import newUser from './newUser'

// documentation https://tv.tycoon.systems/documentation?q=send%20email%20via%20event
export default {
    newUser
}