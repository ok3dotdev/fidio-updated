import newUser from './newUser'
import reset_password from './reset_password'

// documentation https://tycoon.systems/documentation?q=send%20email%20via%20event
export default {
    newUser,
    reset_password
}