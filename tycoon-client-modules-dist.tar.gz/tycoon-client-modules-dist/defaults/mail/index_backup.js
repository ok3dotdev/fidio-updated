import newUser from './newUser'

export {
    newUser
}