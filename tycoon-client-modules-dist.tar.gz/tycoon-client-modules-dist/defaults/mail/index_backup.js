import newUser from './newUser'

export default {
    newUser
}