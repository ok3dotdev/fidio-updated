"use strict";

function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _index = require("../utility/socket/index");
var _react = _interopRequireWildcard(require("react"));
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") { return { "default": obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj["default"] = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
var SocketContainer = function SocketContainer(props) {
  var socket = props.socket;
  var socketRef = (0, _react.useRef)(false);
  var initializeTimer = (0, _react.useRef)(null);
  (0, _react.useEffect)(function () {
    if (!socketRef.current && props._loggedIn && props.dborigin) {
      buildConnection();
    }
  }, [socket, socketRef.current, props._loggedIn, props.dborigin]);
  var buildConnection = function buildConnection() {
    return new Promise(function (resolve, reject) {
      /* Sometimes no explicit Connect event fired. Run if connected true */
      if (socket.connected && props._loggedIn && props.dborigin) {
        (0, _index.initialize)(socket, props._loggedIn, props.dborigin);
      }
      socket.on('connect', function (data) {
        console.log('Connected to socket ∞¦∞', socket);
        socketRef.current = true;
        setTimeout(function () {
          (0, _index.initialize)(socket, props._loggedIn, props.dborigin);
        }, 300);
      }, {
        'reconnectionAttempts': 5
      });
      socket.on("disconnect", function (reason) {
        // Handles disconnects
        console.log('Disconnected from socket', socket);
        if (reason === "io server disconnect") {
          socketRef.current = false;
          // disconnect initiated by server. Manually reconnect
          socket.connect();
        }
      });
      socket.on("connect_error", function (err) {
        console.log('Connection failed', err);
        socketRef.current = false;
        reconnect();
      });
      var reconnect = function reconnect() {
        var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 5000;
        setTimeout(function () {
          socket.connect();
        }, time);
      };
      return resolve();
    });
  };
  (0, _react.useEffect)(function () {
    if (socket) {
      var returnInitialize = function returnInitialize(payload) {
        console.log(payload);
      };
      var returnNotify = function returnNotify(payload) {
        console.log(payload);
      };
      socket.on('returnInitialize', returnInitialize);
      socket.on('returnNotify', returnNotify);
      return function () {
        socket.off('returnInitialize', returnInitialize);
        socket.off('returnNotify', returnNotify);
      };
    }
  }, [props._loggedIn]);
  return /*#__PURE__*/_react["default"].createElement("div", null);
};
var _default = SocketContainer;
exports["default"] = _default;