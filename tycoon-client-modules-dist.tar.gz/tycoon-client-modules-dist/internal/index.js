"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Internal", {
  enumerable: true,
  get: function get() {
    return _Internal["default"];
  }
});
var _Internal = _interopRequireDefault(require("./Internal"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }