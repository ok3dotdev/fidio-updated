import React from 'react';
const Module = props => {
  return /*#__PURE__*/React.createElement("div", null, props.useAppConfigLayout && props.appConfigLayout ? /*#__PURE__*/React.createElement(React.Fragment, null, props.appConfigLayout) : null);
};
export default Module;