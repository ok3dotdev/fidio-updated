"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initialize = void 0;
var initialize = function initialize(socket, loggedIn, dborigin) {
  if (socket && loggedIn) {
    var payload = Object.assign(loggedIn, {
      dborigin: dborigin
    });
    socket.emit('initialize', payload);
    return true;
  } else {
    return false;
  }
};
exports.initialize = initialize;