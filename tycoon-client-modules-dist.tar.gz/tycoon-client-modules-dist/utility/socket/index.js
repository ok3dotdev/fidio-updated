"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "initialize", {
  enumerable: true,
  get: function get() {
    return _socket.initialize;
  }
});
var _socket = require("./socket");