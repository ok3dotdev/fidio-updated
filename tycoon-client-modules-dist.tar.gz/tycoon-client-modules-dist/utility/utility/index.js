"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "normalizeText", {
  enumerable: true,
  get: function get() {
    return _type.normalizeText;
  }
});
var _type = require("./type");