import { normalizeText } from './type';
import { fireGlobalEvent } from './event';
import { getTimeRemaining } from './date';
export { fireGlobalEvent, getTimeRemaining, normalizeText };