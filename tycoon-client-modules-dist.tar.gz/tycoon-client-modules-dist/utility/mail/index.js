import { sendSurveyEmail } from './mail';
export { sendSurveyEmail };