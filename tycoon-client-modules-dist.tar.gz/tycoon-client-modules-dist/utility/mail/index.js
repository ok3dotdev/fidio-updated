"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "sendSurveyEmail", {
  enumerable: true,
  get: function get() {
    return _mail.sendSurveyEmail;
  }
});
var _mail = require("./mail");