"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "fetchSearchData", {
  enumerable: true,
  get: function get() {
    return _search.fetchSearchData;
  }
});
var _search = require("./search");