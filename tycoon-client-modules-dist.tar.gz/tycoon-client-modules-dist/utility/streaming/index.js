"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "beginStream", {
  enumerable: true,
  get: function get() {
    return _stream.beginStream;
  }
});
var _stream = require("./stream");