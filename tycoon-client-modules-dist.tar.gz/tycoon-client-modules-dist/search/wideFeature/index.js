import WideFeature from './WideFeature.js';
export { WideFeature };