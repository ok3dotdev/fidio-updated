"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "WideFeature", {
  enumerable: true,
  get: function get() {
    return _WideFeature["default"];
  }
});
var _WideFeature = _interopRequireDefault(require("./WideFeature.js"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }