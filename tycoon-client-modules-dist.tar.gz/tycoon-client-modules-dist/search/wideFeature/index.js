"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "WideFeature", {
  enumerable: true,
  get: function get() {
    return _WideFeature["default"];
  }
});
var _WideFeature = _interopRequireDefault(require("./WideFeature.js"));