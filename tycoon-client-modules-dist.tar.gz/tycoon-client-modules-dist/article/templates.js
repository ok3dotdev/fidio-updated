const basic = {
  container: {
    margin: '0 1rem'
  },
  internalContainer: {
    margin: '0 auto',
    maxWidth: '800px'
  }
};
export default {
  basic
};