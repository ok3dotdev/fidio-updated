"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var basic = {
  container: {
    margin: '0 1rem'
  },
  internalContainer: {
    margin: '0 auto',
    maxWidth: '800px'
  }
};
var _default = exports["default"] = {
  basic: basic
};