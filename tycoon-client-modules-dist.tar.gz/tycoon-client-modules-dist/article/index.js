import ArticlePage from './ArticlePage';
import SingleArticle from './SingleArticle';
import ArticleTitle from './ArticleTitle';
import ArticleAuthor from './ArticleAuthor';
import ArticleDate from './ArticleDate';
export { ArticleDate, ArticleTitle, ArticlePage, ArticleAuthor, SingleArticle };