"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "ArticlePage", {
  enumerable: true,
  get: function get() {
    return _ArticlePage["default"];
  }
});
var _ArticlePage = _interopRequireDefault(require("./ArticlePage"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }