"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Documentation", {
  enumerable: true,
  get: function get() {
    return _documentation["default"];
  }
});
var _documentation = _interopRequireDefault(require("./documentation"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }