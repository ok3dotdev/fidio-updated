"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "ProfilePage", {
  enumerable: true,
  get: function get() {
    return _ProfilePage["default"];
  }
});
var _ProfilePage = _interopRequireDefault(require("./ProfilePage"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }