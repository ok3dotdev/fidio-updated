"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Help", {
  enumerable: true,
  get: function get() {
    return _Help["default"];
  }
});
var _Help = _interopRequireDefault(require("./Help"));