"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Notifications", {
  enumerable: true,
  get: function get() {
    return _Notifications["default"];
  }
});
var _Notifications = _interopRequireDefault(require("./Notifications"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }