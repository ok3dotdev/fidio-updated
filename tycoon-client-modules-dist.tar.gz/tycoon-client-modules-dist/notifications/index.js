"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Notifications", {
  enumerable: true,
  get: function get() {
    return _Notifications["default"];
  }
});
var _Notifications = _interopRequireDefault(require("./Notifications"));