"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "MarketingSlider", {
  enumerable: true,
  get: function get() {
    return _MarketingSlider["default"];
  }
});
var _MarketingSlider = _interopRequireDefault(require("./MarketingSlider"));