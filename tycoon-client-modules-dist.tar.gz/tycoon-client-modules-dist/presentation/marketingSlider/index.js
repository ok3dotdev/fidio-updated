import MarketingSlider from './MarketingSlider';
export { MarketingSlider };