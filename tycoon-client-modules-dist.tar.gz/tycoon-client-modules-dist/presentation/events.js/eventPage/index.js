"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "EventPage", {
  enumerable: true,
  get: function get() {
    return _EventPage["default"];
  }
});
var _EventPage = _interopRequireDefault(require("./EventPage"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }