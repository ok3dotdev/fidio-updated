import EventPage from './EventPage';
export { EventPage };