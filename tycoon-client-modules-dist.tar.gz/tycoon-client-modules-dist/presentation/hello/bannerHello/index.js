"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "BannerHello", {
  enumerable: true,
  get: function get() {
    return _BannerHello["default"];
  }
});
var _BannerHello = _interopRequireDefault(require("./BannerHello"));