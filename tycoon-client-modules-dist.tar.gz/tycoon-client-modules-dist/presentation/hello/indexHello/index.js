"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "IndexHello", {
  enumerable: true,
  get: function get() {
    return _IndexHello["default"];
  }
});
var _IndexHello = _interopRequireDefault(require("./IndexHello"));