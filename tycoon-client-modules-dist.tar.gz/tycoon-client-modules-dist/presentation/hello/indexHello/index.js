import IndexHello from './IndexHello';
export { IndexHello };