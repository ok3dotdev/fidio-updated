"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "IndexBgHello", {
  enumerable: true,
  get: function get() {
    return _IndexBgHello["default"];
  }
});
var _IndexBgHello = _interopRequireDefault(require("./IndexBgHello"));