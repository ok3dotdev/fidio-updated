import IndexBgHello from './IndexBgHello';
export { IndexBgHello };