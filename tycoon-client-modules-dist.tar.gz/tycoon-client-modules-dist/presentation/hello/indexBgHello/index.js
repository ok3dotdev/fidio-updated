"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "IndexBgHello", {
  enumerable: true,
  get: function get() {
    return _IndexBgHello["default"];
  }
});
var _IndexBgHello = _interopRequireDefault(require("./IndexBgHello"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }