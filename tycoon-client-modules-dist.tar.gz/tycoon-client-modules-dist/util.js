"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.compareObjects = compareObjects;
exports.isObjectEmpty = exports.getFormattedTime = exports.getFormattedDate = exports.detectAllowEditingFlag = exports.debounce = void 0;
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest(); }
function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }
function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }
function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) arr2[i] = arr[i]; return arr2; }
function _iterableToArrayLimit(arr, i) { var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"]; if (null != _i) { var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1; try { if (_x = (_i = _i.call(arr)).next, 0 === i) { if (Object(_i) !== _i) return; _n = !1; } else for (; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0); } catch (err) { _d = !0, _e = err; } finally { try { if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return; } finally { if (_d) throw _e; } } return _arr; } }
function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }
var isObjectEmpty = function isObjectEmpty(obj) {
  return obj // 👈 null and undefined check
  && Object.keys(obj).length === 0 && Object.getPrototypeOf(obj) === Object.prototype;
};
exports.isObjectEmpty = isObjectEmpty;
var debounce = function debounce(a, b, c) {
  var d, e;
  return function () {
    function h() {
      d = null, c || (e = a.apply(f, g));
    }
    var f = this,
      g = arguments;
    return clearTimeout(d), d = setTimeout(h, b), c && !d && (e = a.apply(f, g)), e;
  };
};
exports.debounce = debounce;
var detectAllowEditingFlag = function detectAllowEditingFlag(data, loggedIn) {
  if (data && data.author && loggedIn && loggedIn.identifier && data.author === loggedIn.identifier) {
    return true;
  }
  return false;
};
exports.detectAllowEditingFlag = detectAllowEditingFlag;
var getFormattedTime = function getFormattedTime(time) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  try {
    // Format the time (-HH:MMAM/PM)
    if (options.simple) {
      var _time$split$map = time.split(':').map(Number),
        _time$split$map2 = _slicedToArray(_time$split$map, 2),
        hours = _time$split$map2[0],
        minutes = _time$split$map2[1];
      var period = hours < 12 ? 'AM' : 'PM';
      var hours12 = hours % 12 || 12;
      var _formattedTime = "".concat(hours12, ":").concat(minutes.toString().padStart(2, '0')).concat(period);
      return _formattedTime;
    }
    var timeOptions = {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    };
    var timeFormatter = new Intl.DateTimeFormat('en-US', timeOptions);
    var formattedTime = timeFormatter.format(time);
    return formattedTime;
  } catch (err) {
    console.log(err);
    return time;
  }
};
exports.getFormattedTime = getFormattedTime;
var getFormattedDate = function getFormattedDate(date) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.pretty) {
    try {
      var dateOptions = {
        day: '2-digit',
        month: 'short',
        year: 'numeric'
      };
      console.log('Format Date', date, _typeof(date));
      var dateFormatter = new Intl.DateTimeFormat('en-US', dateOptions);
      var formattedDate = dateFormatter.format(new Date(date));
      console.log('Time for Date', date);
      var formattedTime = getFormattedTime(new Date(date));
      console.log('Formatted Time Date', formattedDate, formattedTime);
      // Combine date and time
      if (!options.date && !options.time || options.date && options.time) {
        return formattedDate + '-' + formattedTime;
      }
      var d = '';
      if (options.date) {
        d += formattedDate;
      }
      if (options.time) {
        if (d.length !== 0) {
          d += '-';
        }
        d += formattedTime;
      }
      return d;
    } catch (err) {
      console.log(err);
      return date;
    }
  }
  var year = date.getFullYear();
  var month = (1 + date.getMonth()).toString().padStart(2, '0');
  var day = date.getDate().toString().padStart(2, '0');
  return month + '/' + day + '/' + year;
};
exports.getFormattedDate = getFormattedDate;
function compareObjects(obj1, obj2) {
  if (obj1 === obj2) return true;
  if (_typeof(obj1) !== 'object' || _typeof(obj2) !== 'object' || obj1 == null || obj2 == null) {
    return false;
  }
  var keysA = Object.keys(obj1);
  var keysB = Object.keys(obj2);
  if (keysA.length !== keysB.length) {
    return false;
  }
  var result = true;
  keysA.forEach(function (key) {
    if (!keysB.includes(key)) {
      result = false;
    }
    if (typeof obj1[key] === 'function' || typeof obj2[key] === 'function') {
      if (obj1[key].toString() !== obj2[key].toString()) {
        result = false;
      }
    }
    if (!compareObjects(obj1[key], obj2[key])) {
      result = false;
    }
  });
  return result;
}