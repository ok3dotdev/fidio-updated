"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isObjectEmpty = exports.getFormattedDate = exports.detectAllowEditingFlag = exports.debounce = void 0;
var isObjectEmpty = function isObjectEmpty(obj) {
  return obj // 👈 null and undefined check
  && Object.keys(obj).length === 0 && Object.getPrototypeOf(obj) === Object.prototype;
};
exports.isObjectEmpty = isObjectEmpty;
var debounce = function debounce(a, b, c) {
  var d, e;
  return function () {
    function h() {
      d = null, c || (e = a.apply(f, g));
    }
    var f = this,
      g = arguments;
    return clearTimeout(d), d = setTimeout(h, b), c && !d && (e = a.apply(f, g)), e;
  };
};
exports.debounce = debounce;
var detectAllowEditingFlag = function detectAllowEditingFlag(data, loggedIn) {
  if (data && data.author && loggedIn && loggedIn.identifier && data.author === loggedIn.identifier) {
    return true;
  }
  return false;
};
exports.detectAllowEditingFlag = detectAllowEditingFlag;
var getFormattedDate = function getFormattedDate(date) {
  var year = date.getFullYear();
  var month = (1 + date.getMonth()).toString().padStart(2, '0');
  var day = date.getDate().toString().padStart(2, '0');
  return month + '/' + day + '/' + year;
};
exports.getFormattedDate = getFormattedDate;