"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.compareObjects = compareObjects;
exports.isObjectEmpty = exports.getFormattedDate = exports.detectAllowEditingFlag = exports.debounce = void 0;
function _typeof(obj) { "@babel/helpers - typeof"; return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (obj) { return typeof obj; } : function (obj) { return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj; }, _typeof(obj); }
var isObjectEmpty = function isObjectEmpty(obj) {
  return obj // 👈 null and undefined check
  && Object.keys(obj).length === 0 && Object.getPrototypeOf(obj) === Object.prototype;
};
exports.isObjectEmpty = isObjectEmpty;
var debounce = function debounce(a, b, c) {
  var d, e;
  return function () {
    function h() {
      d = null, c || (e = a.apply(f, g));
    }
    var f = this,
      g = arguments;
    return clearTimeout(d), d = setTimeout(h, b), c && !d && (e = a.apply(f, g)), e;
  };
};
exports.debounce = debounce;
var detectAllowEditingFlag = function detectAllowEditingFlag(data, loggedIn) {
  if (data && data.author && loggedIn && loggedIn.identifier && data.author === loggedIn.identifier) {
    return true;
  }
  return false;
};
exports.detectAllowEditingFlag = detectAllowEditingFlag;
var getFormattedDate = function getFormattedDate(date) {
  var year = date.getFullYear();
  var month = (1 + date.getMonth()).toString().padStart(2, '0');
  var day = date.getDate().toString().padStart(2, '0');
  return month + '/' + day + '/' + year;
};
exports.getFormattedDate = getFormattedDate;
function compareObjects(obj1, obj2) {
  if (obj1 === obj2) return true;
  if (_typeof(obj1) !== 'object' || _typeof(obj2) !== 'object' || obj1 == null || obj2 == null) {
    return false;
  }
  var keysA = Object.keys(obj1);
  var keysB = Object.keys(obj2);
  if (keysA.length !== keysB.length) {
    return false;
  }
  var result = true;
  keysA.forEach(function (key) {
    if (!keysB.includes(key)) {
      result = false;
    }
    if (typeof obj1[key] === 'function' || typeof obj2[key] === 'function') {
      if (obj1[key].toString() !== obj2[key].toString()) {
        result = false;
      }
    }
    if (!compareObjects(obj1[key], obj2[key])) {
      result = false;
    }
  });
  return result;
}