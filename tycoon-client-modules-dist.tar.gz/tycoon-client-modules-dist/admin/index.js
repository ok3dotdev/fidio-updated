"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Admin", {
  enumerable: true,
  get: function get() {
    return _Admin["default"];
  }
});
Object.defineProperty(exports, "Banner", {
  enumerable: true,
  get: function get() {
    return _Banner["default"];
  }
});
var _Admin = _interopRequireDefault(require("./Admin.js"));
var _Banner = _interopRequireDefault(require("./Banner"));