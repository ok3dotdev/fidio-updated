"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "IndexCta", {
  enumerable: true,
  get: function get() {
    return _IndexCta["default"];
  }
});
var _IndexCta = _interopRequireDefault(require("./IndexCta"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }