import IndexCta from './IndexCta';
export { IndexCta };