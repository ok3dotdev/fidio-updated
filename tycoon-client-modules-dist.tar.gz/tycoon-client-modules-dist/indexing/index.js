import SliderBasic from './SliderBasic';
export { SliderBasic };