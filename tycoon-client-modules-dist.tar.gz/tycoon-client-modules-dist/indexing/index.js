"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "SliderBasic", {
  enumerable: true,
  get: function get() {
    return _SliderBasic["default"];
  }
});
var _SliderBasic = _interopRequireDefault(require("./SliderBasic"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }