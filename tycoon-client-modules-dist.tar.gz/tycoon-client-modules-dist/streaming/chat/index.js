"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Chat", {
  enumerable: true,
  get: function get() {
    return _Chat["default"];
  }
});
var _Chat = _interopRequireDefault(require("./Chat.js"));