"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "WatchPage", {
  enumerable: true,
  get: function get() {
    return _WatchPage["default"];
  }
});
var _WatchPage = _interopRequireDefault(require("./WatchPage.js"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }