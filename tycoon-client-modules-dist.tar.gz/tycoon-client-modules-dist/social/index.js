"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "utility", {
  enumerable: true,
  get: function get() {
    return _utility["default"];
  }
});
var _utility = _interopRequireDefault(require("./utility"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }