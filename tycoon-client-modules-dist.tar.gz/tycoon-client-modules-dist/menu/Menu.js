"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var _react = _interopRequireDefault(require("react"));
var _SubMenu = _interopRequireDefault(require("./SubMenu.js"));
var _MenuModule = _interopRequireDefault(require("./Menu.module.scss"));
var _link = _interopRequireDefault(require("next/link"));
var _SignIn = require("/modules/utility/onboarding/SignIn.js");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { "default": obj }; }
// import brand from '../../styles/Brand.module.scss';

var Menu = function Menu(props) {
  console.log(props._openMenu);
  var handleToggleSettings = _react["default"].useCallback(function (e) {
    if (e && props && props._toggleSingleOpenMenu) {
      props._toggleSingleOpenMenu(e, 'main_settings');
    }
  }, [props._openMenu]);
  var handleLogout = _react["default"].useCallback(function (e) {
    (0, _SignIn.logout)(props._setLoggedIn);
    props._LocalEventEmitter.dispatch('showSignIn', {});
  });
  return /*#__PURE__*/_react["default"].createElement("div", {
    style: {
      width: 100 + "%"
    },
    className: "leadMenuContainer ".concat(_MenuModule["default"].container, " darkModeEnforce")
  }, /*#__PURE__*/_react["default"].createElement("div", {
    style: {
      paddingBottom: 0,
      paddingTop: 0
    },
    className: "margin1600 menuContainer"
  }, /*#__PURE__*/_react["default"].createElement(_SubMenu["default"], {
    _loggedIn: props._loggedIn
  }), /*#__PURE__*/_react["default"].createElement("ul", {
    className: !props._loggedIn ? "".concat(_MenuModule["default"].menu, " ").concat(_MenuModule["default"].menuClosed) : _MenuModule["default"].menu
  }, /*#__PURE__*/_react["default"].createElement(_link["default"], {
    href: "/p"
  }, /*#__PURE__*/_react["default"].createElement("li", {
    className: "".concat(_MenuModule["default"].menuLink, " darkMenuLink")
  }, /*#__PURE__*/_react["default"].createElement("span", {
    className: "".concat(_MenuModule["default"].menuLinkText)
  }, /*#__PURE__*/_react["default"].createElement("div", null, props._loggedIn && props._loggedIn.username ? props._loggedIn.username : 'Dashboard'), /*#__PURE__*/_react["default"].createElement("div", {
    className: "".concat(_MenuModule["default"].menuLinkIconPair, " person material-icons")
  }, "person")), /*#__PURE__*/_react["default"].createElement("div", {
    className: "".concat(_MenuModule["default"].menuLinkIcon, " person material-icons")
  }, "person"))), /*#__PURE__*/_react["default"].createElement("div", {
    onClick: handleToggleSettings,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/_react["default"].createElement("li", {
    className: "".concat(_MenuModule["default"].menuLink, " darkMenuLink")
  }, /*#__PURE__*/_react["default"].createElement("span", {
    className: "".concat(_MenuModule["default"].menuLinkText)
  }, /*#__PURE__*/_react["default"].createElement("div", null), /*#__PURE__*/_react["default"].createElement("div", {
    className: "".concat(_MenuModule["default"].menuLinkIconPair, " ").concat(_MenuModule["default"].menuLinkIconNoText, " settings material-icons")
  }, "settings")), /*#__PURE__*/_react["default"].createElement("div", {
    className: "".concat(_MenuModule["default"].menuLinkIcon, " settings material-icons")
  }, "settings")), props._openMenu && props._openMenu.currentMenu && props._openMenu.currentMenu == 'main_settings' ? /*#__PURE__*/_react["default"].createElement("div", {
    className: "dropMenu"
  }, /*#__PURE__*/_react["default"].createElement("ul", null, props._loggedIn ? /*#__PURE__*/_react["default"].createElement("li", null, /*#__PURE__*/_react["default"].createElement("div", {
    onClick: handleLogout
  }, "Logout")) : null)) : null))));
};
var _default = Menu;
exports["default"] = _default;