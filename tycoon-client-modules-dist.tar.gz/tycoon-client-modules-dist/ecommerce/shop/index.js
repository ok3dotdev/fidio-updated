"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Shop", {
  enumerable: true,
  get: function get() {
    return _Shop["default"];
  }
});
var _Shop = _interopRequireDefault(require("./Shop"));