import ReceiptPage from './ReceiptPage';
import Order from './Order';
export { ReceiptPage, Order };