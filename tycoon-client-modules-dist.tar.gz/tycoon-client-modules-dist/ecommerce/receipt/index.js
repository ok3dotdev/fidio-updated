"use strict";

var _interopRequireDefault = require("@babel/runtime/helpers/interopRequireDefault");
Object.defineProperty(exports, "__esModule", {
  value: true
});
Object.defineProperty(exports, "Order", {
  enumerable: true,
  get: function get() {
    return _Order["default"];
  }
});
Object.defineProperty(exports, "ReceiptPage", {
  enumerable: true,
  get: function get() {
    return _ReceiptPage["default"];
  }
});
var _ReceiptPage = _interopRequireDefault(require("./ReceiptPage"));
var _Order = _interopRequireDefault(require("./Order"));