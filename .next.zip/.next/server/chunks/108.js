exports.id = 108;
exports.ids = [108];
exports.modules = {

/***/ 6242:
/***/ ((module) => {

// Exports
module.exports = {
	"changeImageButton": "ProductImageManager_changeImageButton__LT9lF",
	"changeImageButtonSmall": "ProductImageManager_changeImageButtonSmall__kFQnf",
	"warning": "ProductImageManager_warning__YOxAD",
	"warningItemContainer": "ProductImageManager_warningItemContainer__rzhCz",
	"warningItem": "ProductImageManager_warningItem__AXVz0",
	"productImageContainer": "ProductImageManager_productImageContainer__jGX6C",
	"productImageListThumbnailContainer": "ProductImageManager_productImageListThumbnailContainer__kv2Xk",
	"productImageListContainer": "ProductImageManager_productImageListContainer__DLT2i"
};


/***/ }),

/***/ 3548:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "ReceiptPage_container__T3wjq",
	"pair": "ReceiptPage_pair__d14Vo"
};


/***/ }),

/***/ 5305:
/***/ ((module) => {

// Exports
module.exports = {
	"container": "Shop_container__Qt_8s",
	"adminContainer": "Shop_adminContainer__qm7JM"
};


/***/ }),

/***/ 8331:
/***/ ((module) => {

// Exports
module.exports = {
	"cta": "Slider_cta__IxtIr",
	"heading": "Slider_heading__KXJG4",
	"textOffsetContainer": "Slider_textOffsetContainer__XG4Ac",
	"status": "Slider_status__eePXF",
	"container2": "Slider_container2__q_VX8"
};


/***/ }),

/***/ 5432:
/***/ ((module) => {

// Exports
module.exports = {
	"featureExternalContainer": "Feature_featureExternalContainer__HMUAB",
	"featureContainer": "Feature_featureContainer__LVtvY",
	"featureContainerMedium": "Feature_featureContainerMedium__0pdnW",
	"featureContainerLarge": "Feature_featureContainerLarge__CWQgM",
	"itemContainer": "Feature_itemContainer__XTdyL",
	"item": "Feature_item__AlkTJ",
	"itemContainerThin": "Feature_itemContainerThin__BVE6T",
	"itemMetaContainer": "Feature_itemMetaContainer__xs8KZ",
	"itemMetaContainerPadding": "Feature_itemMetaContainerPadding__4VsEy",
	"itemMetaText": "Feature_itemMetaText__tM6W4",
	"statusContainerInline": "Feature_statusContainerInline__dA_lm",
	"titleText": "Feature_titleText__MyAZ_",
	"thinMetaContainerSize": "Feature_thinMetaContainerSize__295tR",
	"itemThin": "Feature_itemThin__uxwB5",
	"statusContainer": "Feature_statusContainer__9FTwj",
	"sizeExpandContainer": "Feature_sizeExpandContainer__pTXXG",
	"sizeExpand": "Feature_sizeExpand__bv8sF",
	"featureContainerOpen": "Feature_featureContainerOpen__k6Pct",
	"thinMeta": "Feature_thinMeta__q6LSL"
};


/***/ }),

/***/ 6428:
/***/ ((module) => {

// Exports
module.exports = {
	"itemsContainer": "Manager_itemsContainer__Ju_iF",
	"item": "Manager_item__bD6LZ",
	"activeItem": "Manager_activeItem__okAOi"
};


/***/ }),

/***/ 4334:
/***/ ((module) => {

// Exports
module.exports = {
	"videoQuadrant": "WatchPage_videoQuadrant__MgFxK",
	"videoContainer": "WatchPage_videoContainer__o4x4O",
	"videoPlayer": "WatchPage_videoPlayer__53LUC",
	"streamLeadPrompt": "WatchPage_streamLeadPrompt__AAkdQ",
	"streamLeadPrompt_Visible": "WatchPage_streamLeadPrompt_Visible__IY6yv"
};


/***/ }),

/***/ 4012:
/***/ ((module) => {

// Exports
module.exports = {
	"leadContainer": "gridList_leadContainer__H4Jsd",
	"col": "gridList_col__Ndehq"
};


/***/ }),

/***/ 2085:
/***/ ((module) => {

// Exports
module.exports = {
	"leadContainer": "videoItem_leadContainer__S3mGv",
	"container": "videoItem_container__eoe2J",
	"ghostVideoContainer": "videoItem_ghostVideoContainer__9UEYm",
	"ghostVideoContainerActive": "videoItem_ghostVideoContainerActive__MCCZ2",
	"metaContainer": "videoItem_metaContainer__yuiWH",
	"editFlagContainer": "videoItem_editFlagContainer__xY3fM",
	"editFlag": "videoItem_editFlag__y2bCu"
};


/***/ }),

/***/ 4803:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Countdown({ eventDate  }) {
    const [timeLeft, setTimeLeft] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const intervalId = setInterval(()=>{
            const now = new Date();
            const timeDifference = new Date(eventDate) - now;
            if (timeDifference <= 0) {
                clearInterval(intervalId);
                setTimeLeft({
                    days: 0,
                    hours: 0,
                    minutes: 0,
                    seconds: 0
                });
                return;
            }
            const days = Math.floor(timeDifference / (1000 * 60 * 60 * 24));
            const hours = Math.floor(timeDifference % (1000 * 60 * 60 * 24) / (1000 * 60 * 60));
            const minutes = Math.floor(timeDifference % (1000 * 60 * 60) / (1000 * 60));
            const seconds = Math.floor(timeDifference % (1000 * 60) / 1000);
            setTimeLeft({
                days,
                hours,
                minutes,
                seconds
            });
        }, 1000);
        return ()=>clearInterval(intervalId);
    }, [
        eventDate
    ]);
    return !timeLeft ? "" : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "absolute top-24 right-10 mt-24 flex gap-4 text-2xl glow-text",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: timeLeft.days
                    }),
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Days"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: timeLeft.hours
                    }),
                    " ",
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Hours"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: timeLeft.minutes
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Minutes "
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        children: [
                            timeLeft.seconds,
                            " "
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                        children: "Seconds"
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Countdown);


/***/ }),

/***/ 9021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



const Footer = (props)=>{
    const { pageName  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `w-full bg-black relative ${pageName === "Index" ? "mt-[100vh]" : ""}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-between pt-8 w-full pb-1 lg:grid-cols-5 md:pb-14 order-0 sm:gap-6 sm:grid sm:grid-cols-4 max-w-[110rem] mx-auto px-4 text-gray-400 gap-y-12 text-xs",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-center col-span-1 lg:col-span-2 w-full flex justify-center lg:block",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/img/internal/frame2.png",
                            alt: "",
                            className: "h-auto w-[260px]"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-span-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-gray-400",
                                children: "LEGAL"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/terms",
                                            children: "Terms of Service"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "/privacy",
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            href: "#",
                                            children: "FAQ"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-gray-400",
                                children: "COMPANY"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Artist & Managers"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Clubs & Venues"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Partners"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Sponsors"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-gray-400",
                                children: "FOLLOW US"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-white",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "https://www.instagram.com/fidio_official/?igshid=MWZjMTM2ODFkZg%3D%3D/",
                                            children: "Instagram"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "https://www.facebook.com/Fidioafrica",
                                            children: "Facebook"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            target: "_blank",
                                            href: "#",
                                            children: "Twitter"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            target: "_blank",
                                            href: "https://www.linkedin.com/company/fidio-inc/",
                                            children: "LinkedIn"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full p-7 max-w-[110rem] mx-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                        className: "border-gray-400 mb-4"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex justify-between text-gray-400 text-xs",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "\xa92023 Fidio."
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: " CA(CAD)"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 504:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);


const Hero = (props)=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "min-h-screen h-screen absolute top-0 w-full hero",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "absolute inset-0 bg-black opacity-70 min-h-screen"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-6xl mx-auto p-4 px-4 text-center lg:text-left lg:flex lg:pt-[200px] pt-[140px] flex flex-col lg:flex-row gap-1 h-full lg:h-auto relative z-20",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center lg:items-start basis-2/3 justify-center lg:justify-start",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                                className: "font-black text-4xl md:text-6xl lg:text-7xl mb-1 text-white text-center lg:text-left max-w-[800px] main-heading",
                                children: "Your Premiere Home for Live Afrobeats"
                            }),
                            props._loggedIn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                href: "/home",
                                className: "hidden mt-8 px-8 py-4 bg-orange-800 text-white rounded-md lg:block",
                                children: "Get Started"
                            }) : ""
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "w-full flex flex-col lg:flex-row lg:justify-center items-center lg:basis-1/3 pb-32 lg:pt-0 mt-[180px] lg:mt-[0]",
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "bg-black p-4 inline-flex flex-col rounded-lg lg:w-[590px] w-[280px] lg:max-w-[400px] max-w-[500px] max-h-[600px] shadow-xl",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: " relative bg-gray-400 rounded-lg",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        src: "/img/internal/althero.png",
                                        alt: "",
                                        className: "w-full  rounded-lg"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-col lg:flex-row mt-4 justify-between shadow-xl ",
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-center lg:text-left",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "font-black text-xl text-white",
                                                    children: "Alternate Sound Live 6.0"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    className: "text-sm text-white",
                                                    children: "Nov 04 |6:00PM EST"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "basis-1/2 flex flex-col text-center text-white",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                href: "/signin",
                                                className: "rounded-md inline-flex justify-center items-center px-4 py-3 bg-orange-800 mt-2 font-bold",
                                                children: "BUY $4.99"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Hero);


/***/ }),

/***/ 4836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



const Menu = (props)=>{
    var _props_userData, _props_userData_profileData, _props_userData_profileData_user;
    const [isMenuOpen, setIsMenuOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "bg-transparent z-40 relative flex justify-center",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-8xl mx-auto flex justify-between px-2 pr-4 pt-1 lg:p-4 items-center w-full",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            className: "w-[150px] h-auto",
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "/img/internal/frame2.png",
                                alt: "",
                                className: "w-[150px] h-auto"
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "lg:flex gap-4 hidden",
                        children: [
                            !props._loggedIn ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        className: "px-6 py-2 rounded-md flex justify-center items-center",
                                        href: "/signin",
                                        children: "Login"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        className: "bg-white text-black px-6 py-2 rounded-md flex justify-center items-center",
                                        href: "/signin",
                                        children: "Sign Up"
                                    })
                                ]
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {}),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-12 h-12 rounded-full",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                    href: "/p",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                        className: "rounded-full",
                                        src: props === null || props === void 0 ? void 0 : (_props_userData = props.userData) === null || _props_userData === void 0 ? void 0 : (_props_userData_profileData = _props_userData.profileData) === null || _props_userData_profileData === void 0 ? void 0 : (_props_userData_profileData_user = _props_userData_profileData.user) === null || _props_userData_profileData_user === void 0 ? void 0 : _props_userData_profileData_user.icon,
                                        alt: ""
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:hidden flex items-center",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: ()=>setIsMenuOpen(!isMenuOpen),
                            className: "text-white focus:outline-none",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                className: "w- h-6",
                                fill: "none",
                                stroke: "currentColor",
                                viewBox: "0 0 24 24",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeWidth: "2",
                                    d: "M4 6h16M4 12h16m-7 6h7"
                                })
                            })
                        })
                    })
                ]
            }),
            isMenuOpen && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "lg:hidden fixed inset-0 bg-black p-4 transition-transform transform-gpu translate-y-0 ease-out duration-300 flex flex-col justify-between",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "flex justify-between items-center mb-8",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/home",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                            src: "/img/internal/frame2.png",
                                            alt: "",
                                            className: "w-[150px] h-auto cursor-pointer"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        onClick: ()=>setIsMenuOpen(!isMenuOpen),
                                        className: "text-white focus:outline-none",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
                                            className: "w-8 h-6",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            xmlns: "http://www.w3.org/2000/svg",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: "2",
                                                d: "M6 18L18 6M6 6l12 12"
                                            })
                                        })
                                    })
                                ]
                            }),
                            !props._loggedIn ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "hover:bg-slate-700 mb-4 px-6 py-2 rounded-md flex items-center",
                                href: "/signin",
                                children: "Home"
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: "hover:bg-slate-700 mb-4 px-6 py-2 rounded-md flex items-center",
                                href: "/home",
                                children: "Home"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "space-y-4",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: " px-6 py-2 rounded-md flex justify-center items-center",
                                href: "/signin",
                                children: "Login"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                className: " bg-white text-black px-6 py-2 rounded-md flex justify-center items-center",
                                href: "/signin",
                                children: "Sign Up"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Menu);


/***/ }),

/***/ 6213:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_onboarding_signin__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9358);



const Signin = (props)=>{
    //   console.log('signin', props);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "w-full h-[100vh] fixed",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "max-w-3xl mx-auto h-full w-full lg:grid grid-cols-1 gap-5 lg:gap-8 lg:grid-cols-2 flex flex-col justify-start lg:justify-center",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "lg:flex justify-start lg:justify-center items-center col-span-1 mt-[10%] hidden",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/img/internal/frame2.png",
                            alt: "",
                            width: "450px",
                            className: "w-[300px] lg:w-[450px]"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col gap-y-2 justify-start lg:justify-center items-center lg:mt-0",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "w-full lg:hidden block",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                    src: "/img/internal/frame2.png",
                                    alt: "",
                                    width: "250px",
                                    className: "w-[100px] lg:w-[250px]"
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "text-2xl mb-8 font-bold",
                                children: "Log In or Sign Up"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modules_onboarding_signin__WEBPACK_IMPORTED_MODULE_2__.Username, {
                                redirectOnAuth: "/home",
                                ...props,
                                prompt: "Username",
                                confirm: "Continue"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modules_onboarding_signin__WEBPACK_IMPORTED_MODULE_2__.SignIn, {
                                redirectOnAuth: "/home",
                                ...props
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Signin);


/***/ }),

/***/ 4884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const LoadingSkeleton = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        role: "status",
        class: "space-y-8 animate-pulse md:space-y-0 md:space-x-8 md:flex md:items-center ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            class: "flex items-center justify-center w-full bg-gray-300 rounded dark:bg-gray-500 min-h-[70vh]"
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoadingSkeleton);


/***/ }),

/***/ 2044:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
// TicketClaimedPopup.js


const TicketClaimedPopup = ({ onClose  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "bg-gray-800 p-8 rounded-lg shadow-lg  text-center",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "z-20",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                        className: "text-2xl mb-4",
                        children: "You're all set!"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                        children: "Please check your cart to complete purchase"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        onClick: onClose,
                        className: "bg-orange-400 text-white px-4 py-2 rounded mt-2",
                        children: "Close"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TicketClaimedPopup);


/***/ }),

/***/ 2643:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ customModules)
});

// EXTERNAL MODULE: ./customModules/features/Hero.jsx
var Hero = __webpack_require__(504);
// EXTERNAL MODULE: ./customModules/features/Menu.jsx
var Menu = __webpack_require__(4836);
// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./modules/search/feature/index.js
var feature = __webpack_require__(7173);
;// CONCATENATED MODULE: ./customModules/features/data/index.js
const upcomingEvents = [
    {
        img: "img/internal/lagosparty.jpg",
        title: "Kris Hans & Top Striker",
        artist: "Kris Hans & Top Striker",
        date: "SEP 30, 2023",
        price: "FREE"
    },
    {
        img: "img/internal/sewa.jpg",
        title: "A Night With Sewa",
        artist: "Sewa",
        date: "0ct 22, 2023",
        price: "FREE"
    },
    {
        img: "img/internal/sharon4.png",
        title: "Rock Concert Extravaganza",
        artist: "Rock Band X",
        date: "Sep 07, 2023",
        price: 15
    },
    {
        img: "img/internal/sharon2.png",
        title: "Jazz Night under the Stars",
        artist: "Smooth Jazz Trio",
        date: "JAN 04, 2024",
        price: 40
    },
    {
        img: "img/internal/SharonRose14.png",
        title: "Country Music Jamboree",
        artist: "Country Stars",
        date: "Jul 09, 2023",
        price: 10
    },
    {
        img: "img/internal/sharon9.png",
        title: "Electronic Dance Party",
        artist: "DJ Electronica",
        date: "Aug 09, 2023",
        price: 20
    },
    {
        img: "img/internal/sharonx.png",
        title: "Classical Music Gala",
        artist: "Symphony Orchestra",
        date: "Jul 09, 2023",
        price: 15
    },
    {
        img: "img/internal/SharonRose15.png",
        title: "Rap Battle Showdown",
        artist: "Hip-Hop Crew",
        date: "Sep 07, 2023",
        price: 25
    }
];

// EXTERNAL MODULE: external "react-fast-marquee"
var external_react_fast_marquee_ = __webpack_require__(5700);
var external_react_fast_marquee_default = /*#__PURE__*/__webpack_require__.n(external_react_fast_marquee_);
;// CONCATENATED MODULE: ./customModules/features/EventsGrid.jsx




const EventsGrid = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full mb-12 mt-12 px-2 lg:px-8",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                className: "text-2xl font-bold",
                children: "Past Shows"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "mt-8",
                children: /*#__PURE__*/ jsx_runtime.jsx((external_react_fast_marquee_default()), {
                    style: {
                        display: "flex",
                        gap: "1rem"
                    },
                    className: "w-full flex  gap-x-2",
                    pauseOnClick: true,
                    speed: 20,
                    children: upcomingEvents.map(({ img , title , artist , date , price  }, index)=>/*#__PURE__*/ jsx_runtime.jsx(Events, {
                            title: title,
                            artist: artist,
                            date: date,
                            price: price,
                            img: img
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const features_EventsGrid = (EventsGrid);
const Events = ({ title , artist , date , price , img  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "max-w-[200px] lg:max-w-[400px] mr-4 transition-transform duration-300 overflow-hidden",
        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
            className: "h-[200px] rounded-md mb-2 min-h-[200px] overflow-hidden relative transform transition-transform duration-300",
            children: [
                /*#__PURE__*/ jsx_runtime.jsx("img", {
                    className: "w-full object-cover",
                    src: img,
                    alt: ""
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "absolute inset-0 bg-black opacity-30 transition-opacity hover:opacity-20"
                }),
                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "absolute top-0 left-0 mt-4 ml-4 bg-orange-300 rounded-md p-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "absolute inset-0 bg-black opacity-40 transition-opacity hover:opacity-20"
                        }),
                        /*#__PURE__*/ jsx_runtime.jsx("p", {
                            className: "text-xs text-black z-20",
                            children: date.slice(0, 6)
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "absolute bottom-0 left-0 mb-4 ml-4",
                    children: /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        className: "text-white text-lg",
                        children: title
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./modules/indexing/index.js
var indexing = __webpack_require__(6256);
// EXTERNAL MODULE: external "react-responsive-carousel"
var external_react_responsive_carousel_ = __webpack_require__(4508);
// EXTERNAL MODULE: ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css
var carousel_min = __webpack_require__(3559);
// EXTERNAL MODULE: ./customModules/features/TicketPopup.jsx
var TicketPopup = __webpack_require__(2044);
;// CONCATENATED MODULE: ./customModules/features/FreePopUp.jsx


const FreePopUp = ({ onClose  })=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "fixed inset-0 bg-black bg-opacity-75 flex justify-center items-center z-50",
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "bg-gray-800 p-8 rounded-lg shadow-lg  text-center",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "z-20",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "text-2xl mb-4",
                        children: "You're all set!"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex gap-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("img", {
                                className: "w-[180px] h-[200px] rounded-lg max-w-[200px]",
                                src: "/img/internal/tinycafe.jpeg",
                                alt: "sewa"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "flex flex-col gap-2 justify-center text-left font-light",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        children: "Tiny's Cafe Session"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "font-sans",
                                        children: "NOV 5th"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                        className: "font-sans",
                                        children: "06:30PM EST"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("button", {
                        onClick: onClose,
                        className: "bg-orange-400 text-white px-4 py-2 rounded mt-2",
                        children: "Close"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const features_FreePopUp = (FreePopUp);

// EXTERNAL MODULE: ./customModules/features/CountDown.jsx
var CountDown = __webpack_require__(4803);
// EXTERNAL MODULE: ./modules/utility/fetch/index.js
var fetch = __webpack_require__(23);
// EXTERNAL MODULE: ./modules/utility/utility/index.js
var utility = __webpack_require__(5329);
;// CONCATENATED MODULE: ./customModules/features/FeaturedEvent.jsx









const FeaturedEvent = (props, showTimer, data)=>{
    const [isPopupVisible, setIsPopupVisible] = (0,external_react_.useState)(false);
    const [showPop, setShowPop] = (0,external_react_.useState)(false);
    const [currentIndex, setCurrentIndex] = (0,external_react_.useState)(0);
    const handleTicketClaim = external_react_default().useCallback(async (e)=>{
        (0,utility.fireGlobalEvent)(e, props._LocalEventEmitter);
        setIsPopupVisible(true);
    });
    const handleFreeTicketClaim = (e)=>{
        setShowPop(true);
    };
    function convertTimestamp(timestamp) {
        const dateObj = new Date(timestamp);
        const options = {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "2-digit",
            minute: "2-digit",
            timeZoneName: "short"
        };
        const formattedDateTime = dateObj.toLocaleString("en-US", options);
        return formattedDateTime;
    }
    const handlePopupClose = ()=>{
        setIsPopupVisible(false);
        setShowPop(false);
    };
    const handleCarouselChange = (index)=>{
        setCurrentIndex(index);
    };
    const handleFireGlobalEvent = external_react_default().useCallback(async (e)=>{
        (0,utility.fireGlobalEvent)(e, props._LocalEventEmitter);
        setIsPopupVisible(true);
    });
    const carouselItems = [
        {
            backgroundImageDesktop: "url(/img/internal/altsound.png)",
            backgroundImageMobile: "url(/img/internal/altsound.png)",
            title: "Alternate Sound",
            date: "NOV 04, 2023 | 06:00 PM EST"
        },
        {
            backgroundImageDesktop: "url(/img/internal/tinycafe.jpeg)",
            backgroundImageMobile: "url(/img/internal/tinycafe.jpeg)",
            title: "A NIGHT WITH SEWA 2",
            date: "OCT 23, 2023 | 08:00 PM EST"
        }
    ];
    const receiveData = (data)=>{
        console.log("data", data);
        setEvetsData(data.data.fetchedData[0].productReq);
    };
    /*#__PURE__*/ jsx_runtime.jsx(fetch.FetchHandler, {
        ...props,
        handlerName: "my_handler",
        handlerArgs: [
            {
                productReq: [
                    "1da050fa-6be1-4926-9e10-cf0a9ee575a8",
                    "68f37cef-a4f8-40d2-96aa-cdf57b0a220a"
                ]
            }
        ],
        receiveData: receiveData
    });
    (0,external_react_.useEffect)(()=>{
        const handleResize = ()=>{
            const isMobile = window.innerWidth <= 768;
            const backgroundImage = isMobile ? carouselItems[currentIndex].backgroundImageMobile : carouselItems[currentIndex].backgroundImageDesktop;
            const carouselItem = document.querySelector(`#carousel-item-${currentIndex}`);
            if (carouselItem) {
                carouselItem.style.backgroundImage = backgroundImage;
            }
        };
        window.addEventListener("resize", handleResize);
        handleResize();
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, [
        currentIndex,
        carouselItems
    ]);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(external_react_responsive_carousel_.Carousel, {
                selectedItem: currentIndex,
                onChange: handleCarouselChange,
                showThumbs: false,
                showArrows: true,
                showStatus: false,
                interval: 3000,
                children: props.data.map((item, index)=>{
                    var _item_styles_, _item_styles__option_, _item_styles_1, _item_detailmeta, _item_detailmeta_eventDateDef;
                    /*#__PURE__*/ return (0,jsx_runtime.jsxs)("div", {
                        id: `carousel-item-${index}`,
                        className: "flex flex-col justify-end relative w-full min-h-[520px] lg:min-h-[700px] max-w-full",
                        style: {
                            backgroundSize: "cover",
                            objectFit: "cover",
                            backgroundRepeat: "no-repeat",
                            textAlign: "left",
                            backgroundImage: item.backgroundImageDesktop
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                className: "absolute inset-0 bg-black min-h-[700px] opacity-10"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                className: "self-end w-full px-4 lg:px-8 py-12 pb-12 bg-gradient-to-b from-transparent to-black z-20",
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                        className: "text-5xl lg:text-8xl font-bold",
                                        children: item.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "flex gap-4 mt-4 items-center",
                                        children: [
                                            item.styles[0].price <= 0 ? /*#__PURE__*/ jsx_runtime.jsx("button", {
                                                onClick: handleFreeTicketClaim,
                                                className: "bg-orange-800 text-white rounded-md px-4 py-4 text-xs lg:text-xl",
                                                children: "Claim free ticket"
                                            }) : /*#__PURE__*/ (0,jsx_runtime.jsxs)("button", {
                                                onClick: handleTicketClaim,
                                                item: item.id,
                                                selectedstyle: (_item_styles_ = item === null || item === void 0 ? void 0 : item.styles[0]) === null || _item_styles_ === void 0 ? void 0 : _item_styles_.sid,
                                                currentoption: (_item_styles__option_ = (_item_styles_1 = item === null || item === void 0 ? void 0 : item.styles[0]) === null || _item_styles_1 === void 0 ? void 0 : _item_styles_1.option[0]) === null || _item_styles__option_ === void 0 ? void 0 : _item_styles__option_.sid,
                                                action: "buy",
                                                className: "bg-orange-800 text-white rounded-md px-4 py-4 text-xs lg:text-xl",
                                                children: [
                                                    "Buy Livestream $",
                                                    item.styles[0].price
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "lg:text-xl text-white",
                                                children: convertTimestamp((_item_detailmeta = item.detailmeta) === null || _item_detailmeta === void 0 ? void 0 : (_item_detailmeta_eventDateDef = _item_detailmeta.eventDateDef) === null || _item_detailmeta_eventDateDef === void 0 ? void 0 : _item_detailmeta_eventDateDef.dates[0])
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }, index);
                })
            }),
            isPopupVisible && /*#__PURE__*/ jsx_runtime.jsx(TicketPopup/* default */.Z, {
                onClose: handlePopupClose
            }),
            showPop && /*#__PURE__*/ jsx_runtime.jsx(features_FreePopUp, {
                onClose: handlePopupClose
            }),
            props.showTimer ? /*#__PURE__*/ jsx_runtime.jsx(CountDown/* default */.Z, {
                eventDate: "2023-11-04T16:00:00Z"
            }) : ""
        ]
    });
};
/* harmony default export */ const features_FeaturedEvent = (FeaturedEvent);

// EXTERNAL MODULE: external "@mui/icons-material/ChevronRight"
var ChevronRight_ = __webpack_require__(2818);
var ChevronRight_default = /*#__PURE__*/__webpack_require__.n(ChevronRight_);
// EXTERNAL MODULE: external "@mui/icons-material/ChevronLeft"
var ChevronLeft_ = __webpack_require__(6959);
var ChevronLeft_default = /*#__PURE__*/__webpack_require__.n(ChevronLeft_);
;// CONCATENATED MODULE: ./customModules/features/Upcoming.jsx




// import { FetchHandler } from '../../modules/utility/fetch';
// import { fireGlobalEvent } from '../../modules/utility/utility';
const events = [
    {
        name: "Afro Fusion Night",
        date: "Nov 15th, 2023",
        venue: "Lagos, Nigeria",
        img: "/img/internal/sharon5.png"
    },
    {
        name: "Safari Beats Live",
        date: "Dec 05th, 2023",
        venue: "Nairobi, Kenya",
        img: "/img/internal/sharon6.png"
    },
    {
        name: "Jungle Groove Party",
        date: "Oct 25th, 2023",
        venue: "Cape Town, South Africa",
        img: "/img/internal/sharon7.png"
    },
    {
        name: "Desert Rhythms Concert",
        date: "Nov 10th, 2023",
        venue: "Marrakech, Morocco",
        img: "/img/internal/sharon8.png"
    },
    {
        name: "Savannah Soundscape Live",
        date: "Dec 20th, 2023",
        venue: "Nairobi, Kenya",
        img: "/img/internal/sharon5.png"
    }
];
{}const Upcoming = ()=>{
    const scrollRef = (0,external_react_.useRef)(null);
    const smoothScroll = (distance)=>{
        const container = scrollRef.current;
        const startScrollPosition = container.scrollLeft;
        const targetScrollPosition = startScrollPosition + distance;
        let start = null;
        const duration = 500;
        const animate = (timestamp)=>{
            if (!start) start = timestamp;
            const progress = timestamp - start;
            const timeFunction = Math.sin(progress / duration * (Math.PI / 2));
            const currentDistance = timeFunction * distance;
            container.scrollLeft = startScrollPosition + currentDistance;
            if (progress < duration) {
                requestAnimationFrame(animate);
            }
        };
        requestAnimationFrame(animate);
    };
    const scroll = (direction)=>{
        const distance = direction === "left" ? -350 : 350;
        smoothScroll(distance);
    };
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full mb-12 mt-12 relative px-2 lg:px-8",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                className: "text-2xl font-bold",
                children: "Coming Up"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "flex gap-8 w-full overflow-x-auto relative no-scrollbar pt-8",
                ref: scrollRef,
                children: events.map(({ img , date , venue , name  }, id)=>/*#__PURE__*/ jsx_runtime.jsx(Event, {
                        img: img,
                        date: date,
                        venue: venue,
                        name: name
                    }, id))
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "hidden lg:flex absolute top-1/2 transform -translate-y-1/2 left-0 right-0 justify-between px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("button", {
                        className: "bg-gray-500 p-2 rounded-full opacity-70 hover:opacity-100",
                        onClick: ()=>scroll("left"),
                        children: /*#__PURE__*/ jsx_runtime.jsx((ChevronLeft_default()), {})
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("button", {
                        className: "bg-gray-500 p-2 rounded-full opacity-70 hover:opacity-100",
                        onClick: ()=>scroll("right"),
                        children: /*#__PURE__*/ jsx_runtime.jsx((ChevronRight_default()), {})
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const features_Upcoming = (Upcoming);
const Event = ({ img , name , venue , date  })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "min-w-[300px] min-h-[400px] lg:min-w-[339px] lg:min-h-[480px] inset-0 rounded-2xl overflow-hidden relative transform transition-transform duration-300 hover:-translate-y-1.5 flex flex-col justify-end items-center pb-12 hover:bg-black/40",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "absolute rounded-2xl inset-0 bg-cover bg-center transform transition-transform duration-300 transition-filter hover:filter[blur(10px)]",
                style: {
                    backgroundImage: `url(${img})`
                }
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "absolute top-0 left-0 mt-4 ml-4 bg-orange-300 rounded-md px-3 py-3 text-black",
                children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                    className: "text-xs",
                    children: date.slice(0, 6)
                })
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "absolute inset-0 bg-black opacity-40 transition-opacity hover:opacity-20"
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "z-10 relative text-orange-300",
                children: [
                    " ",
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        className: "text-lg lg:text-2xl font-black",
                        children: name
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        className: "text-lg lg:text-xl font-black",
                        children: venue
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./customModules/features/Marquee.jsx



const MarqueeComponent = ()=>{
    return /*#__PURE__*/ _jsx(Marquee, {
        children: "Hello world let this slide"
    });
};
/* harmony default export */ const features_Marquee = ((/* unused pure expression or super */ null && (MarqueeComponent)));
const Marquee_Event = ()=>{
    return /*#__PURE__*/ _jsx("div", {});
};

// EXTERNAL MODULE: ./customModules/features/Footer.jsx
var Footer = __webpack_require__(9021);
// EXTERNAL MODULE: ./customModules/features/Skeleton.jsx
var Skeleton = __webpack_require__(4884);
;// CONCATENATED MODULE: ./customModules/features/HomeDash.jsx












const HomeDash = (props)=>{
    const [eventsData, setEventsData] = external_react_default().useState([]);
    const [isLoading, setIsLoading] = external_react_default().useState(true);
    const receiveData = (data)=>{
        console.log("data", data);
        setEventsData(data.data.fetchedData[0].productReq);
        setIsLoading(false);
        console.log("events", eventsData);
    };
    const handleFireGlobalEvent = external_react_default().useCallback(async (e)=>{
        (0,utility.fireGlobalEvent)(e, props._LocalEventEmitter);
    });
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "w-full h-full pb-8 ",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(feature.Feature, {
                ...props,
                hideToggle: true,
                defaultSize: "large"
            }),
            isLoading ? /*#__PURE__*/ jsx_runtime.jsx(Skeleton/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime.jsx(features_FeaturedEvent, {
                ...props,
                data: eventsData
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "relative",
                children: /*#__PURE__*/ jsx_runtime.jsx(features_Upcoming, {})
            }),
            /*#__PURE__*/ jsx_runtime.jsx(features_EventsGrid, {}),
            /*#__PURE__*/ jsx_runtime.jsx(fetch.FetchHandler, {
                ...props,
                handlerName: "my_handler",
                handlerArgs: [
                    {
                        productReq: [
                            "1da050fa-6be1-4926-9e10-cf0a9ee575a8",
                            "68f37cef-a4f8-40d2-96aa-cdf57b0a220a"
                        ]
                    }
                ],
                receiveData: receiveData
            })
        ]
    });
};
/* harmony default export */ const features_HomeDash = (HomeDash);
// {
//     "productReq": [
//         {
//             "__typename": "Product",
//             "id": "b208c40c-6503-491a-a0ca-f1ce85d02d17",
//             "shop": "3cf7daaa-f81f-4d69-b9ba-deb574f7cff9",
//             "name": "Yesy",
//             "owner": "201198a1-4554-4cc5-8677-8f047967ca65",
//             "detailmeta": {
//                 "productType": "virtual",
//                 "ticket": true,
//                 "livestream": true,
//                 "livestreamDef": {
//                     "dates": [],
//                     "tags": [
//                         "testtag"
//                     ],
//                     "input": "testtag"
//                 },
//                 "eventDateDef": {
//                     "dates": [
//                         "2023-10-28T04:00:00.000Z"
//                     ],
//                     "input": "oct28-2023",
//                     "tags": []
//                 }
//             },
//             "styles": [
//                 {
//                     "price": 0,
//                     "sid": "0441f2a2-4f6c-47b6-bb42-831708287de7",
//                     "style": "",
//                     "option": [
//                         {
//                             "sid": "70756244-2924-48b1-898f-eb7e4228b5cb",
//                             "quantity": 1
//                         }
//                     ]
//                 }
//             ],
//             "shipping": [],
//             "published": true,
//             "created": "2023-10-16 00:16:37.795 +00:00",
//             "publish": "2023-10-16 00:16:37.675 +00:00",
//             "images": [
//                 {
//                     "orig": "2cd7b55d-9dcb-45d6-8af3-72df429b610e.png",
//                     "name": "product/a1a1d734c62b4224a9aa1ba14574e1af.png"
//                 }
//             ],
//             "protype": {
//                 "type": "virtual"
//             },
//             "infinite": false,
//             "meta": {},
//             "files": {}
//         },
//         {
//             "__typename": "Product",
//             "id": "bed6d9f6-7760-4d70-82fc-badd7d43635a",
//             "shop": "3cd25c67-ce17-4e82-92b2-6435ecc7d94d",
//             "name": "Test 1",
//             "owner": "ff53b78e-fcc5-4b85-a8c7-4708b29ce187",
//             "detailmeta": {
//                 "productType": "virtual",
//                 "ticket": true,
//                 "livestream": true,
//                 "livestreamDef": {
//                     "dates": [],
//                     "tags": [],
//                     "input": ""
//                 },
//                 "eventDateDef": {
//                     "dates": [],
//                     "input": ""
//                 }
//             },
//             "styles": [
//                 {
//                     "price": 0,
//                     "sid": "5029056c-ee0c-4afa-9421-5e83d31b4a3c",
//                     "style": "",
//                     "option": [
//                         {
//                             "sid": "178c3ce7-a84a-4ec4-b9ed-8f83ca56a2d6",
//                             "quantity": 100
//                         }
//                     ]
//                 }
//             ],
//             "shipping": [],
//             "published": true,
//             "created": "2023-10-15 23:47:42.540 +00:00",
//             "publish": "2023-10-15 23:47:42.438 +00:00",
//             "images": [
//                 {
//                     "orig": "ff304e38-17c7-4a38-ab8c-e6e3bc9b337e.jpeg",
//                     "name": "product/5c58ab9b36a848acb5fc2a3c453a0a21.jpeg"
//                 },
//                 {
//                     "orig": "14322913-0f42-4bed-9c64-fefa250f6f8f.jpeg",
//                     "name": "product/1579960792a34255a4c1814de9c02424.jpeg"
//                 },
//                 {
//                     "orig": "f863f926-3d35-41f8-abc7-2bb4c6c1f5bb.jpeg",
//                     "name": "product/8fdd3777de9242ef8704fe61c0bffbba.jpeg"
//                 }
//             ],
//             "protype": {
//                 "type": "virtual"
//             },
//             "infinite": false,
//             "meta": {},
//             "files": {}
//         }
//     ]
// }
{
/* <MarqueeComponent /> */ }{
/* <Footer /> */ }{
/* <SliderBasic items={items} /> */ }{
/* <button
        onClick={handleFireGlobalEvent}
        item={'b208c40c-6503-491a-a0ca-f1ce85d02d17'}
        selectedstyle={'0441f2a2-4f6c-47b6-bb42-831708287de7'}
        currentoption={'70756244-2924-48b1-898f-eb7e4228b5cb'}
        action='add_to_cart'
      >
        Add To Cart
      </button> */ }
;// CONCATENATED MODULE: ./customModules/features/Privacy.jsx


const PrivacyContent = ()=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "pt-[20px] px-4 h-full",
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "max-w-4xl mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
                class: " p-4 ",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h1", {
                        class: "text-2xl font-semibold mb-4",
                        children: "FIDIO PRIVACY POLICY"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Effective as of January 15, 2023 (Publication Date September 16, 2023)"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "Thank you for visiting Fidio. Your privacy is important to us. This privacy policy ('Privacy Policy') describes how we, our affiliated and associated entities, as further detailed below (collectively 'Fidio', 'we', 'us', and 'our'), collects, uses, discloses, transfers, stores, retains, or otherwise processes your personal data, and the choices you can make about the way your information is collected and used by Fidio. Please review our Privacy Policy as it may change in the future and contact us at",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "mailto:privacy@fidio.ca",
                                        class: "text-blue-500",
                                        children: "privacy@fidio.ca"
                                    }),
                                    " ",
                                    "or the correspondence address below if you have any questions or concerns or wish to exercise your privacy rights."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "It’s your right to:"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                class: "list-disc pl-6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Be informed about how we process your personal data."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "We provide this information through our Privacy Policy, our Services, and by answering your questions when you contact us."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Access your personal data."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You can ask whether we process your personal data, and if we do, you can ask for a copy of your personal data and for information on certain other aspects of the processing, including: the purposes of the processing; categories of the personal data processed; recipients or categories of recipients of the data; source of the data where we have not received your data directly from you; information about the existence of automated decision-making or profiling; and information about other privacy rights you have in relation to your personal data."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Rectify inaccurate or incomplete personal data."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                children: [
                                                    "You may correct some categories of your personal data yourself in your account settings or contact",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "mailto:privacy@fidio.ca",
                                                        class: "text-blue-500",
                                                        children: "privacy@fidio.ca"
                                                    }),
                                                    "."
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Deletion (erasure) of your personal data."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You have the right to ask us to delete your personal data under certain circumstances, including:"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                class: "list-disc pl-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "Your personal data are no longer necessary in relation to the purposes for which we have collected them;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "You withdraw your consent to processing of your personal data and there is no other legal ground for the processing;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "You object to the processing and there are no overriding legitimate grounds for the processing or when you object to the processing of your data for direct marketing purposes;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "Your personal data were unlawfully processed by us;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "The erasure is mandated under a law to which we are subject;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "We have collected the personal data of a child."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "Please know that you may also delete certain personal data by yourself in your Fidio account. You may also delete your folders, playlists, playlist descriptions, remove tracks from your playlists or remove added artists and other content from your library. Under some circumstances, we are legally not required to comply with a deletion request."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                children: [
                                                    "In order to delete the personal data associated with your account, please contact",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "mailto:privacy@fidio.ca",
                                                        class: "text-blue-500",
                                                        children: "privacy@fidio.ca"
                                                    }),
                                                    " ",
                                                    "or visit Settings within the FIDIO app followed by Account. Click ‘Delete Account’. Please note, you must first cancel your existing subscription before being allowed to delete all of the personal information associated with your account. Please contact our support team at",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "mailto:privacy@fidio.ca",
                                                        class: "text-blue-500",
                                                        children: "privacy@fidio.ca"
                                                    }),
                                                    " ",
                                                    "with any questions or concerns about this process."
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Restriction of processing of your personal data."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "Under certain circumstances, you may request that we stop processing some or all of your personal data temporarily. You may request the restriction of processing if:"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                class: "list-disc pl-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "You have contested the accuracy of your personal data for the period of verification of the accuracy of your personal data;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "When we unlawfully processed your personal data and instead of erasure of such data you request restriction of their use;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "When we no longer need your personal data in relation to the purposes for which they were collected but you require such data for the establishment, exercise or defense of legal claims;"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "When you have objected to the processing, pending the verification on our end whether our legitimate grounds override your interests."
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Data Portability."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You have the right to receive a copy of your personal data in a machine-readable (electronic) format and to have it sent to another service provider, if our legal basis for processing your personal data is your consent or performance of contract."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Object."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You have the right to object to the processing of your personal data on certain grounds:"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                class: "list-disc pl-6",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        children: "When we process your personal data for our or third party’s legitimate interests. When we receive your request on this ground, we will no longer process your personal data for such purposes, unless we demonstrate that we have compelling legitimate grounds to continue processing your personal data for these purposes, which override your interests, rights, and freedoms or where we need to process such data for the establishment, exercise, or defense of legal claims."
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                                        children: [
                                                            "When we process your data for direct marketing purposes. You can also object at any time that we process your personal data for direct marketing purposes. If you object, we will no longer process your data for such purposes. You may change your preferences and opt out from receiving some or all of these types of direct marketing communications in your FIDIO account settings, or you may contact us through the contact points provided in this Privacy Policy (",
                                                            /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                                href: "mailto:privacy@fidio.ca",
                                                                class: "text-blue-500",
                                                                children: "privacy@fidio.ca"
                                                            }),
                                                            " ",
                                                            "or our correspondence address below). You may also unsubscribe from our marketing emails by clicking on the unsubscribe link provided in such emails."
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Not be subject to automated decision-making."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You have the right not to be subject to a decision based solely on automated processing (i.e., decisions made by machines without human involvement), including profiling, which would produce legal effects or similarly affect you significantly. Our processing of your data does not involve this type of automated decision-making."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Withdraw consent."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "Where we rely on your consent to process your personal data for a particular purpose, you may withdraw your consent at any time. If you withdraw your consent, we will stop processing your personal data for the specific purpose or purposes requested. This does not affect the lawfulness of processing of your data before you have revoked the consent."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        class: "mb-2",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Register a complaint."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "If you reside in applicable jurisdictions, you are entitled, per local data protection law, to contact your local authorities regarding any question, concern, or complaint you have relating to our processing of your personal data."
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                class: "text-base font-semibold",
                                                children: "Non-discrimination."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                children: "You have the right to not be discriminated against if you exercise any of your privacy rights. We will not discriminate against you or deny, charge different prices for, or provide a different quality of our Services if you choose to exercise these rights, although some functionality and features on the Services may change or no longer be available to you."
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                            children: [
                                "You can request to exercise any of your privacy rights with an email to",
                                " ",
                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                    href: "mailto:privacy@fidio.ca",
                                    class: "text-blue-500",
                                    children: "privacy@fidio.ca"
                                }),
                                " ",
                                "with our customer service support contact form, or by writing to the correspondence address below. Please note that when you make a request to exercise your rights, we may require that you provide information and follow procedures so that we can verify your identity. Where possible, we will attempt to match the information that you provide in your request to information we already have to verify your identity. If we are able to verify your request, we will process it. We will assess any request to exercise these rights on a case-by-case basis. We will respond to your request within the periods required by applicable data protection law. However, we may not always be able to comply fully with your request, and we will notify you in that event."
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                            children: "For the purposes of this Privacy Policy, Fidio Technologies Inc. d/b/a ‘Fidio’ is the ‘controller’ of your personal data. Fidio Technologies Inc. is registered as a Corporation in Canada, with headquarters located at 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada."
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: /*#__PURE__*/ jsx_runtime.jsx("p", {
                            children: "The correspondence address for FIDIO is 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada. As the controller Fidio decides why and how your personal data are handled by FIDIO when you use our services ('Services')."
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "FIDIO is responsible for handling your data according to applicable data protection rules."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Our policy is to process your personal data in accordance with applicable data protection laws and regulations. This Privacy Policy is separate from FIDIO’s Terms of Use ('Terms'), which govern your use and access to FIDIO Services."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "This Privacy Policy applies when: you register a FIDIO account; you log in and use FIDIO’s content and streaming services; you download and/or use FIDIO clients (e.g., FIDIO mobile applications, desktop player, web player, or other technical interfaces provided by FIDIO); your personalization of your user experience; you visit or interact with our websites and fan pages on social networks; our websites, services, communications, or documents refer to this Privacy Policy; you interact with us in any other way, such as when you contact our customer support service, respond to our surveys, participate in our competitions and giveaways, use our developer platform, and other communications. This Privacy Policy collectively refers to the above as processing of your data in the context of provision of our Services."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "The Personal and Other Information We Collect"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "At FIDIO and FIDIO websites, you can order products, express an opinion, create playlists, and subscribe to services such as online newsletters and paid streaming. The types of personally identifiable information that may be collected at these pages include your: name, FIDIO account, user and profile data (including privacy and marketing settings), address, location, e-mail address, telephone number, fax number, contact preferences, credit card and other payment information, Internet protocol address, date of birth, gender, Facebook, Twitter, Google or Apple user identifiers, and details of how you use and interact with our websites and Services (e.g., your search queries, login data, playlists, device information, network connection type, a record of customer service emails, consumption data, listening behavior, surveys, sweepstakes and competitions entered, etc.)."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "FIDIO may process information about you related to: identification data and contact data; account data; subscription data; payment and billing data; usage data; login data; device data; network data, marketing data; personal data processed in the context of customer support; personal data processed in the context of surveys, interviews and user-testing; personal data processed in the context of competitions and sweepstakes; personal data processed about you in the context of your interaction with our fan pages on social media networks."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "At certain parts of some of our Services and websites, only persons who provide us with the requested personally identifiable information will be able to order products, programs, and services or otherwise participate in the Service or and/website's activities and offerings. We may draw inferences from any of the information we gather via our websites and Services, including about your preferences. We do not deliberately collect sensitive personal data and would not use any such information except for the purposes for which it is collected and as authorized by law."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may also receive information about you from third parties that may have collected and transferred your personal data to us in accordance with their own privacy policies and/or terms of use. When we receive such information from third parties, we may combine it with the other personal data that we have collected about you as set out in this Privacy Policy and use such information either alone or in combination with the other personal data we hold."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We also may collect certain non-personally identifiable information when you visit many of our web pages such as the type of browser you are using (e.g., Safari, Internet Explorer), the type of operating system you are using and information about your Internet service provider (e.g., Comcast, AT&T) or device (e.g., iPhone X, MacBook Pro) and other user-related general data (e.g., zip code, area code)."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "How We Use the Information We Collect"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may use the information you provide about yourself to fulfill your requests for our products, programs, and services, to respond to your inquiries about our offerings, and to offer you other products, programs or services that we believe may be of interest to you. We sometimes use this information to communicate with you, such as to notify you when a concert you have purchased is available for download, to fulfill a request by you for an online newsletter, or to contact you about your account with us. If you enter into a giveaway, contest or other promotion, we may use the information you provide to administer those programs."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "The information we collect in connection with our website is used to provide an interactive experience. We use this information to facilitate participation in these online forums and communities and, from time to time, to offer you new products, programs, or services. As is the case with most Internet services, we obtain some information automatically and store it in log files. We use this and other information to understand and analyze trends, to administer the site, to learn about user behavior on the site, to improve our products and services, and to gather generalized demographic information about our users. We may use this information to market and advertise our products and services."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "When we process your personal data, we do so because we have specific and defined reasons as well as a legal justification to do so."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                class: "list-disc pl-6",
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                children: "Consent:"
                                            }),
                                            " When you have given us your free, informed, unambiguous consent to process your personal data for a specific purpose. You are free to withdraw your consent at any time;"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                children: "Performance of Contract:"
                                            }),
                                            " When you request our products and/or Services and we need to process your personal data to deliver these Services according to our Terms;"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                children: "Legal Obligation:"
                                            }),
                                            " When we are subject to different legal or regulatory obligations in jurisdictions where we operate, which require that we process certain personal data for specific purposes;"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("li", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                                children: "Legitimate Interests:"
                                            }),
                                            " When we or a third party have legitimate interests to process your personal data for various purposes that benefit FIDIO or third parties, such as other FIDIO users. Prior to relying on this legal basis, we balance the benefits of processing for FIDIO or third parties against your interests, rights and freedoms to determine if we can rely on this legal basis."
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may collect, share, use or otherwise process personal data about you for various purposes, including providing our Services and products, payment and billing, personalization, improvement of our websites, Services and products, analytics, troubleshooting, testing, calculating royalty payments, marketing, compliance with legal obligations, enforcement of Terms and policies, addressing misuse and unlawful activity, establishment and defense of legal claims, fulfilling contractual obligations, conducting surveys and user-testing, enabling your participation in our FIDIO subscription service and special offers, providing customer support, and communication on social networks."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "You are not required to provide any personally identifiable information that we have requested, but if you choose not to do so, in many cases we will not be able to provide you with our products or services or respond to any questions you may have."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We sometimes use the non-personally identifiable information that we collect to improve the design and content of our site and to enable us to personalize your Internet experience. We also may share non-personally identifiable information publicly and with our partners and use this information in the aggregate to analyze site usage, as well as to offer you products, programs, or services."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We share your data with third parties if you give us permission, if it is necessary for the performance of the contract we have with you, or if we have a legitimate interest for such sharing. We may receive and share information with our business partners, including third parties such as an artist, promoter, venue, sponsor, and/or strategic marketing and advertising partners."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: "p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Our business partners use the information we give them as described in their privacy policies, which may include sending you marketing communications."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "You should read those policies to learn how they treat your information. We may share information with our affiliates and group companies; our processors and service providers; third-party applications, services and platforms (including audio devices, smart TVs, cars, voice assistants, etc.); payment service providers; advertising and analytics service providers; auditors and other third party accounting services; and any purchaser or successor to all or part of our business. For example, if part of our business is sold we may give our customer list as part of that transaction."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may disclose personally identifiable information in response to legal process (e.g. in response to a court order or a subpoena), public authorities or to enforce applicable Terms, including investigation of potential violations. We also may disclose such information to detect, prevent or otherwise address fraud, intellectual property violations, security or technical issues, to protect our operations or users, or to respond to a law enforcement agency's request. Additionally, in the event of a reorganization, merger or sale we may transfer any and all information we collect to the relevant third party."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may de-identify your data and combine and aggregate your de-identified information with other information in a way that it no longer enables your identification and share that de-identified, aggregated information with other third parties not mentioned above – for example, with artists or content rights holders whose content we license. Such de-identified and aggregated statistics may include demographic data, such as how many users constitute a particular age group, general locations of where groups of users reside and similar data."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Agents and contractors of FIDIO who have access to personally identifiable information are required to protect this information in a manner that is consistent with this Privacy Policy by, for example, not using the information for any purpose other than to carry out the services they are performing for FIDIO."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Although we take appropriate measures to safeguard against unauthorized disclosures of information, we cannot assure you that personally identifiable information that we collect will never be disclosed in a manner that is inconsistent with this Privacy Policy."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Finally, FIDIO websites will not use or transfer personally identifiable information provided to us in ways unrelated to the ones described above without also providing you with an opportunity to opt out of these unrelated uses. For example, if you don’t want to be on our mailing list, you can opt out by updating your settings or contacting us at privacy@fidio.ca"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: "p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Cookies"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: 'To enhance your experience with our website, many of our web pages use "cookies." Cookies are text files we place in your computer\'s browser to store your preferences. Cookies, by themselves, do not tell us your e-mail address or other personally identifiable information unless you choose to provide this information to us by, for example, registering at our site. However, once you choose to furnish the site with personally identifiable information, this information may be linked to the data stored in the cookie.'
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We use cookies to understand site usage and to improve the content and offerings on our site. For example, we may use cookies to personalize your experience at Fidio.ca (e.g. to recognize you by name when you return to our site), save your password in password-protected areas, and enable you to use shopping carts on our website."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "You may also set your browser to block all cookies, including cookies associated with our services, or to indicate when a cookie is being set by us. However, many of our services may not function properly if your cookies are disabled."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: "p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Social Media Networks"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We use various usage and insight tools offered by the operators of social media networks, through which we can view general, anonymized statistics about our fan pages, such as interactions and reach of our posts and demographic information about our fan page visitors (e.g. age, gender, region). We can optimize the content we offer on our fan pages on that basis. Whenever you interact with our fan pages, operators of the social networks use cookies and similar technologies to track the usage behavior of fan page visits. This information is collected regardless of whether you are a logged-in user of the particular social network or not. On that basis, we receive various insights from the operators of social networks."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We do not have access to the personal data which the operators of social networks use to create such insights. The selection and processing of your data for insights is performed exclusively by the operators of social networks. However, in some cases, when using these usage analysis and insight tools, we are jointly responsible ('joint controllers') with the operators of the social networks for processing your data to the extent indicated below."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "When you visit our profile or fan pages on Facebook and Instagram (each the 'Social Media Network'), the Social Media Network and FIDIO act as joint controllers with respect to the collection of your data and the creation of insights. We have entered into joint controller terms with each Social Media Network to govern the relationship between FIDIO and the Social Media Network with respect to this processing. The Social Media Network is the primary controller for the collection of your data that is used for the creation of insight reports. The Social Media Network is therefore responsible for enabling your privacy rights in line with the applicable privacy laws. More information on how the Social Media Network processes your personal data, including the legal basis the Social Media Network relies on and the ways to exercise privacy rights against the Social Media Network, can be found in each Social Media Network's own Privacy Policy (Facebook, Instagram, etc.)."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "When you visit our Twitter or YouTube profiles, Twitter as the operator of Twitter or Google as the operator of YouTube, as relevant, collects and processes your personal data to the extent described in their privacy policies. Through statistics, we receive anonymized information from Twitter and Google – for example about the number of our Twitter and YouTube profile visits, about how successful our posts are or about what interests our followers pursue. Please refer to the Twitter and YouTube privacy policies for further information on how they process your personal data."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Note that when you visit our fan pages, the operators of social media process your data also for their own purposes, which are not covered in this Privacy Policy. We have no influence over the data processing operations of third parties. In this regard, we refer you to the privacy policy of the respective social network."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: "p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Links to Third Party Sites or Services"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We may link to third party sites or services we don't control. If you click on one of those links, you will be taken to websites we do not control. This policy does not apply to the privacy practices of those websites. Read the privacy policy of these other websites carefully. We are not responsible for these third-party websites. Our site may also serve third-party content that contains their own cookies or tracking technologies. We do not control the use of those technologies."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We do not track our customers across third-party websites; however, some third-party sites do keep track of your browsing activities when they provide you content, which allows them to determine what they present to you. If you are visiting such sites, your browser should allow you to set the Do Not Track (DNT) signal so that third parties know you do not want to be tracked. Third parties that have content embedded on FIDIO websites may set cookies on a user's browser and/or collect information about the fact that a web browser visited a specific FIDIO website from a certain IP address. Third parties cannot obtain any other personally identifiable information from FIDIO's websites unless you provide it to them directly. Information collected by third parties is governed by their privacy practices."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "FIDIO offers interactive services that allow you to post content to share publicly or with friends. At any time, you can contact privacy@fidio.ca to delete or remove content you have posted using the deletion or removal options within our service. Although we offer deletion capability for our services, please be aware that the removal of content may not ensure complete or comprehensive removal of that content or information posted through the services."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Information You Choose to Make Public"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Certain information will be public on our websites and Services as part of your user experience including your user name, and any public interactions you initiate on our websites or Services including posting reviews, playlists, identifying favorite artists or performances, etc. The extent of your information visible to others on our websites and Services will depend on the information you choose to share. You can change or delete some of the information you provide. If you use another third party service or website to authenticate to our Services we will receive your first and last name and profile information from these third parties and this information will be saved automatically in your FIDIO account along with your user name and data. You can also edit or delete this information."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "You may be able to create public playlists on our Services. Your public playlists will appear in your user data, will be searchable on our Services and other FIDIO users can access and use them. You and other FIDIO users may be able to share user playlists and information via a shareable link or via third-party social networks or messaging platforms. You can change the privacy of your playlists at any time. If you change your public playlist to a private setting, it will no longer be searchable on our Services or appear in any public user data. Please be aware that if other FIDIO users access a previously public playlist, subsequent changing of the playlist to a private setting will not automatically remove the playlist for such other users. If you shared your public or private playlist through a shareable URL link or with other FIDIO users and they added such a playlist, at present you can only remove the playlist from their collections by their deleting it."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Children’s Personal Data"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Our Services and their content are not directed at children under the age of 13. We do not knowingly collect or solicit any personal data from children under the age of 13 or knowingly allow such persons to register for our Services. If you are under the age of 13, please do not use our Services, do not browse our websites and do not send us any of your personal data. If we learn that we have collected personal data from a child under the age 13, we will promptly delete that information, in accordance with applicable law. If you are a parent or guardian and believe that we may have collected personal data from your child, please notify us immediately by sending an email to privacy@fidio.ca. If you are 13 – 18 years of age, you may use our Services according to our Terms in appropriate circumstances. We reserve the right to limit access to our Services for children aged 13 – 18 years if their use of our Services or processing of personal data would be illegal or would require a consent of a parent or guardian, according to law applicable in their country of residence. Do not play or recommend any inappropriate content to individuals under 18 years old."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        class: " p-4 shadow rounded-lg mb-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                class: "text-lg font-semibold mb-2",
                                children: "Data Retention, Deletion and Anonymization"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                        children: "Data Retention."
                                    }),
                                    " We will keep your personal data only for the period necessary to fulfil the purposes for which we collect and process your personal data, as described in this Privacy Policy and in accordance with applicable law. This means that the retention periods will vary according to the data category and the purpose we have to process your personal data. The retention periods for data are determined on a case-by-case basis that depends on various factors."
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: "The nature of the personal data and why it is collected and processed. The length of time we will keep your personal data will generally be determined by how long we need that information to provide you with our Services and to provide customer support. For example, as set out in this Privacy Policy, we require account data to deliver our Services. We need to keep it for the duration your FIDIO account exists so that we can maintain your account. Similarly, we will keep some of your usage data, such as your playlists or folders for the lifetime of your account;"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: "For so long as we are required by law to do so. We are subject to various legal obligations in countries in which we operate, such as bookkeeping, accounting, tax or audit obligations, which require that we keep certain data for specified periods. For example, we will keep your information in accordance with applicable law and where we have a legal obligation to do so;"
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: "Other factors as required by law and our legitimate interests. We may keep certain data for the establishment, exercise, or defense of legal claims, to deal with and resolve requests, disputes or complaints, for litigation or regulatory matters, and for the safety, security, and integrity of our Services, among other reasons."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("strong", {
                                        children: "Data Deletion and Anonymization."
                                    }),
                                    " Subject to applicable law, after the lapse of the retention periods, we will delete or permanently anonymize your personal data so that it is no longer capable of identifying you. If you request that we delete your FIDIO user account, we will treat your FIDIO account deletion request as a request for erasure (deletion) of your personal data and we will delete or anonymize your personal data, so that it no longer identifies you, in accordance with applicable law. Depending on the jurisdiction in which you reside, there may be circumstances in which we retain your personal data for lawful reasons after receiving a deletion request, for example if certain legal obligations apply or if there are unresolved issues or claims relating to your FIDIO user account or your use of our Services."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "data-retention-security",
                        class: "p-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                children: "Data Retention, Deletion and Anonymization"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We have compelling legitimate grounds to retain some of your personal data that overrides your interests in having your data deleted (e.g., for fraud prevention purposes, to enforce our Terms, etc.)."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We cannot verify your identity or confirm that the personal data that we maintain relates to you, or if we cannot verify that you have the authority to make a request on behalf of another individual;"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "There is another exception under the applicable legislation in the country or state of your residence (e.g., exceptions applicable under the California Consumer Privacy Act)."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "In such cases, we will keep limited information about you in a protected form for the period necessary to fulfil processing under the applicable exception."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "commitment-to-security",
                        class: "p-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                children: "Our Commitment to Security"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We have put in place appropriate physical, electronic, and managerial procedures to safeguard and help prevent unauthorized access, maintain data security, and correctly use the information we collect online."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We use standard security measures in place to protect your information. These measures will depend on the type of information collected. However, as the Internet is not guaranteed to be secure, we cannot promise that your use of FIDIO sites and Internet-based services and applications will be completely safe. If you believe that an unauthorized account has been created with your name or identity, contact us at the address below."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "We recommend that you always use strong passwords, that you change them regularly and that you do not use the same passwords for your FIDIO account as you already use to access other services or devices. We also recommend that you always access the Services and make payments from a secure computer or device. Any third-party services that you use to connect to your FIDIO account may also affect your information."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "additional-disclosures",
                        class: "p-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                children: "ADDITIONAL DISCLOSURES FOR INDIVIDUALS RESIDING IN SELECT JURISDICTIONS"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                children: "CANADA"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "This section is relevant if you reside in Canada. FIDIO complies with the Canadian Personal Information Protection and Electronic Documents Act (‘PIPEDA’). This Privacy Policy includes all the necessary disclosures required by the PIPEDA. If you are not satisfied with how we handled your privacy request, please contact admin@fidio.ca and please note you have the right to make a written submission indicating your concerns to the Privacy Commissioner in your jurisdiction or to the Office of the Privacy Commissioner of Canada at the following address: Office of the Privacy Commissioner of Canada, 30 Victoria Street Gatineau, Quebec K1A 1H3.",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "https://www.priv.gc.ca/en",
                                        children: "https://www.priv.gc.ca/en"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                children: "THE EUROPEAN ECONOMIC AREA AND THE UNITED KINGDOM"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "This section is relevant if you reside in any of the European Economic Area countries (the ‘EEA’) or in the United Kingdom (the ‘UK’) and includes disclosures required by the General Data Protection Regulation (GDPR). The GDPR gives you rights as described in this Privacy Policy, which you can exercise through the contacts and methods provided in this Privacy Policy."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "If you are not satisfied with how we handled your request to exercise any of your rights or you have any other questions or concerns about your rights or this Privacy Policy, please contact admin@fidio.ca or send us a letter to our correspondence address as provided in this Privacy Policy."
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "You also have the right to register a complaint with the relevant data protection authority. You may contact your local data protection authority about any questions or concerns you may have.",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "https://www.eeassoc.org/privacy-notice",
                                        children: "Overview of data protection authorities in different EEA countries"
                                    }),
                                    "and the data protection authority for the UK is the Information Commissioner’s Office.",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "https://ico.org.uk/global/contact-us/",
                                        children: "Information Commissioner’s Office"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "As described above in this Privacy Policy, we share your data both internally and with our content providers, affiliates and partners and processors and third-party vendors. Some of these recipients are located in countries outside the EEA and the UK, including in the United States and other countries, whose laws may not provide an equivalent level of protection for your personal data as is the level of protection guaranteed in the EEA and the UK. These transfers are necessary and essential for us to provide our Services to you. Prior to your personal data being shared with third parties, we will take contractual or other steps reasonably necessary to ensure that your personal data is treated securely by such third parties.",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "https://commission.europa.eu/law/law-topic/data-protection/international-dimension-data-protection/standard-contractual-clauses-scc_en",
                                        children: "Standard Contractual Clauses approved by the European Commission"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "amendments-to-privacy-policy",
                        class: "p-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                children: "Amendments to this Privacy Policy"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Our websites and Services are subject to constant improvements, and future changes may influence what personal data we process and how we collect, use, share, store or otherwise process it. We may develop other Services in the future which are currently not mentioned in this Privacy Policy. The Privacy Policy will apply to them accordingly unless stated otherwise upon the launch of the new Services."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "This Privacy Policy may be updated to reflect new changes in our Services, changes in the legal framework, or improvements in how we handle personal data. When we make material changes to the Privacy Policy, we will provide you with notice as appropriate under the circumstances, by sending you an email or notification within a FIDIO client. Unless stated otherwise, our most recent Privacy Policy applies to all information that we process about you."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("section", {
                        id: "contact-us",
                        class: "p-4",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                children: "How to Contact Us"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                children: [
                                    "If you have any questions or concerns about the FIDIO Privacy Policy for this site our Services or its implementation you may contact our Data Protection Office at",
                                    " ",
                                    /*#__PURE__*/ jsx_runtime.jsx("a", {
                                        href: "mailto:privacy@fidio.ca",
                                        children: "privacy@fidio.ca"
                                    }),
                                    " or at the address below:"
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "Fidio Technologies Inc. 95 Kenesky Drive, Toronto ON L8B 1Y3 Canada. Attn: Privacy"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                children: "\xa9FIDIO"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Privacy = (PrivacyContent);

;// CONCATENATED MODULE: ./customModules/doc/privacy.jsx



const privacy_Privacy = (props)=>{
    return /*#__PURE__*/ jsx_runtime.jsx((external_react_default()).Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx(Privacy, {})
    });
};
/* harmony default export */ const privacy = (privacy_Privacy);

;// CONCATENATED MODULE: ./customModules/features/Terms.jsx


const TermsContent = ()=>{
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "pt-[20px] px-4 h-full",
        suppressHydrationWarning: true,
        children: /*#__PURE__*/ jsx_runtime.jsx("div", {
            className: "max-w-4xl mx-auto",
            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                class: " p-4 ",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h1", {
                        class: "text-2xl font-semibold mb-4",
                        children: "FIDIO TERMS OF SERVICE"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "text-sm",
                        children: "Effective as of January 15, 2023"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-4",
                        children: "Thank you for visiting FIDIO’s web site (the “Site”) and for using our products and services (“Services”). The following are the terms of service (“Terms”) that govern the use of the Fidio websites and applications where these Terms appear (collectively, “Site”). Our Privacy Policy and any other policies, rules or guidelines that may be applicable to particular offers or features on the Site are also incorporated into these Terms. By creating an account, viewing content, making a purchase or otherwise visiting or using the Site and our services, you expressly agree to these Terms, as we may update from time to time."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-4",
                        children: "This web page contains our full User agreement (“Agreement”). You may print this document for reference. Limited use of the Site is offered to you by FIDIO subject to, and conditioned upon your acceptance of, these Terms of Service. Your use of the Site constitutes your legally binding acceptance of and agreement to these Terms of Service. Under these Terms of Service only, Fidio grants you a license to view and use the interactive features of this Site. If you do not agree to these Terms of Service, you are not an authorized User and should discontinue any use of the Site and Services."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "AGE OF MAJORITY, RIGHT TO ENTER INTO THIS AGREEMENT"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You represent and warrant to Fidio that you are at least eighteen (18) years old and that you possess the legal right and ability to enter into this Agreement and to use the Site in accordance with this Agreement."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "PRIVACY POLICY"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                        class: "mt-2",
                        children: [
                            "Please review our",
                            /*#__PURE__*/ jsx_runtime.jsx("a", {
                                href: "https://www.fidio.ca/privacy",
                                class: "text-blue-500 hover:underline",
                                children: "privacy policy"
                            }),
                            "which is available at www.fidio.ca/privacy. Fidio’s privacy policy explains how we treat User data and protect your privacy when you use our Services. By using our Services, you agree that Fidio can use such data in accordance with our privacy policies."
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "NOTICE REGARDING FUTURE CHANGES TO TERMS"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "FIDIO reserves the right to change or modify these Terms of Service (including, without limitation, FIDIO’s privacy policy) at any time without notice to you. Please read these Terms of Service carefully, as you are bound to comply with the provisions herein."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "NOTICE REGARDING ARBITRATION AND CLASS ACTION WAIVER"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "The Terms contain an arbitration agreement and class action waiver. Specifically, you and we agree that any dispute or claim relating in any way to the Terms, your use of the Site, or products or services sold, distributed, issued, or serviced by us or through us, will be resolved by binding, individual arbitration, rather than in court. By agreeing to individual arbitration, you and we each waive any right to participate in a class action lawsuit or class-wide arbitration. This agreement and waiver, along with some limited exceptions, is explained in Section 16 below."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "1. Services"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "1.1. General"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "Fidio provides a marketplace for Afro-inspired artists, venues, festivals, and merchants (collectively, “Event Producers”) to offer live-streamed and pre-recorded entertainment events (“Events”) and to sell tickets (“Tickets”) to those Events to consumers (“Attendees”, collectively with Event Producers and other Site visitors, “Users”). In this regard, Fidio acts as an intermediary between Event Producers and Attendees and not an agent or broker of Event Producers. We do not guarantee any number of Tickets that will be available to purchase for an Event, the quality of the experience provided by an Event Producer, or the conduct of any User. We may make changes to the Services at any time, without notice. If you object to the changes, your sole recourse is to stop using the Site. Certain features of the Site may be subject to additional terms."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "1.2. Event Producer Responsibilities"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "1.2.1. Tickets:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "It is your duty as an Event Producer to accurately describe the experience in connection with any Tickets you offer and, by offering a Ticket, you agree that you will provide the experience described. If you fail to provide such experience, you agree to indemnify us and reimburse us for any refunds that we need to issue and damages that we suffer due to your failure. If your Event is postponed or rescheduled, you agree to provide the experience described in the Ticket at such reasonable later date. In the event that you do not provide the experience, we will not remit any payments to you unless and until we are satisfied (in our discretion) that Attendees will be issued replacement Tickets or refunds. Unless you have a separate agreement with us, you acknowledge and agree that all of your Events will be accessible to Attendees who purchase an individual Ticket or a subscription. You must also furnish a working contact and support email address which will be displayed on your Fidio store."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "1.2.2. Event Producer Content:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You are responsible for creating the images, words, graphics, recordings and other content that are featured on your Event Producer page, communicated to your Attendees through Event Producer Communications (defined below), and performed and displayed as part of an Event (collectively, the “Event Producer Content”). You are solely responsible for securing all third-party permissions, licenses and approvals that may be required (e.g., from record labels, music publishers, managers, agents, etc.) for all Event Producer Content you make available on the Site, including without limitation to perform, display, record and replay a streaming Event, where applicable. You warrant and represent that, prior to providing any Event Producer Content to the Site, you have all of the foregoing permissions, licenses and approvals, and shall indemnify, defend and hold Fidio and its affiliates harmless from all claims in connection therewith."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "1.2.3. Event Producer Communications:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You are responsible for all marketing/exclusive content text messages and/or emails featuring Event Producer Content in connection with Tickets (collectively, “Event Producer Communications”), including honoring any and all marketing opt-out requests and other compliance with applicable laws. As an Event Producer, you agree to indemnify, defend and hold us harmless for any liability or loss incurred by us as a result of the Event Producer Content or Event Producer Communications. As an Attendee, you release us from all liability in connection with any Event Producer Content and Event Producer Communications."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "2. Account Registration"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "2.1. General:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You will not be required to register for an account in order to browse the Site as a general User. However, Users will be required to register for an Attendee account to use certain features of the Site, such as purchasing a Ticket and viewing Events, purchasing merchandise and for an Event Producer account to provide Events through the Site, and to offer Tickets to those Events and sell merchandise. Event Producers may also purchase Tickets from other Event Producers, in which case the purchaser would be an “Attendee” for purposes of that particular transaction."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "2.2. Account Credentials:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "By registering for an account, you agree that all information provided is accurate and complete. Your account username may not include the name of another person with the intent to impersonate that person, or be offensive, vulgar or obscene. Your account and your account username and password are personal to you, and you may not transfer or sell access to your account or use another User’s account without that User’s permission. You will be responsible for the confidentiality and use of your username and password, and for all activities (including purchases) that are conducted through your account. We will not be liable for any harm related to disclosure of your username or password or the use by anyone else of your username or password. You will immediately notify us in writing if you discover any unauthorized use of your account or other account-related security breach. We may require you to change your username and/or password if we believe your account is no longer secure or if we receive a complaint that your username violates someone else’s rights. You will have no ownership in your account or your username. We may refuse registration, cancel an account or deny access to the Site for any reason."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "2.3. Event Producer Accounts:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "An Event Producer may establish and manage its own account or delegate permission to authorized individuals to do so on its behalf, resulting in multiple User accounts associated with one Event Producer account. In such case, Event Producer and each authorized User are responsible for compliance with the obligations of Event Producer hereunder in these Terms and our Privacy Policy and the term “Event Producer” shall mean both the individual Event Producer and all authorized Users associated with its account. A particular User (such as a business manager, public relations manager, or social media manager) may be associated with more than one Event Producer account, in which case that User is responsible for compliance with the obligations of each Event Producer the User represents."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "text-xl font-semibold mt-6",
                        children: "3. Attendee Purchases and Terms of Sale"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.1. General:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "Fidio is an events-based ticketing platform for Event Producers’ streaming Events. We do not control the services advertised or provided by the Event Producer and do not manage or fulfil the merchandise that an Event Producer might include as part of an order. While we may collect information from Attendees with respect to merchandise (such as shipping and size information), the Event Producer is solely responsible for fulfilment of the merchandise orders and Fidio has no responsibility for the accuracy of any information collected, the shipping or fulfilment of the merchandise or with respect to the merchandise itself. We may from time to time offer special promotional offers (“Offers”) to Attendees. Offer eligibility is determined by us in our sole discretion, and we reserve the right to revoke an Offer and put your account on hold in the event that we determine you are not eligible. The eligibility requirements and other limitations and conditions will be disclosed when you sign-up for the Offer or in other communications made available to you."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.2. Pricing:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "We sell livestream Tickets on behalf of Event Producers, which means that the price for each Ticket for an Event is determined by the applicable Event Producer. Tickets are sold individually, and we may also offer a monthly or annual subscription. Subscriptions are all-access, subject to certain restrictions set by us. Subscription features may include:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        class: "list-decimal pl-6 mt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "the ability to watch any eligible content without needing to purchase an individual Ticket,"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "access to special Events (subject to an additional fee),"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "the ability to add upcoming Events to schedule for notifications and planning,"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "personalized recommendations, and"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "the ability to create playlists."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "Quarterly plans renew for 90-day periods and annual plans renew for 1-year periods. You must pay all fees (plus any taxes) during your subscription period and any renewal periods. Your subscription fees will be charged to the payment method you maintain in your account. We may adjust fees from time to time and will attempt to notify you in advance of any such fee changes prior to your next billing cycle. If you do not wish to accept a fee change, you may terminate your subscription by following the process in your account. If you choose to purchase a subscription, to the extent permitted by applicable law, your subscription will continue and automatically renew until terminated. There will be no refunds if you choose to terminate a subscription, however you will be able to continue to view Events through the end of your subscription term."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.3. Fees and Taxes:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "All prices are charged in U.S. Dollars (unless otherwise stated). Applicable taxes shall be separately assessed as required by law at the time of checkout. If applicable, currency exchange rates and foreign transaction fees are generally determined and applied by your payment provider, and you acknowledge and agree that we have no responsibility for refunding or compensating you for amounts or expenses incurred in connection with those fees. If the amount you pay for a Ticket is incorrect (regardless of whether it is incorrect because of an error in a price posted on the Site or otherwise communicated to you), if you are able to order a Ticket before its scheduled on-sale or presale date, or if you are able to order a Ticket that was not supposed to have been released for sale, then we will have the right to cancel that Ticket (or the order for that Ticket) and refund to you the amount that you paid. This will apply regardless of whether the error occurred because of human error or a transactional malfunction of the Site. If a refund is processed in error, or a refund exceeds the original amount paid, we reserve the right to recharge the original method of payment used at the time of purchase. Shipping and handling fees and taxes charged or collected by us for merchandise made available for purchase by an Event Producer will be added to your order and will appear as a separate charge on your order confirmation and receipt."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.4. Method of Payment:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You agree to pay all charges incurred by you at the amounts in effect when such charges are incurred and agree that we and any of our third-party payment processors are authorized to immediately charge your credit card or other method of payment used at the time of purchase. You agree to immediately notify us of any change in your payment information. We reserve the right at any time to change our billing methods. All information that you provide to us or our third-party payment processors must be accurate, current and complete. You will not attempt to conceal your identity by using multiple Internet Protocol addresses or email addresses, or by any other means, to conduct transactions on the Site. You will not hold us liable if you do not comply with laws related to your transactions. We may provide law enforcement with information you provide to us related to your transactions to assist in any investigation or prosecution of you. We may cancel an order or prevent you from making future orders for any reason, including, without limitation:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        class: "list-decimal pl-6 mt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "if you attempt to use the Site in breach of any applicable law or regulation, including but not limited to the card network rules or regulations;"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "if you use the Site in breach of these Terms;"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "if we suspect fraudulent, unlawful or improper activity regarding a payment;"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.4. Billing Information Verification:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "All information on accounts and orders must be valid and are subject to verification. Orders are subject to credit card approval and are processed only after the billing address associated with your credit card and other billing information have been verified. Orders that are placed, or attempted to be placed, using an account with any information that is found to be false, misleading, incorrect, or incomplete, or that cannot be verified as belonging to the account holder, such as name, address, email address, phone number, IP address, or other account or billing information, are subject to cancelation, at any time. If your order is cancelled for any of the foregoing reasons, we may sell your Tickets to another Attendee without further notice. Occasionally, we receive incorrect billing or credit card account information for a Ticket order that can delay processing and delivery. In these cases, customer service will attempt to contact you, using the information provided at the time of purchase. If we are unable to reach you after our initial attempt, we may cancel your order and sell your Ticket to another Attendee without further notice."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.5. No Resale, Transfer, and Promotions:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "Purchases of all Tickets are personal to each Attendee, and the resale, transfer, or gifting of Tickets is expressly prohibited. Tickets may not be used for advertising, promotions, contests or sweepstakes unless formal written authorization is given by us."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.6. Postponed or Rescheduled Events:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "If an Event is postponed or rescheduled, your Ticket is still valid for the rescheduled Event date and we will not issue a refund. If an Event Producer cancels an Event, we will issue you a refund to the original method of payment used at time of purchase (as outlined below) unless your Ticket was part of a subscription, in which case you will not receive a refund. We will communicate to Attendees any changes to Event times on behalf of the Event Producer."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.7. Refunds:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "All sales are final and Tickets are non-refundable except in the limited circumstances where an Event is canceled. In our sole discretion, we may issue you a refund for a non-subscription Ticket due to a canceled Event and, in such event, we will issue a refund of the Ticket face value paid. If a refund is issued, it will be processed to the original method of payment used at time of purchase. We cannot issue a refund to a different credit or debit card. If your credit card or debit card number has changed, but is for the same account (e.g., a new card has been issued for the same account), the refund will be processed to that account. You agree that you will not attempt to evade, avoid, or circumvent any refund prohibitions in any manner with regard to the Ticket you purchased. Without limiting the foregoing, you will not contact us to seek a refund or exchange from us when we are prohibited from providing one by the Event Producer, and you will not dispute or otherwise seek a “chargeback” from the company whose credit card you used to purchase the Ticket from the Site. Should you do so, your Tickets or subscription may be canceled, and we may, in our sole discretion, refuse to honor pending and future Ticket and subscription purchases made from all credit card accounts or online accounts on which such chargebacks have been made, and may prohibit all persons in whose name the credit card accounts exist and any person who accesses any associated online account or credit card or who otherwise breaches this provision from using the Site."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.8. Ticket Orders:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "Individual Tickets are sold on a first come first served basis and while quantities last. Your Ticket or subscription order is confirmed when we send you a confirmation, in the form of a confirmation page or email. If you do not receive a confirmation number after submitting payment information, or if you experience an error message or service interruption after submitting payment information, it is your responsibility to confirm whether or not your order has been placed. We will not be responsible for losses (monetary or otherwise) if you fail to receive an order confirmation or if a confirmation is not generated for an order."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.9. Ability to View an Event:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "The ability to view a streaming Event may be limited depending on your Internet provider, your device, and your browser type. You are responsible for determining whether your Internet speed, device, and browser can support a streaming Event and Fidio strongly suggests that you test your Internet speed, device, and browser before making a streaming ticket purchase. Fidio is not liable for troubleshooting issues, Internet loading, or capacity issues if these cause Attendees to miss any part of an Event. Fidio does not assist with the production of the Event or any other part of the Event, including merchandise included with a Ticket, the length of the Event, and the ability to re-watch the Event. It is in the Event Producer’s sole discretion whether to permit Attendees to re-watch an Event after the original Event has taken place. Fidio is not liable for any issues during an Event, and only the Event Producer may approve refunds if any issues arise. Attendees may not photograph, film, or otherwise record Events and may not post any such photographs or recordings to social media or make any such recording publicly available without the Event Producer’s prior written permission in each instance. If you violate these provisions, in addition to seeking monetary damages against you, we and/or the Event Producer may seek an injunction against you to take down such recordings without posting a bond."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "3.10. Donations:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "3.10.1. General:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "In partnership with a third-party, Fidio will offer Event Producers the option to implement a donation feature with regard to a specific Event, Ticket, or other service offering (the “Donation Services”). Charities are selected by Event Producers in their sole discretion and Event Producers are responsible for vetting all organizations with the third-party before utilizing the Donation Services. A more comprehensive donations policy will be provided when these Terms are updated."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "4. Site Code of Conduct & Acceptable Use Policy"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "You agree that you will comply with all applicable laws, rules and regulations, and that you will not:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        class: "list-decimal pl-6",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "Restrict or inhibit any other person from using the Site."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "Use the Site for any unlawful purpose."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "Express or imply that any statements you make are endorsed by us, without our prior written consent."
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "Impersonate any person or entity, whether actual or fictitious, including any employee or representative of our company."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "Fidio may refuse access to the Site or our Services if we believe a User has violated the Code of Conduct or any other provision of these Terms in our sole and absolute discretion."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h3", {
                        class: "text-lg font-semibold mt-4",
                        children: "5. Ownership of Content and Grant of Conditional License to use the Site"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "The Site and all data, text, designs, pages, print screens, images, artwork, photographs, audio and video clips, and HTML code, source code, or software that reside or are viewable or otherwise discoverable on the Site, and all Tickets obtained from the Site, (collectively, the “Content”) are owned by us or our licensors. Our licensors include Event Producers with regard to the Event Producer Content that they own and license to Fidio for the purpose of displaying an Event to Attendees hereunder. Other than Event Producer Content, we own a copyright and, in some instances, patents and other intellectual property in the Site and Content. We may change the Content and features of the Site at any time. We grant Users a personal, limited, conditional, no-cost, non-exclusive, non- transferable, non-sublicensable revocable license subject to the limitations below to view this Site and the Content, and to use the Site as an Attendee and/or Event Producer as otherwise permitted herein only if, as a condition precedent, you agree that you will not:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "a) Submit any software or other materials that contain any viruses, worms, Trojan horses, defects, date bombs, time bombs or other items of a destructive nature;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "b) Manipulate identifiers, including by forging headers, in order to disguise the origin of any posting that you submit;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "c) Link to any portion of the Site other than the URL assigned to the home page of the Site;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: 'd) "Frame" or "mirror" any part of the Site;'
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "e) Modify, adapt, sub-license, translate, sell, reverse engineer, decompile or disassemble any portion of the Site or otherwise attempt to derive any source code or underlying ideas or algorithms of any part of the Content;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "f) Remove any copyright, trademark or other proprietary rights notices contained on the Site;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "g) Use any robot, spider, offline reader, site search/retrieval application or other manual or automatic device, tool, or process to retrieve, index, data mine or in any way reproduce or circumvent the navigational structure or presentation of the Content or the Site, including with respect to any CAPTCHA displayed on the Site. Operators of public search engines may use spiders to copy materials from the Site for the sole purpose of and solely to the extent necessary for creating publicly available searchable indices of the materials, but not caches or archives of such materials. We may revoke this exception at any time and require removal of archived materials gathered in the past;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "h) Use any automated software or computer system to search for, reserve, buy or otherwise obtain Tickets, discount codes, promotional codes, vouchers, gift cards or any other items available on the Site, including sending information from your computer to another computer where such software or system is active;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "i) Take any action that imposes or may impose (in our sole discretion) an unreasonable or disproportionately large load on our infrastructure;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "j) Access, reload or refresh transactional event pages, or make any other request to transactional servers, more than once during any three-second interval;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "k) Request more than 500 pages of the Site in any 24-hour period, whether alone or with a group of individuals;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "l) Make more than 600 reserve requests on the Site in any 24-hour period, whether alone or with a group of individuals;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "m) Reproduce, modify, display, publicly perform, distribute or create derivative works of the Site or the Content;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "n) Reproduce or scan Tickets in a format or medium different from that provided by the Site;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "o) Decode, decrypt, modify, or reverse engineer any Tickets or underlying algorithms or barcodes used on or in production of Tickets or the Site;"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "p) Use the Site or the Content in an attempt to, or in conjunction with, any device, program or service designed to circumvent any technological measure that effectively controls access to, or the rights in, the Site and/or Content in any way including, without limitation, by manual or automatic device or process, for any purpose."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "This license is expressly conditioned on your pre-existing agreement to comply with, and your actual compliance with, each of the provisions described in this Ownership of Content and Grant of Conditional License section. This license exists only so long as you strictly comply with each of the provisions described in this section. Any use of the Site or Content by you or anyone acting on your behalf that does not strictly comply with each and every provision in this section exceeds the scope of the license granted to you herein, constitutes unauthorized reproduction, display, or creation of unauthorized derivative versions of the Site and Content, and infringes our copyrights, trademarks, patents and other rights in the Site and Content. You will not acquire any ownership rights by using the Site or the Content."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        class: "mt-2",
                        children: "The registered and unregistered trademarks, logos and service marks displayed on the Site are owned by us or our licensors. You may not use our trademarks, logos and service marks in any way without our prior written permission."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "6. Chat and User Content"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "We may host livestream Event Producer chats (“Chats”). We reserve the right to restrict or terminate your access to the Chats at any time, for any reason. If your access to a Chat has been restricted or terminated, you may not create a second account or register with a new name and/or email address in order to evade such restrictions or termination. Use of the Chat feature is at your own risk. We are not responsible for and disclaim all liability associated with any content posted by a User (“User Content”) or other third-party content that may be available in a Chat. All opinions and views expressed in a Chat are solely those of the posting User."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "Users may not post affiliate links, blogger codes, auction site postings, links to competitive ticketing and/or streaming platforms, links to other commercial websites, your own blog, social media accounts, or any other commercial content. Be respectful in how you express your opinions. Personal attacks, harassment, and rude, insensitive, or offensive comments are prohibited whether they are directed at Artists, Fans, or Fidio staff. Chats are designed for bonding over common interests related to the Event. Comments related to your dissatisfaction with a purchase, assistance with an order, or other customer service-related issues should be directed to Customer Service. Should you have a problem with a User or post, please take a screen shot and contact Customer Service. Be careful about sharing personal or private information through a Chat. Even if you’re posting through a username and not your real name, it can be easier than you think to find out someone’s real name and identity. Don’t post anything anonymously that you wouldn’t be comfortable sharing publicly. Respect another User’s request if the User prefers not to communicate with you. Do not request other Users to contact you outside of a Chat."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "As between you and us, you own all rights to your User Content. If you submit User Content to the Site, you grant us a worldwide, non-exclusive, transferable, sublicensable, royalty-free right and license to use, reproduce, modify, create derivative works of, distribute, publicly perform, display, archive and commercialize your User Content, in our sole discretion, in all formats and in all media channels now known or hereinafter discovered, without any compensation or acknowledgment to you or anyone else. This license will not affect your ownership in your User Content, including the right to grant additional licenses to your User Content, except if it conflicts with these Terms. We are not obligated to post, display or otherwise use any User Content, or to attribute your User Content to you. You will not make or authorize any claim against us that our use of your User Content infringes any of your rights. Statements, opinions, and reviews posted by participants in a Chat may be inaccurate, offensive, obscene, threatening or harassing. We do not endorse and are not responsible for these posts. We will not be liable for any loss or harm caused by the post or your reliance on information obtained through the post."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "You will be responsible for your User Content and the consequences of posting it. By submitting User Content, you represent to us that (i) you own, or have the necessary permission to submit the User Content and to grant the licenses to us under this section, (ii) your User Content does not violate the Code of Conduct and Acceptable Use Policy contained in these Terms, and (iii) you have the written permission of every identifiable person in the User Content to use that person’s name and likeness in the manner contemplated by the Site and these Terms or, if the person is a minor, the written permission of the minor’s parent or legal guardian."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "You understand that User Content posted to Chats will be viewed by other Users, that you have no expectation of privacy with regard to such User Content, and that your ability to delete User Content after posting may be limited due to the nature of the Chat."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "We will have the right (but not the obligation) to monitor the Site, and the User Content, and to disclose any User Content and the circumstances surrounding its submission in order to operate the Site properly, or to protect ourselves, our sponsors and other Users, or to comply with legal obligations or governmental requests."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "If we are notified that your User Content does not comply with these Terms, we may investigate the allegation and may decide to remove your User Content and cancel your account. We may also hold you liable for any User Content that infringes the rights of a third party and require you to pay or reimburse us for any amounts we believe are necessary to resolve any complaint. Enforcement of these guidelines is in our sole and absolute discretion, and our failure to enforce them in certain instances does not constitute a waiver of our right to enforce them in other instances."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "If you use any review feature of the Site or provide us with any communications, comments, questions, suggestions, or other feedback relating to the Site or our Services (collectively, “Feedback”) your Feedback will be treated as non-confidential and non-proprietary and you grant to us the right to use such Feedback for any purpose whatsoever, including the development of new products and services, without any attribution or compensation to you."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "7. Claims of Copyright Infringement on the Site"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "7.1. Under Canada’s Copyright Act and the Digital Millennium Copyright Act of 1998 (the “DMCA”) if you believe in good faith that any content on the Site infringes your copyright, you may send us a notice requesting that the content be removed. The notice must include:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "a) your (or your agent’s) physical or electronic signature;"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "b) identification of the copyrighted work on our Site that is claimed to have been infringed (or a representative list if multiple copyrighted works are included in one notification);"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "c) identification of the content that is claimed to be infringing or the subject of infringing activity, including information reasonably sufficient to allow us to locate the content on the Site;"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "d) your name, address, telephone number and email address (if available);"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "e) a statement that you have a good faith belief that use of the content in the manner complained of is not authorized by you or your agent or the law; and"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "f) a statement that the information in the notification is accurate and, under penalty of perjury, that you or your agent is authorized to act on behalf of the copyright owner. If you believe in good faith that a notice of copyright infringement has been wrongly filed against you, you may send us a counter-notice. You may read more information about the DMCA at www.copyright.gov and the Canadian Intellectual Property Office."
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "7.2. Notices and counter-notices should be sent to Fidio Inc. by emailing copyright@fidio.ca. There can be penalties for false claims under the DMCA. We suggest that you consult your legal advisor before filing a notice or counter-notice."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "7.3. If you are found to be a repeat copyright infringer and we receive multiple DMCA or other copyright infringement notices regarding your User Content, you agree that we may take actions to prevent future infringement, such as:"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "a) Blocking your account from future content uploads"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "b) Terminating your account and access to the Site"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "c) Putting your email address on a banned list"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx("li", {
                                children: "d) Prohibiting you and anyone using your email address, IP address, or other identifying information from reopening your account or opening a new account"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "8. Termination"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "We reserve the right to terminate or suspend a User account or access to the Site at any time and for any reason, including your violation of these Terms as determined in our sole and absolute discretion. Whether you are an Event Producer or an Attendee, if we terminate or suspend your account, you will have no further access to your account, or anything associated with it, and the conditional license granted to you hereunder shall immediately cease. We will not have any liability to you for any suspension or termination of your account, including with regard to any deletion of Event Producer Content, Event Producer Communications, or other User Content. All provisions of these Terms which by their nature should survive, shall so survive the termination, including without limitation, ownership provisions, disclaimers of warranties, limitations of liability, and indemnities."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "9. Third Party Links"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "The Site may contain links to other websites that may not be owned or operated by us. The fact that we may link to those websites does not indicate any approval or endorsement of those websites. We have no control over those websites. We are not responsible for the content of those websites, or the privacy practices of those websites. We strongly encourage you to become familiar with the terms of use and practices of any linked website. Your use of such other websites is at your own risk and is subject to the terms of use and privacy policies of those websites. It is up to you to take precautions to ensure that whatever links you select or software you download (whether from the Site or other sites) is free of viruses, worms, Trojan horses, defects, date bombs, time bombs and other items of a destructive nature."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "10. Access from Outside Canada"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "We operate the Site from our offices in Ontario, Canada. We do not represent that Content available on or through the Site is appropriate or available in other locations. We may limit the availability of the Site or any service or product described on the Site to any person or geographic area at any time. If you choose to access the Site from outside Canada, you do so at your own risk and you are responsible for following applicable local laws."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "11. Rules for Sweepstakes, Contests, and Games"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "In addition to these Terms, sweepstakes, contests, games, or other promotions (collectively, “Promotions”) made available through the Site may have specific rules that are different from these Terms. By participating in a Promotion, you will become subject to those rules. You should review the rules before you participate in a Promotion. Promotion rules will control over any conflict with these Terms, except in all instances the arbitration agreement and class action waiver set forth below will control and apply."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        class: "mt-4",
                        children: "12. Violation of these Terms"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "We may investigate any violation of these Terms, including unauthorized use of the Site. We may provide law enforcement with information you provide to us related to your transactions to assist in any investigation or prosecution of you. We may take legal action that we feel is appropriate. You agree that monetary damages may not provide us a sufficient remedy and that we may pursue injunctive or other relief for your violation of these Terms. If we determine that you have violated these Terms or the law, are stalking a User or someone associated with Fidio, or otherwise interfering with activities associated with a Ticket, or for any other reason or for no reason, we may cancel your account, delete all your User Content and prevent you from accessing the Site at any time without notice to you. If that happens, you may no longer use the Site or any Content. You will still be bound by your obligations under these Terms. You agree that we will not be liable to you or any third party for termination of your access to the Site or to your account or any related information, and we will not be required to make the Site or your account or any related information available to you. We may also cancel any Tickets sold or offered through the Site. We may refuse to honor pending and future offers made from all accounts we believe may be associated with you or cancel a Ticket order associated with any person we believe to be acting with you or on your behalf or exercise any other remedy available to us."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "13. Disclaimer of Warranties"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "WE PROVIDE THE SITE AND THE CONTENT TO YOU “AS IS” AND “AS AVAILABLE” WITHOUT WARRANTIES OF ANY KIND. WE TRY TO KEEP THE SITE UP, BUG-FREE AND SAFE, BUT YOU USE IT AT YOUR OWN RISK. TO THE FULLEST EXTENT PERMISSIBLE BY LAW, AND TO THE EXTENT THAT APPLICABLE LAW PERMITS THE DISCLAIMER OF EXPRESS OR IMPLIED WARRANTIES, WE DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING ANY WARRANTY OF TITLE, NON-INFRINGEMENT, ACCURACY, MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR WARRANTIES THAT MAY ARISE FROM COURSE OF DEALING OR COURSE OF PERFORMANCE OR USAGE OF TRADE. WE DO NOT GUARANTEE THAT THE SITE WILL ALWAYS BE SAFE, SECURE OR ERROR-FREE OR THAT THE SITE WILL ALWAYS FUNCTION WITHOUT DISRUPTIONS, DELAYS OR IMPERFECTIONS. WE DO NOT GUARANTEE THE QUALITY OR STANDARD OF ANY OF THE TICKETS OR OTHER GOODS AND SERVICES THAT WE MAY OFFER THROUGH THE SITE FROM TIME TO TIME. YOU ARE TAKING THE RISK THAT THE EVENT PRODUCERS MAY NOT PROVIDE THE LEVEL OF INTERACTION THAT YOU WERE ANTICIPATING OR THAT THE TICKET OR OTHER GOOD OR SERVICE PURCHASED DOES NOT MEET YOUR EXPECTATIONS. WE ARE NOT RESPONSIBLE FOR THE ACTIONS OR INFORMATION OF THIRD PARTIES, INCLUDING USERS, AND YOU RELEASE US FROM ANY CLAIMS AND DAMAGES, KNOWN AND UNKNOWN, ARISING OUT OF OR IN ANY WAY CONNECTED WITH ANY CLAIM YOU HAVE AGAINST ANY SUCH THIRD PARTIES. IF YOU ARE A CALIFORNIA RESIDENT, YOU WAIVE CALIFORNIA CIVIL CODE \xa71542, WHICH SAYS: A GENERAL RELEASE DOES NOT EXTEND TO CLAIMS WHICH THE CREDITOR DOES NOT KNOW OR SUSPECT TO EXIST IN HIS OR HER FAVOR AT THE TIME OF EXECUTING THE RELEASE, WHICH IF KNOWN BY HIM OR HER MUST HAVE MATERIALLY AFFECTED HIS SETTLEMENT WITH THE DEBTOR."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "14. Limitation of Liability"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "14.1. IN NO EVENT WILL WE OR OUR SUPPLIERS, SERVICE PROVIDERS, ADVERTISERS AND SPONSORS, BE RESPONSIBLE OR LIABLE TO YOU OR ANYONE ELSE FOR, AND YOU HEREBY KNOWINGLY AND EXPRESSLY WAIVE ALL RIGHTS TO SEEK, DIRECT, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES OF ANY TYPE OTHER THAN OUT OF POCKET EXPENSES, AND ANY RIGHTS TO HAVE DAMAGES MULTIPLIED OR OTHERWISE INCREASED, ARISING OUT OF OR IN CONNECTION WITH THE SITE, THE CONTENT, OR ANY TICKET PURCHASED THROUGH THE SITE, EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES, AND REGARDLESS OF WHETHER THE CLAIM IS BASED UPON ANY CONTRACT, TORT, OR OTHER LEGAL OR EQUITABLE THEORY. WITHOUT LIMITING THE FOREGOING, YOU EXPRESSLY ACKNOWLEDGE AND AGREE THAT WE WILL HAVE NO LIABILITY OR RESPONSIBILITY WHATSOEVER FOR (a) ANY FAILURE OF ANOTHER USER OF THE SITE TO CONFORM TO THE CODE OF CONDUCT, (b) PERSONAL INJURY OR PROPERTY DAMAGE, OF ANY NATURE WHATSOEVER, WHETHER ARISING IN CONTRACT OR IN TORT, RESULTING FROM YOUR ATTENDANCE AT A LIVE EVENT RELATING TO A PURCHASED TICKET OR SUBSCRIPTION OR ACCESS TO AND USE OF OUR SITE, (c) ANY UNAUTHORIZED ACCESS TO OR USE OF OUR SECURE SERVERS AND/OR ANY AND ALL PERSONAL INFORMATION AND/OR FINANCIAL INFORMATION STORED THEREIN, (d) ANY BUGS, VIRUSES, WORMS, TROJAN HORSES, DEFECTS, DATE BOMBS, TIME BOMBS OR OTHER ITEMS OF A DESTRUCTIVE NATURE WHICH MAY BE TRANSMITTED TO OR THROUGH OUR SITE, (e) ANY ERRORS, MISTAKES, INACCURACIES OR OMISSIONS IN ANY CONTENT, OR (f) ANY LOST, STOLEN OR DAMAGED TICKETS, OR THE FAILURE OF AN EVENT PRODUCER TO HONOR A TICKET OR SUBSCRIPTION. YOUR SOLE AND EXCLUSIVE REMEDY FOR DISSATISFACTION WITH THE SITE IS TO STOP USING THE SITE. THE LIMITATIONS IN THIS SECTION WILL APPLY EVEN IF ANY LIMITED REMEDY"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "FAILS OF ITS ESSENTIAL PURPOSE. THE ALLOCATION OF RISK BETWEEN US IS AN ESSENTIAL ELEMENT OF THE BASIS OF THE BARGAIN BETWEEN US."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "14.2. OUR AGGREGATE LIABILITY ARISING OUT OF THESE TERMS OR THE USE OF THE SITE WILL NOT EXCEED (I) THE GREATER OF ONE HUNDRED DOLLARS ($100) OR (A) IN THE CASE OF EVENT PRODUCERS, THE AMOUNT WE HAVE EARNED FROM YOUR USE OF THE SERVICES IN THE PAST SIX MONTHS, OR (B) IN THE CASE OF ATTENDEES, THE AMOUNT YOU HAVE PAID TO US FOR YOUR USE OF THE SERVICES IN THE PAST SIX MONTHS. IN NO EVENT WILL ATTORNEYS’ FEES BE AWARDED OR RECOVERABLE BY YOU. OUR LIABILITY WILL BE LIMITED UNDER THIS PARAGRAPH TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, AND THE PROVISIONS OF THIS PARAGRAPH WILL NOT APPLY TO THE EXTENT APPLICABLE LAW PERMITS THE RECOVERY OF DAMAGES, ATTORNEYS’ FEES OR COSTS OTHERWISE PROHIBITED UNDER THIS PARAGRAPH. THE PROVISIONS OF THIS PARAGRAPH THAT (A) PROHIBIT DAMAGES TO BE MULTIPLIED OR OTHERWISE INCREASED, (B) IMPOSE A DAMAGES LIMITATION OF THE GREATER OF ONE HUNDRED DOLLARS ($100) OR THE AMOUNT WE HAVE EARNED FROM YOUR USE AS AN EVENT PRODUCER OR THE AMOUNT YOU HAVE PAID US IN THE PAST SIXMONTHS AS AN ATTENDEE, AS THE CASE MAY BE, AND (C) PROHIBIT THE RECOVERY OF ATTORNEYS’ FEES AND COSTS, DO NOT APPLY IN CERTAIN STATES, INCLUDING WITHOUT LIMITATION NEW JERSEY, TO CLAIMS BROUGHT UNDER STATUTES PERMITTING SUCH RECOVERY."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "15. Indemnification"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "If anyone brings a claim against us related to your use of the Site, your User Content, your Event Producer Content, your Event Producer Communications, your violation of these Terms, or your negligence or willful misconduct in connection with your use of the Site, you agree to indemnify, defend and hold us and our affiliated companies, suppliers, advertisers and sponsors, and each of our officers, directors, employees, and agents, harmless from and against any and all claims, damages, losses and expenses of any kind (including reasonable legal fees and costs). We reserve the right to take exclusive control and defence of any claim, and you will cooperate fully with us in asserting any available defences."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "16. Disputes, Including Mandatory Arbitration and Class Action Waiver"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "YOU AND WE EACH AGREE THAT, EXCEPT AS PROVIDED BELOW, ANY DISPUTE, CLAIM, OR CONTROVERSY RELATING IN ANY WAY TO THE TERMS, YOUR USE OF THE SITE, OR PRODUCTS OR SERVICES SOLD, DISTRIBUTED, ISSUED, OR SERVICED BY OR THROUGH US—IRRESPECTIVE OF WHEN"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "THAT DISPUTE, CLAIM, OR CONTROVERSY AROSE—WILL BE RESOLVED SOLELY BY BINDING, INDIVIDUAL ARBITRATION AS SET FORTH IN THESE TERMS, RATHER THAN IN COURT. YOU AND WE THEREBY EACH AGREE TO WAIVE ANY RIGHT TO A JURY TRIAL AND AGREE THAT YOU AND WE MAY BRING CLAIMS AGAINST EACH OTHER ONLY IN AN INDIVIDUAL CAPACITY, AND NOT AS A PLAINTIFF OR CLASS MEMBER IN ANY PURPORTED CLASS OR REPRESENTATIVE PROCEEDING."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.1. Exceptions. The arbitration agreement and class action waiver set forth in this Section 16 shall be subject to these limited exceptions: You may assert claims in small claims court if your claims apply. If a claim involves the conditional license granted to you as described in the Ownership of Content and Grant of Conditional License section above, either of us may file a lawsuit in a federal or state court located within the Province of Ontario, Canada or at Fidio’s discretion, in the United States Federal District Court for the judicial district in which your address is located, or if your address is outside of the United States, for any judicial district in the United States, and you further agree to and submit to the exercise of personal jurisdiction of such courts for the purpose of litigating any such claim or action and we both consent to the jurisdiction of those courts for such purposes. In the event that the arbitration agreement in the Terms is for any reason held to be unenforceable, any litigation against us (except for small claims court actions) may be commenced only in a federal or state court located within the Province of Ontario, Canada, and you and we each consent to the jurisdiction of those courts for such purposes. You and we each retain the right to participate in class-wide settlement of claims."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.2. Informal Dispute Resolution. You and we each recognize and agree that good faith, informal efforts to resolve disputes often result in prompt, low-cost, and mutually beneficial outcomes. Therefore, you and we each agree that, before either of us may commence an arbitration or assert a claim in small claims court, you and we will engage in the following informal dispute resolution process: The party seeking to initiate a claim in arbitration or small claims court (“claimant”) must give written notice to the other party (“respondent”). To notify us that you intend to initiate informal dispute resolution, you must send an email to Fidio, Inc. at legal@fidio.ca, providing: your full name; the email address and mailing address associated with your Fidio account; your counsel’s name and contact information, if you are represented by counsel; and a brief description of your claim(s) and the relief sought. To notify you that we intend to initiate informal dispute resolution, we will email you at the email address associated with your Fidio account and provide a brief description of our claim(s) and the relief sought, and our counsel’s name and contact information. You and we will then personally meet and confer, via teleconference or videoconference, in a good faith effort to informally resolve any claim covered by this mutual arbitration agreement. If either you or us is represented by counsel, that counsel may participate in the informal dispute resolution conference. All offers, promises, conduct, and statements made in the course of the informal dispute resolution process by any party, its agents, employees, and attorneys are confidential and not admissible for any purpose in any subsequent proceeding, provided that evidence that is otherwise admissible or discoverable shall not be rendered inadmissible or non-discoverable as a result of its use in the informal dispute resolution process. The informal dispute resolution conference shall occur within sixty (60) days of receipt of the written notice described above unless an extension is mutually agreed upon by you and us. If, after participating in that conference, you and we have been unable to resolve the dispute, the claimant may commence an arbitration or assert a claim in small claims court in accordance with this arbitration agreement. Any statute of limitations will be tolled while you and we engage in the informal dispute resolution process described in this section."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: '16.3. Governing Law; Interpretation and Enforcement. The arbitration agreement in the Terms is governed by the Arbitration Act (1991, S.O. 1991, c.17) (“AA"), including its procedural provisions, in all respects. This means that the AA governs, among other things, the interpretation and enforcement of this arbitration agreement and all of its provisions, including, without limitation, the class action waiver. State arbitration laws do not govern in any respect. Further, you and we each agree that the Terms evidence a transaction involving interstate commerce and will be governed by and construed in accordance with federal law to the fullest extent possible.'
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.4. Arbitration Generally; Relief Available. There is no judge or jury in arbitration, and court review of an arbitration award is limited pursuant to the AA. However, an arbitrator can award on an individual basis the same damages and relief as a court (including injunctive and declaratory relief or statutory damages) and must follow the Terms as a court would. For the avoidance of doubt, the arbitrator can award public injunctive relief if authorized by law and warranted by the individual claim(s)."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.5. Arbitration Proceedings and Rules. The rules and procedures of the ADR Institute of Canada (ADRIC) shall apply to all arbitral proceedings."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.7. Delegation; Interpretation. The arbitrator, and not any federal, state or local court or agency, shall have exclusive authority to the extent permitted by law to resolve all disputes arising out of or relating to the interpretation, applicability, enforceability, or formation of this Agreement, including, but not limited to, any claim that all or any part of this Agreement is void or voidable; however, in the event of a dispute about which particular version of this Agreement you agreed to, a court will decide that specific question. This arbitration agreement is intended to be broadly interpreted and will survive termination of the Terms."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "16.8. Limited Right to Appeal. As explained above, court review of the arbitrator’s decision is limited pursuant to the AA; however, the Terms provide a limited right to appeal the arbitrator’s decision to a panel of arbitrators, as set forth in this sub-section. Specifically, in the event that the arbitrator awards injunctive relief against either you or us, the party against whom injunctive relief was awarded may – within 21 days of the arbitrator’s final decision – appeal that decision to JAMS, in accordance with the following procedure: a) Except as otherwise provided by the Terms, the appeal will be conducted pursuant to the JAMS Optional Arbitration Appeal Procedure, available at www.jamsadr.com. b) To commence an appeal, a party must submit the Demand for Arbitration Form available at www.jamsadr.com, and must also provide notice to the other party in the manner described above in this section. c) The JAMS appeal panel will consist of arbitrators who are either (a) retired state or federal judges or (b) licensed attorneys with at least 20 years of active litigation experience and substantial expertise in the substantive laws applicable to the subject matter of the dispute. d) The JAMS appeal panel will conduct a de novo review of the arbitrator’s decision. e) Except as provided in the AA, there will be no right of appeal from the JAMS appeal panel’s decision."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "17. Relationship Between the Parties."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "Nothing contained in these Terms of Service shall be construed to constitute you and FIDIO as partners or joint venturers or to constitute employment or any type of agency. These Terms of Service control the relationship between FIDIO and you. These Terms of Service do not create any third party beneficiary rights."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "18. Full Integration."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "These Terms of Service constitute the entire agreement between you and FIDIO related to this Site. No prior or contemporaneous written, oral, and electronic representation, negotiation, or agreement form a part of this agreement, and these Terms of Service supersede all prior written, oral, or electronic agreements between you and FIDIO relating to this Site."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-",
                        children: "19. Written Agreement."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "These Terms of Service constitute a written agreement between you and Fidio. A printed version of these Terms of Service, and of any notice given in electronic form related to this agreement, shall be admissible in judicial or administrative proceedings to the same extent, and subject to the same restrictions, as other business contracts, documents, or records originally generated and maintained in printed form."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "20. Force Majeure."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "Fidio shall not have any liability to you hereunder by reason of any delay or failure to perform any obligation or covenant if the delay or failure to perform is occasioned by force majeure, meaning any act of God, storm, fire, casualty, unanticipated work stoppage, power outage, satellite failure, strike, lockout, labor dispute, civil disturbance, riot, war, national emergency, act of Government, act of public enemy, or other cause of similar or dissimilar nature beyond its control."
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mt-4",
                        children: "21. Severability"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "It is our belief that the Terms do not contain any provision contrary to law. However, if any part of the Terms is determined to be illegal, invalid, or unenforceable, you agree that: (a) that part shall nevertheless be enforced to the extent permissible in order to affect the intent of the Terms, and (b) the remaining parts shall be deemed valid and enforceable. 18. Terminating our Services. You may stop using our Services at any time. Fidio may also stop providing Services and Site Content to you or add or create new limits to our Services at any time for any reason. Fidio, at its sole discretion, and with or without notice to you, may: i) terminate this Agreement between Fidio and you and/or your Accounts, and you will remain liable for all amounts due under your Account up to and including the date of termination; ii) terminate your license to the Services and software; and iii) preclude your access to the Site and Services. Fidio reserves the right to modify, suspend or discontinue the Site, Services and/or Materials at any time with or without notice to you, and Fidio will not be liable to you or to any third party should FIDIO exercise such rights. 19. Questions If you have any questions, comments or complaints regarding these Terms or the Site, please contact us at:"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        children: "Fidio Technologies Inc. 95 Kenesky Drive, Waterdown, ON L8B 1Y3 admin@fidio.com"
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Terms = (TermsContent);

;// CONCATENATED MODULE: ./customModules/doc/Terms.jsx



const Terms_Terms = (props)=>{
    return /*#__PURE__*/ jsx_runtime.jsx((external_react_default()).Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx(Terms, {})
    });
};
/* harmony default export */ const doc_Terms = (Terms_Terms);

// EXTERNAL MODULE: ./customModules/features/Signin.jsx
var Signin = __webpack_require__(6213);
;// CONCATENATED MODULE: ./customModules/index.js
// entry.js






const Modules = {
    Hero: Hero/* default */.Z,
    Menu: Menu/* default */.Z,
    HomeDash: features_HomeDash,
    Privacy: privacy,
    Terms: doc_Terms,
    Signin: Signin/* default */.Z
};
/* harmony default export */ const customModules = (Modules);


/***/ }),

/***/ 7786:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _utility = __webpack_require__(5329);
var _wideFeature = __webpack_require__(9101);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
var Module = function Module(props) {
    var AfterSignIn = _react["default"].useRef();
    var Lead2 = _react["default"].useRef();
    var ButtonAction = _react["default"].useRef();
    _react["default"].useEffect(function() {
        try {
            setTimeout(function() {
                if (Lead2.current && !Lead2.current.classList.contains("IndexCta_Lead2Trans")) {
                    Lead2.current.classList.add("IndexCta_Lead2Trans");
                }
                setTimeout(function() {
                    if (AfterSignIn.current && !AfterSignIn.current.classList.contains("IndexCta_AfterSignInTrans")) {
                        AfterSignIn.current.classList.add("IndexCta_AfterSignInTrans");
                    }
                    if (ButtonAction.current && !ButtonAction.current.classList.contains("IndexCta_ButtonStyleTrans")) {
                        ButtonAction.current.classList.add("IndexCta_ButtonStyleTrans");
                    }
                }, 750);
            }, 1000);
        } catch (err) {
        // fail silently
        }
    }, [
        props._loggedIn
    ]);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_ExternalContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_Container"
    }, props.definition ? /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_LeadContainer ".concat(props.className)
    }, props.ctaTopVideos ? /*#__PURE__*/ _react["default"].createElement(_wideFeature.WideFeature, _extends({
        image1: props.ctaTopVideos.image1
    }, props)) : "", /*#__PURE__*/ _react["default"].createElement("img", {
        src: props.definition.logo,
        className: "IndexCta_MyLogo"
    }), /*#__PURE__*/ _react["default"].createElement("h1", {
        className: "IndexCta_Lead1_5 pointer IndexCta_Lead_First"
    }, (0, _utility.normalizeText)(props.definition.lead)), /*#__PURE__*/ _react["default"].createElement("h1", {
        className: "IndexCta_Lead2 pointer IndexCta_Lead_Second",
        ref: Lead2
    }, (0, _utility.normalizeText)(props.definition.lead2), " ", /*#__PURE__*/ _react["default"].createElement("span", {
        className: "IndexCta_RecordingCircle"
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_Description"
    }, props.definition.description), props.children, !props._loggedIn ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_AfterSignIn",
        ref: AfterSignIn
    }, props.definition.afterSignIn) : /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            gap: ".5rem",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        className: "IndexCta_ButtonStyle ButtonGlowing simpleBtn",
        ref: ButtonAction
    }, props.definition.buttonAfterSignIn))), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_DetailContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "IndexCta_Detail"
    }, props.definition.detail))) : null));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 2345:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "IndexCta", ({
    enumerable: true,
    get: function get() {
        return _IndexCta["default"];
    }
}));
var _IndexCta = _interopRequireDefault(__webpack_require__(7786));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 9054:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _Tooltip = _interopRequireDefault(__webpack_require__(7229));
var _ecommerce = __webpack_require__(6102);
var _utility = __webpack_require__(5329);
var _util = __webpack_require__(8131);
var _AllInclusive = _interopRequireDefault(__webpack_require__(2156));
var _ConfirmationNumber = _interopRequireDefault(__webpack_require__(9605));
var _Stadium = _interopRequireDefault(__webpack_require__(227));
var _ = __webpack_require__(1303);
var _ProductImageManagerModule = _interopRequireDefault(__webpack_require__(6242));
var _uuid = __webpack_require__(5828);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var allowedTypes = [
    "image/jpeg",
    "image/png"
];
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), componentDidMount = _React$useState2[0], setComponentDidMount = _React$useState2[1];
    var _React$useState3 = _react["default"].useState({}), _React$useState4 = _slicedToArray(_React$useState3, 2), selectedStyle = _React$useState4[0], setSelectedStyle = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), currentOption = _React$useState6[0], setCurrentOption = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(null), _React$useState8 = _slicedToArray(_React$useState7, 2), warning = _React$useState8[0], setWarning = _React$useState8[1];
    var optionSelect = _react["default"].useRef();
    var styleSelect = _react["default"].useRef();
    var isTicketRef = _react["default"].useRef();
    var isLivestreamRef = _react["default"].useRef();
    var _React$useState9 = _react["default"].useState(null), _React$useState10 = _slicedToArray(_React$useState9, 2), uploadingForLineupId = _React$useState10[0], setUploadingForLineupId = _React$useState10[1];
    var _React$useState11 = _react["default"].useState(null), _React$useState12 = _slicedToArray(_React$useState11, 2), currentLineupId = _React$useState12[0], setCurrentLineupId = _React$useState12[1];
    var lineupIdRef = _react["default"].useRef();
    var lineupNameRef = _react["default"].useRef();
    var lineupDescriptionRef = _react["default"].useRef();
    var lineupTimeRef = _react["default"].useRef();
    var currency = "$";
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            setComponentDidMount(true);
        }
    }, [
        componentDidMount,
        setComponentDidMount,
        props.product
    ]);
    (0, _ecommerce.resolveDefaultStyle)(props.product, selectedStyle, setSelectedStyle, currentOption, setCurrentOption);
    var updateLineup = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            if (e.currentTarget.getAttribute("option")) {
                var temp = _objectSpread({}, props.product.detailmeta);
                if (e.currentTarget.getAttribute("option") === "add") {
                    if (temp.lineup && temp.lineup.length < 10) {
                        temp.lineup.push(props.defaultLineup());
                        props.setCurrentLineupEditing(temp.lineup.length - 1);
                        setCurrentLineupId(temp.lineup[temp.lineup.length - 1].id);
                        lineupNameRef.current.value = "";
                        lineupDescriptionRef.current.value = "";
                        lineupTimeRef.current.value = null;
                    }
                } else if (e.currentTarget.getAttribute("option") === "remove") {
                    if (temp.lineup && temp.lineup.length > 0) {
                        temp.lineup.pop();
                        props.setCurrentLineupEditing(temp.lineup.length - 1 > -1 ? temp.lineup.length - 1 : null);
                        if (temp.lineup.length !== 0) {
                            setCurrentLineupId(temp.lineup[temp.lineup.length - 1].id);
                        }
                        lineupNameRef.current.value = "";
                        lineupDescriptionRef.current.value = "";
                        lineupTimeRef.current.value = null;
                    }
                } else if (e.currentTarget.getAttribute("option") === "setSelected") {
                    var index = e.currentTarget.getAttribute("index");
                    if (!isNaN(index)) {
                        props.setCurrentLineupEditing(index);
                        setCurrentLineupId(temp.lineup[index].id);
                        lineupNameRef.current.value = temp.lineup[index].title;
                        lineupDescriptionRef.current.value = temp.lineup[index].description;
                        lineupTimeRef.current.value = temp.lineup[index].time;
                    }
                }
            }
        }
    });
    var setSelectedStyleHandler = _react["default"].useCallback(function(e) {
        if (e && e.currentTarget) {
            if (e.currentTarget.value) {
                setSelectedStyle(e.currentTarget.value);
                var currentStyleObject = props.product.styles.find(function(m) {
                    return m.sid === e.currentTarget.value;
                });
                console.log(currentStyleObject);
                if (currentStyleObject && currentStyleObject.option && currentStyleObject.option[0] && currentStyleObject.option[0].sid) {
                    setCurrentOption(currentStyleObject.option[0].sid);
                }
            }
        }
    });
    var changeCurrentOption = _react["default"].useCallback(function(e) {
        setCurrentOption(e.currentTarget.value);
    });
    var handleEdit = _react["default"].useCallback(function(e) {
        console.log(e, "edit");
        if (e && e.currentTarget && e.currentTarget.getAttribute && e.currentTarget.getAttribute("modif")) {
            var modif = e.currentTarget.getAttribute("modif");
            if (modif === "edit" && props.handleEdit) {
                props.handleEdit(props.product);
                setTimeout(function() {
                    props.nameRef.current.value = props.product.name;
                    if (props.product.styles && props.product.styles[0]) {
                        props.styleInput.current.value = props.product.styles[0].style;
                        props.setEditingSelectedStyle(props.product.styles[0].sid);
                        setTimeout(function() {
                            console.log(props, props.product.styles[0].option && props.product.styles[0].option[0]);
                            if (props.product.styles[0].option && props.product.styles[0].option[0]) {
                                if (props.optionInput.current) {
                                    props.optionInput.current.value = props.product.styles[0].option[0].option;
                                }
                                props.setEditingSelectedOption(props.product.styles[0].option[0].sid);
                                props.quantityInput.current.value = props.product.styles[0].option[0].quantity;
                                props.priceInput.current.value = props.product.styles[0].price;
                                console.log(props.product.detailmeta);
                                if (props.product.detailmeta) {
                                    isTicketRef.current.value = props.product.detailmeta.ticket;
                                    isLivestreamRef.current.value = props.product.detailmeta.livestream;
                                }
                                props.setEditingOptionsMeta(props.product.detailmeta);
                            }
                        }, 250);
                    }
                }, 250);
            }
        }
    });
    var handleFireGlobalEvent = _react["default"].useCallback(/*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(e) {
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        (0, _utility.fireGlobalEvent)(e, props._LocalEventEmitter);
                    case 1:
                    case "end":
                        return _context.stop();
                }
            }, _callee);
        }));
        return function(_x2) {
            return _ref.apply(this, arguments);
        };
    }());
    _react["default"].useEffect(function() {
        var useCur = props.currentLineupEditing;
        if (props.currentLineupEditing === null) {
            props.setCurrentLineupEditing(0);
            useCur = 0;
        }
        if (props.editing && props.editing.detailmeta && props.editing.detailmeta.lineup && props.editing.detailmeta.lineup.length > 0 && props.editing.detailmeta.lineup[useCur]) {
            if (lineupNameRef.current) {
                setCurrentLineupId(props.editing.detailmeta.lineup[useCur].id);
                lineupNameRef.current.value = props.editing.detailmeta.lineup[useCur].title;
                lineupDescriptionRef.current.value = props.editing.detailmeta.lineup[useCur].description;
                lineupTimeRef.current.value = props.editing.detailmeta.lineup[useCur].time;
            }
        }
    }, [
        props.currentLineupEditing,
        props.editing.id,
        lineupNameRef.current,
        lineupDescriptionRef.current,
        lineupTimeRef.current
    ]);
    var fileInput = _react["default"].useRef();
    var handleUploadImage = _react["default"].useCallback(function(e) {
        setWarning(null);
        setUploadingForLineupId(e.currentTarget.getAttribute("lineupid"));
        if (fileInput.current) {
            fileInput.current.click(); // Prompt file upload
        }
    });
    var handleNewFile = _react["default"].useCallback(function(e) {
        try {
            if (e && e.target && e.target.files) {
                var files = e.target.files;
                if (files && files.length > 0) {
                    var filesRenamed = Array.from(files).slice(0, files.length > 1 ? 1 : files.length).filter(function(m) {
                        return m.type && allowedTypes.indexOf(m.type) > -1;
                    }).map(function(m) {
                        var blob = m.slice(0, m.size, m.type);
                        var ext = allowedTypes[allowedTypes.indexOf(m.type)].match(/\/([a-zA-Z0-9].*)/)[1];
                        return new File([
                            blob
                        ], "".concat((0, _uuid.v4)(), ".").concat(ext), {
                            type: m.type
                        });
                    });
                    var f = /*#__PURE__*/ function() {
                        var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2() {
                            var formData, imgNames, data, _f;
                            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                                while(1)switch(_context2.prev = _context2.next){
                                    case 0:
                                        if (!(!props.fetchBusy && props.apiUrl && props.domainKey && props._loggedIn && props.editing)) {
                                            _context2.next = 15;
                                            break;
                                        }
                                        formData = new FormData();
                                        imgNames = [];
                                        if (filesRenamed) {
                                            filesRenamed.forEach(function(img) {
                                                formData.append("image", img);
                                                imgNames.push(img.name);
                                            });
                                            formData.append("imgNames", JSON.stringify(imgNames));
                                        }
                                        formData.append("domainKey", props.domainKey);
                                        formData.append("hash", props._loggedIn.hash);
                                        formData.append("identifier", props._loggedIn.identifier);
                                        formData.append("product", props.editing.id);
                                        formData.append("detailmeta", JSON.stringify(props.editing.detailmeta));
                                        formData.append("lineupid", uploadingForLineupId);
                                        if (props.setFetchBusy) {
                                            props.setFetchBusy(true);
                                            setTimeout(function() {
                                                props.setFetchBusy(false);
                                            }, 10000);
                                        }
                                        _context2.next = 13;
                                        return (0, _ecommerce.doUploadImageForLineupParticipant)(props.apiUrl, props.domainKey, props.editing.id, props._loggedIn, formData);
                                    case 13:
                                        data = _context2.sent;
                                        if (data && data.product && data.product.products) {
                                            if (props.setFetchBusy) {
                                                props.setFetchBusy(false);
                                            }
                                            if (props.setShopProducts && props.setCombinedFeed) {
                                                console.log("Set Combined Feed", data.product.products, props.setCombinedFeed);
                                                props.setShopProducts(data.product.products);
                                                props.setCombinedFeed(data.product.products);
                                                if (props.setEditing) {
                                                    _f = data.product.products.find(function(m) {
                                                        return m.id === props.editing.id;
                                                    });
                                                    if (_f) {
                                                        props.setEditing(_f);
                                                    }
                                                }
                                            }
                                        }
                                    case 15:
                                    case "end":
                                        return _context2.stop();
                                }
                            }, _callee2);
                        }));
                        return function f() {
                            return _ref2.apply(this, arguments);
                        };
                    }();
                    f();
                }
            }
        } catch (err) {
            console.log(err);
            setWarning({
                message: "There was an issue uploading images"
            });
        }
    });
    var validStyleObject = selectedStyle && props.product && props.product.styles && props.product.styles.find(function(m) {
        return m.sid === selectedStyle;
    }) ? props.product.styles.find(function(m) {
        return m.sid === selectedStyle;
    }) : null;
    var validOptionObject = validStyleObject && validStyleObject.option ? currentOption ? validStyleObject.option.find(function(m) {
        return m.sid === currentOption;
    }) : validStyleObject.option[0] ? validStyleObject.option[0] : null : null;
    // console.log(props.product, props._loggedIn, currentOption, selectedStyle, props)
    var isAdmin = props.product && props.product.owner && props._loggedIn && props._loggedIn.identifier && props._loggedIn.identifier === props.product.owner;
    console.log(props.product, props.editingOptionsMeta, selectedStyle, currency);
    var currentPrice = _react["default"].useMemo(function() {
        return (0, _ecommerce.resolveCurrentPrice)(props.product, selectedStyle, currency);
    }, [
        props.product,
        selectedStyle,
        currency
    ]);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_col ".concat(props.className),
        id: props.product && props.product.id ? props.product.id : "",
        selectedstyle: validStyleObject !== null && validStyleObject !== void 0 && validStyleObject.sid ? validStyleObject.sid : "",
        currentoption: validOptionObject !== null && validOptionObject !== void 0 && validOptionObject.sid ? validOptionObject.sid : ""
    }, props.editing && props.editing.id && props.product && props.editing.id === props.product.id ? /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_img_container"
    }, /*#__PURE__*/ _react["default"].createElement(_.ProductImageManager, props)), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_meta_container"
    }, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Name of Product",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        name: "name",
        placeholder: "Product Name",
        style: {
            width: "100%"
        },
        onChange: props.setCurrentName,
        ref: props.nameRef,
        modif: "product_name"
    })), props.pageError.location && props.pageError.location === "product_name" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "error"
    }, props.pageError.message) : null), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "If your product has multiple styles, set them here. A style should be an alternate design or color for a single product that you want to track as single product. For example you might have white, black, grey for t-shirts as individual styles.",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "Style:"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "dropdown_input"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        ref: props.styleInput,
        onChange: props.setCurrentStyleName
    }), /*#__PURE__*/ _react["default"].createElement("select", {
        id: props.editing.id + "_styles",
        name: props.editing.id + "_styles",
        style: {
            width: "100%"
        },
        onChange: props.changeCurrentStyle
    }, props.resolveStyles(props.editing).map(function(style, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: style.sid,
            className: "style_option",
            key: i
        }, style.style);
    }))))), props.selectedStyle && props.selectedStyle.option.length > 0 && props.selectedStyle.option[0] && Object.hasOwnProperty.call(props.selectedStyle.option[0], "option") ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "If your product has options, set them here. An option should be a sizing or format choice that exists for all or most styles. For example you might have sizes XS, S, M, L, XL or OS as individual options per style.",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "Option:"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "dropdown_input"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        ref: props.optionInput,
        onChange: props.setCurrentOptionName
    }), /*#__PURE__*/ _react["default"].createElement("select", {
        id: props.editing.id + "_options",
        name: props.editing.id + "_options",
        style: {
            width: "100%"
        },
        onChange: props.changeCurrentOption,
        ref: props.optionSelect
    }, props.editing.styles.find(function(m) {
        return m.sid === props.editingSelectedStyle;
    }).option.map(function(option, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: option.sid,
            className: "option_option",
            key: i
        }, option.option);
    }))))) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the price for the currently selected Style"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "$")), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "currency",
        style: {
            width: "100%"
        },
        defaultValue: "1.00",
        ref: props.priceInput,
        onChange: props.setCurrentPrice
    }), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the quantity for the currently selected Style & Option combo"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600,
            display: props.selectedOption && props.selectedOption.quantity && props.selectedOption.quantity === 10000000 ? "none" : "block"
        }
    }, "Qty")), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "number",
        style: {
            width: "100%",
            display: props.selectedOption && props.selectedOption.quantity && props.selectedOption.quantity === 10000000 ? "none" : "block"
        },
        defaultValue: "1",
        ref: props.quantityInput,
        onChange: props.setCurrentQuantity
    }), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Infinite stock"
    }, /*#__PURE__*/ _react["default"].createElement(_AllInclusive["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        onChange: props.setInfinity,
        checked: props.selectedOption && props.selectedOption.quantity && props.selectedOption.quantity === 10000000
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 Product_admin_choice_container"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: props.addStyle
    }, "Add Style"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: props.addOption
    }, "Add Option")), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center",
            height: "18px"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the product type"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600,
            paddingTop: ".2rem"
        }
    }, "Type: ")), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            fontSize: ".8rem",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "radio",
        id: "virtual",
        name: "fav_language",
        value: "virtual",
        defaultChecked: true,
        onChange: props.onProductTypeChange
    }), /*#__PURE__*/ _react["default"].createElement("label", {
        "for": "virtual"
    }, "Virtual"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "radio",
        id: "physical",
        name: "fav_language",
        value: "physical",
        onChange: props.onProductTypeChange
    }), /*#__PURE__*/ _react["default"].createElement("label", {
        "for": "physical"
    }, "Physical"))), props.product.detailmeta && props.product.detailmeta.productType === "virtual" ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 promptContainer",
        style: {
            alignItems: "center",
            height: "20px",
            borderRadius: ".5rem",
            margin: ".25rem 0"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Ticketed Products offer universally unique ids that are unique across the product being sold and can be stamped onto Virtual Ticket Images",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Is this a ticket?"), /*#__PURE__*/ _react["default"].createElement(_ConfirmationNumber["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        value: props.product.detailmeta.ticket,
        defaultChecked: props.product.detailmeta.ticket,
        onChange: props.setOptionsMetaData,
        option: "ticket",
        ref: isTicketRef
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "promptContainer",
        style: {
            borderRadius: ".5rem",
            margin: ".25rem 0"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center",
            height: "20px"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "You can use a date to authorize all users that purchase this ticket for access to your livestreams on that day. Or you can use a tag that you must include in the livestream tags field when you create it. Please use this if you want to put your livestream behind this paywalled purchase",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Is this for a livestream?"), /*#__PURE__*/ _react["default"].createElement(_Stadium["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        value: props.product.detailmeta.livestream,
        defaultChecked: props.product.detailmeta.livestream,
        onChange: props.setOptionsMetaData,
        option: "livestream",
        ref: isLivestreamRef
    })), props.product.detailmeta.livestream ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            paddingBottom: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter dates or words for matching authorization. Enter dates in the following format MON-DD-YYYY-HH:MM or they will not be parsed as dates. Time must be input in 24 H military time. Values that do not match dates will be parsed as tags that can be added to livestreams. Any matches will authorize viewership of the stream for purchases of this ticket",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        style: {
            marginBottom: ".125rem",
            width: "-webkit-fill-available"
        },
        placeholder: "Date in DD/MM/YY format or a tag",
        onInput: props.setOptionsMetaData,
        option: "livestreamDef",
        option2: "input",
        defaultValue: props.product.detailmeta.livestreamDef.input
    })), props.product.detailmeta.livestreamDef.dates.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, props.product.detailmeta.livestreamDef.dates.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d ? (0, _util.getFormattedDate)(d, {
            pretty: true
        }) : "");
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), props.product.detailmeta.livestreamDef.tags.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, props.product.detailmeta.livestreamDef.tags.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d);
    })) : /*#__PURE__*/ _react["default"].createElement("div", null)) : null, props.product.detailmeta.ticket ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Date for Event"), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter dates in the following format MON-DD-YYYY-HH:MM or they will not be parsed as dates. Time must be input in 24 H military time. Values that do not match dates will be parsed as tags that can be added to livestreams. Any matches will authorize viewership of the stream for purchases of this ticket",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        style: {
            marginBottom: ".125rem",
            width: "-webkit-fill-available"
        },
        placeholder: "Date in MON-DD-YYYY-HH:MM format. If the ticket does not have an event date leave empty",
        onInput: props.setOptionsMetaData,
        option: "eventDateDef",
        option2: "input",
        defaultValue: props.product.detailmeta.eventDateDef.input
    })), props.product.detailmeta.eventDateDef.dates.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, props.product.detailmeta.eventDateDef.dates.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d ? (0, _util.getFormattedDate)(d, {
            pretty: true
        }) : "");
    })) : /*#__PURE__*/ _react["default"].createElement("div", null)) : null, props.product.detailmeta.livestream ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            background: "#222222",
            marginTop: ".25rem",
            marginBottom: ".25rem",
            borderRadius: ".25rem",
            padding: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: "600"
        }
    }, "Lineup"), props.product.detailmeta.lineup && props.product.detailmeta.lineup.length < 10 || !props.product.detailmeta.lineup ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".6rem"
        },
        ref: lineupIdRef
    }, currentLineupId !== null && currentLineupId !== void 0 ? currentLineupId : ""), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter participants name",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        placeholder: "Name",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: props.setOptionsMetaData,
        option: "lineupTemp",
        option2: "title",
        ref: lineupNameRef
    })), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Optional: Enter description of participant",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        placeholder: "Description",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: props.setOptionsMetaData,
        option: "lineupTemp",
        option2: "description",
        ref: lineupDescriptionRef
    })), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Optional: Enter expected time for lineup participant to be performing",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "time",
        placeholder: "Time",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: props.setOptionsMetaData,
        option: "lineupTemp",
        option2: "time",
        ref: lineupTimeRef
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, props.product.detailmeta.lineup && props.product.detailmeta.lineup.length < 10 && props.product.detailmeta.lineup.length > 0 ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Add another Lineup Participant",
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%"
        },
        onClick: updateLineup,
        option: "add"
    }, "Add")) : null, props.product.detailmeta.lineup && props.product.detailmeta.lineup[props.currentLineupEditing] ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Remove this Lineup Participant",
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%"
        },
        onClick: updateLineup,
        option: "remove"
    }, "Remove")) : null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            overflow: "auto",
            marginTop: ".125rem"
        }
    }, props.product.detailmeta.lineup && props.product.detailmeta.lineup.map ? props.product.detailmeta.lineup.map(function(m, i) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_editing ".concat(m.id === currentLineupId ? "lineupItem_current" : ""),
            style: {
                maxWidth: "75px"
            },
            onClick: updateLineup,
            option: "setSelected",
            index: i,
            key: i
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            style: {
                fontSize: ".7rem",
                fontWeight: "600",
                overflowWrap: "anywhere"
            }
        }, m.title !== "" ? m.title : /*#__PURE__*/ _react["default"].createElement("div", {
            style: {
                opacity: ".7"
            }
        }, "Participant")), /*#__PURE__*/ _react["default"].createElement("div", {
            style: {
                marginTop: ".125rem"
            }
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "ProductImageManager_container",
            style: {
                position: "relative",
                width: "68px",
                height: "68px"
            }
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_ProductImageManagerModule["default"].productImageListThumbnailContainer),
            style: {
                backgroundImage: "url(".concat(props.cdn["static"], "/").concat(m.image, ")"),
                height: "68px",
                backgroundSize: "cover",
                borderRadius: "1rem"
            }
        }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
            title: "Click here to upload an image for your lineup participant",
            placement: "bottom"
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_ProductImageManagerModule["default"].changeImageButtonSmall, " image material-icons"),
            onClick: handleUploadImage,
            lineupid: m.id
        }, "image")), /*#__PURE__*/ _react["default"].createElement("img", {
            src: "".concat((0, _ecommerce.resolveImg)(null)),
            className: "Product_img",
            style: {
                width: "68px",
                height: "68px",
                borderRadius: "1rem",
                opacity: m.image ? 0 : 1
            }
        })))), m.time ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_time",
            style: {
                fontSize: "1rem"
            }
        }, (0, _util.getFormattedTime)(m.time, {
            simple: true
        })) : null, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_id",
            style: {
                fontSize: ".5rem",
                overflow: "hidden",
                whiteSpace: "nowrap"
            }
        }, m.id));
    }) : null)) : null) : null), warning && warning.message ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warning)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warningItemContainer)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warningItem)
    }, warning.message))) : null, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "file",
        style: {
            display: "none"
        },
        ref: fileInput,
        onChange: handleNewFile
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 Product_admin_choice_container",
        style: {
            marginTop: ".125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: props.handlePublishProduct,
        modif: "publish",
        existing: "true"
    }, "Publish"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: props.handlePublishProduct,
        modif: "save",
        existing: "true"
    }, "Save"), props.editing ? /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: props.handleCancelProduct,
        modif: "save"
    }, props.editing["new"] ? "Abandon" : "Cancel") : null))) : /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_img_container"
    }, /*#__PURE__*/ _react["default"].createElement(_.ProductImageManager, {
        cdn: props.cdn,
        product: props.product,
        _loggedIn: props._loggedIn,
        domainKey: props.domainKey,
        apiUrl: props.apiUrl,
        setShopProducts: props.setShopProducts,
        setCombinedFeed: props.setCombinedFeed
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_meta_container"
    }, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", null, props.product.name)), props.product && props.product.styles && props.product.styles.length > 1 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("select", {
        id: props.product.id + "_styles",
        name: props.product.id + "_styles",
        style: {
            width: "100%"
        },
        onChange: setSelectedStyleHandler,
        ref: styleSelect
    }, (0, _ecommerce.resolveStyles)(props.product).map(function(style, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: style.sid,
            className: "style_option",
            key: i
        }, style.style);
    }))) : null, validStyleObject && validStyleObject.option && validStyleObject.option[0] && validStyleObject.option[0].option // Only show if base option is named (non default option for tracking quantity)
     ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "dropdown_input"
    }, /*#__PURE__*/ _react["default"].createElement("select", {
        id: props.product.id + "_options",
        name: props.product.id + "_options",
        style: {
            width: "100%"
        },
        onChange: changeCurrentOption,
        ref: optionSelect
    }, props.product.styles.find(function(m) {
        return m.sid === selectedStyle;
    }).option.map(function(option, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: option.sid,
            className: "option_option",
            key: i
        }, option.option);
    })))) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, currentPrice), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "none",
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, validOptionObject && validOptionObject.quantity ? validOptionObject.quantity : "")), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 Product_admin_choice_container",
        style: {
            marginTop: ".125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleFireGlobalEvent,
        item: props.product.id,
        selectedstyle: selectedStyle,
        currentoption: currentOption,
        action: "buy"
    }, "Buy Now"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleFireGlobalEvent,
        item: props.product.id,
        selectedstyle: selectedStyle,
        currentoption: currentOption,
        action: "add_to_cart"
    }, "Add To Cart"), isAdmin ? /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleEdit,
        modif: "edit",
        alt: "edit"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "edit material-icons",
        style: {
            fontSize: "1rem"
        }
    }, "edit")) : null))));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 8996:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _ecommerce = __webpack_require__(6102);
var _util = __webpack_require__(8131);
var _Tooltip = _interopRequireDefault(__webpack_require__(7229));
var _ProductImageManagerModule = _interopRequireDefault(__webpack_require__(6242));
var _uuid = __webpack_require__(5828);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var allowedTypes = [
    "image/jpeg",
    "image/png"
];
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), componentDidMount = _React$useState2[0], setComponentDidMount = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(null), _React$useState4 = _slicedToArray(_React$useState3, 2), warning = _React$useState4[0], setWarning = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), useImage = _React$useState6[0], setUseImage = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(null), _React$useState8 = _slicedToArray(_React$useState7, 2), itemId = _React$useState8[0], setItemId = _React$useState8[1];
    var _React$useState9 = _react["default"].useState(0), _React$useState10 = _slicedToArray(_React$useState9, 2), currentlySelectedImage = _React$useState10[0], setCurrentlySelectedImage = _React$useState10[1];
    var _React$useState11 = _react["default"].useState([]), _React$useState12 = _slicedToArray(_React$useState11, 2), imageThumbnailFeed = _React$useState12[0], setImageThumbnailFeed = _React$useState12[1];
    var fileInput = _react["default"].useRef();
    var productImageRef = _react["default"].useRef();
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            setComponentDidMount(true);
        }
    }, [
        componentDidMount,
        setComponentDidMount,
        props.product
    ]);
    _react["default"].useEffect(function() {
        if (props.product && props.product.id !== itemId) {
            setItemId(props.product.id);
            setUseImage(null);
            setCurrentlySelectedImage(0);
        }
    }, [
        props.product
    ]);
    var handleUploadImage = _react["default"].useCallback(function(e) {
        setWarning(null);
        if (fileInput.current) {
            fileInput.current.click(); // Prompt file upload
        }
    });
    var handleNewFile = _react["default"].useCallback(function(e) {
        try {
            if (e && e.target && e.target.files) {
                var files = e.target.files;
                if (files && files.length > 0) {
                    var filesRenamed = Array.from(files).slice(0, files.length > 4 ? 4 : files.length).filter(function(m) {
                        return m.type && allowedTypes.indexOf(m.type) > -1;
                    }).map(function(m) {
                        var blob = m.slice(0, m.size, m.type);
                        var ext = allowedTypes[allowedTypes.indexOf(m.type)].match(/\/([a-zA-Z0-9].*)/)[1];
                        return new File([
                            blob
                        ], "".concat((0, _uuid.v4)(), ".").concat(ext), {
                            type: m.type
                        });
                    });
                    var n = props.editing && props.editing["new"];
                    if (n && props.passTempImages) {
                        // Product not created yet, do not upload image. We can load image as temp image to show user
                        props.passTempImages(filesRenamed);
                        var reader = new FileReader();
                        reader.onload = function(event) {
                            setUseImage(event.target.result);
                        };
                        reader.readAsDataURL(filesRenamed[0]);
                    } else {
                        // Product created already, immediately upload
                        try {
                            var f = /*#__PURE__*/ function() {
                                var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                                    var formData, imgNames, data, _f;
                                    return _regeneratorRuntime().wrap(function _callee$(_context) {
                                        while(1)switch(_context.prev = _context.next){
                                            case 0:
                                                if (!(!props.fetchBusy && props.apiUrl && props.domainKey && props._loggedIn && props.editing)) {
                                                    _context.next = 13;
                                                    break;
                                                }
                                                formData = new FormData();
                                                imgNames = [];
                                                if (filesRenamed) {
                                                    filesRenamed.forEach(function(img) {
                                                        formData.append("image", img);
                                                        imgNames.push(img.name);
                                                    });
                                                    formData.append("imgNames", JSON.stringify(imgNames));
                                                }
                                                formData.append("domainKey", props.domainKey);
                                                formData.append("hash", props._loggedIn.hash);
                                                formData.append("identifier", props._loggedIn.identifier);
                                                formData.append("product", props.editing.id);
                                                if (props.setFetchBusy) {
                                                    props.setFetchBusy(true);
                                                    setTimeout(function() {
                                                        props.setFetchBusy(false);
                                                    }, 10000);
                                                }
                                                _context.next = 11;
                                                return (0, _ecommerce.doUploadImageForProduct)(props.apiUrl, props.domainKey, props.editing.id, props._loggedIn, formData);
                                            case 11:
                                                data = _context.sent;
                                                if (data && data.product && data.product.products) {
                                                    if (props.setShopProducts && props.setCombinedFeed) {
                                                        props.setShopProducts(data.product.products);
                                                        props.setCombinedFeed(data.product.products);
                                                        if (props.setEditing) {
                                                            _f = data.product.products.find(function(m) {
                                                                return m.id === props.editing.id;
                                                            });
                                                            if (_f) {
                                                                props.setEditing(_f);
                                                            }
                                                        }
                                                    }
                                                    if (props.setFetchBusy) {
                                                        props.setFetchBusy(false);
                                                    }
                                                }
                                            case 13:
                                            case "end":
                                                return _context.stop();
                                        }
                                    }, _callee);
                                }));
                                return function f() {
                                    return _ref.apply(this, arguments);
                                };
                            }();
                            f();
                        } catch (err) {
                        // fail silently
                        }
                    }
                }
            }
        } catch (err) {
            console.log(err);
            setWarning({
                message: "There was an issue uploading images"
            });
        }
    });
    _react["default"].useEffect(function() {
        if (props.editing && !props.editing["new"]) {
            if (!useImage) {
                if (props.editing.images && props.editing.images[0] && props.editing.images[0].name && props.cdn && props.cdn["static"]) {
                    setUseImage(props.cdn["static"] + "/" + props.editing.images[0].name);
                }
            }
        }
        if (props.product) {
            if (!useImage) {
                if (props.product.images && props.product.images[0] && props.product.images[0].name && props.cdn && props.cdn["static"]) {
                    setUseImage(props.cdn["static"] + "/" + props.product.images[0].name);
                }
            }
        }
    }, [
        props.editing,
        useImage,
        props.product
    ]);
    _react["default"].useEffect(function() {
        console.log(props.editing, props.product);
        if (props.editing) {
            setImageThumbnailFeed(props.editing.images);
        } else if (props.product) {
            setImageThumbnailFeed([]);
        }
    }, [
        props.editing,
        props.product
    ]);
    // select container
    // .on("mouseover", function() {
    //     $(this)
    //       .children(".img_producto")
    //       .css({ transform: "scale(" + $(this).attr("data-scale") + ")" });
    //   })
    //   .on("mouseout", function() {
    //     $(this)
    //       .children(".img_producto")
    //       .css({ transform: "scale(1)" });
    //   })
    //   .on("mousemove", function(e) {
    //     $(this)
    //       .children(".img_producto")
    //       .css({
    //         "transform-origin":
    //           ((e.pageX - $(this).offset().left) / $(this).width()) * 100 +
    //           "% " +
    //           ((e.pageY - $(this).offset().top) / $(this).height()) * 100 +
    //           "%"
    //       });
    console.log(imageThumbnailFeed);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className, " ProductImageManager_container"),
        style: {
            position: "relative"
        }
    }, props.editing && !(0, _util.isObjectEmpty)(props.editing) ? /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "file",
        style: {
            display: "none"
        },
        ref: fileInput,
        onChange: handleNewFile
    }), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Click here to upload an image for your product",
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].changeImageButton, " image material-icons"),
        onClick: handleUploadImage
    }, "image")), warning && warning.message ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warning)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warningItemContainer)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].warningItem)
    }, warning.message))) : null) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].productImageListContainer)
    }, imageThumbnailFeed && imageThumbnailFeed.map && props.cdn && props.cdn["static"] ? imageThumbnailFeed.map(function(m) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_ProductImageManagerModule["default"].productImageListThumbnailContainer),
            style: {
                backgroundImage: "url(".concat(props.cdn["static"], "/").concat(m.name, ")")
            }
        }, /*#__PURE__*/ _react["default"].createElement("img", {
            src: (0, _ecommerce.resolveImg)(props.editing, props.cdn),
            className: "Product_img",
            style: {
                width: "45px",
                opacity: useImage ? 0 : 1
            }
        }));
    }) : null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ProductImageManagerModule["default"].productImageContainer),
        ref: productImageRef,
        style: {
            backgroundImage: useImage ? "url(".concat(useImage, ")") : ""
        }
    }, /*#__PURE__*/ _react["default"].createElement("img", {
        src: (0, _ecommerce.resolveImg)(props.editing, props.cdn),
        style: {
            opacity: useImage ? 0 : 1
        },
        className: "Product_img"
    })));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 1303:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "Product", ({
    enumerable: true,
    get: function get() {
        return _Product["default"];
    }
}));
Object.defineProperty(exports, "ProductImageManager", ({
    enumerable: true,
    get: function get() {
        return _ProductImageManager["default"];
    }
}));
var _Product = _interopRequireDefault(__webpack_require__(9054));
var _ProductImageManager = _interopRequireDefault(__webpack_require__(8996));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 1628:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _ReceiptPageModule = _interopRequireDefault(__webpack_require__(3548));
var _ecommerce = __webpack_require__(6102);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _receiptData$totals, _receiptData$paymentm, _receiptData$paymentm2, _receiptData$meta, _card$brand, _card$last;
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), fetchBusy = _React$useState2[0], setFetchBusy = _React$useState2[1];
    var resolveStyle = function resolveStyle(p, s) {
        if (p && p.styles && s) {
            var f = p.styles.find(function(m) {
                return m.sid === s;
            });
            if (f && f.style) {
                return f.style;
            }
        }
        return "";
    };
    var resolveOption = function resolveOption(p, s, o) {
        if (p && p.styles && s) {
            var f = p.styles.find(function(m) {
                return m.sid === s;
            });
            if (f.option) {
                console.log(f.option);
                var f2 = f.option.find(function(m) {
                    return m.sid === o;
                });
                if (f2 && f2.option) {
                    return f2.option;
                }
            }
        }
        return "";
    };
    var receiptData = props === null || props === void 0 ? void 0 : props.receiptData;
    var currency = receiptData === null || receiptData === void 0 ? void 0 : receiptData.currency;
    var cartTotal = receiptData === null || receiptData === void 0 ? void 0 : (_receiptData$totals = receiptData.totals) === null || _receiptData$totals === void 0 ? void 0 : _receiptData$totals.total;
    var creation = receiptData !== null && receiptData !== void 0 && receiptData.creation && !isNaN(new Date(Number(receiptData.creation))) ? new Date(Number(receiptData.creation)).toString() : "";
    var card = receiptData !== null && receiptData !== void 0 && (_receiptData$paymentm = receiptData.paymentmethoddetails) !== null && _receiptData$paymentm !== void 0 && _receiptData$paymentm.card ? receiptData.paymentmethoddetails.card : null;
    var cardBilling = receiptData !== null && receiptData !== void 0 && (_receiptData$paymentm2 = receiptData.paymentmethoddetails) !== null && _receiptData$paymentm2 !== void 0 && _receiptData$paymentm2.billing_details ? receiptData.paymentmethoddetails.billing_details : null;
    console.log(receiptData);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, receiptData ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            padding: "1rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: _ReceiptPageModule["default"].pair
    }, /*#__PURE__*/ _react["default"].createElement("h3", {
        style: {
            marginTop: "0",
            marginBottom: ".25rem"
        }
    }, "Order ", receiptData.id), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".7rem"
        }
    }, creation)), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ReceiptPageModule["default"].container, " ReceiptPage_container")
    }, /*#__PURE__*/ _react["default"].createElement("div", null, receiptData !== null && receiptData !== void 0 && receiptData.cart && Array.isArray(receiptData.cart) ? receiptData.cart.map(function(m, i) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            key: i,
            className: "".concat(i !== 0 ? "separator_top_dashed" : "", " ReceiptPage_product"),
            style: {
                fontSize: ".8rem"
            }
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: _ReceiptPageModule["default"].pair
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "ReceiptPage_product_name"
        }, m.product.name), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "ReceiptPage_product_cost"
        }, "$", (0, _ecommerce.resolveMoneyFormat)(m.total), " ", currency.toUpperCase())), /*#__PURE__*/ _react["default"].createElement("div", {
            className: _ReceiptPageModule["default"].pair,
            style: {
                fontSize: ".7rem"
            }
        }, /*#__PURE__*/ _react["default"].createElement("div", null, resolveStyle(m.product, m.style)), /*#__PURE__*/ _react["default"].createElement("div", null, resolveOption(m.product, m.style, m.option))));
    }) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ReceiptPageModule["default"].pair, " separator_top")
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontWeight: 600,
            lineHeight: "1.25rem"
        }
    }, "Total"), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontWeight: 600,
            lineHeight: "1.25rem"
        }
    }, "$", cartTotal ? (0, _ecommerce.resolveMoneyFormat)(cartTotal) : "", " ", currency.toUpperCase()))), /*#__PURE__*/ _react["default"].createElement("div", null, receiptData.paymentfulfilled ? /*#__PURE__*/ _react["default"].createElement("div", null, receiptData !== null && receiptData !== void 0 && (_receiptData$meta = receiptData.meta) !== null && _receiptData$meta !== void 0 && _receiptData$meta.charged && currency ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: _ReceiptPageModule["default"].pair,
        style: {
            fontSize: ".7rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", null, "Paid $", (0, _ecommerce.resolveMoneyFormat)(receiptData.amountcaptured), " ", currency.toUpperCase(), " on ", new Date(receiptData.meta.charged).toLocaleDateString()), /*#__PURE__*/ _react["default"].createElement("div", null, card ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            gap: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", null, (_card$brand = card.brand) !== null && _card$brand !== void 0 ? _card$brand : ""), /*#__PURE__*/ _react["default"].createElement("div", null, (_card$last = card.last4) !== null && _card$last !== void 0 ? _card$last : ""), /*#__PURE__*/ _react["default"].createElement("div", null, cardBilling !== null && cardBilling !== void 0 && cardBilling.name ? cardBilling.name : "")) : null)) : "") : /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".75rem"
        }
    }, "Payment Unfulfilled"))))) : null);
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 190:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "ReceiptPage", ({
    enumerable: true,
    get: function get() {
        return _ReceiptPage["default"];
    }
}));
var _ReceiptPage = _interopRequireDefault(__webpack_require__(1628));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 6363:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _gridList = _interopRequireDefault(__webpack_require__(542));
var _ShopModule = _interopRequireDefault(__webpack_require__(5305));
var _util = __webpack_require__(8131);
var _uuid = __webpack_require__(5828);
var _AllInclusive = _interopRequireDefault(__webpack_require__(2156));
var _ConfirmationNumber = _interopRequireDefault(__webpack_require__(9605));
var _Stadium = _interopRequireDefault(__webpack_require__(227));
var _Tooltip = _interopRequireDefault(__webpack_require__(7229));
var _ecommerce = __webpack_require__(6102);
var _product = __webpack_require__(1303);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _selectedStyle$option;
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), fetchBusy = _React$useState2[0], setFetchBusy = _React$useState2[1];
    var _React$useState3 = _react["default"].useState({}), _React$useState4 = _slicedToArray(_React$useState3, 2), currentSelected = _React$useState4[0], setCurrentSelected = _React$useState4[1];
    var _React$useState5 = _react["default"].useState([]), _React$useState6 = _slicedToArray(_React$useState5, 2), feed = _React$useState6[0], setFeed = _React$useState6[1];
    var _React$useState7 = _react["default"].useState([]), _React$useState8 = _slicedToArray(_React$useState7, 2), combinedFeed = _React$useState8[0], setCombinedFeed = _React$useState8[1];
    var _React$useState9 = _react["default"].useState({}), _React$useState10 = _slicedToArray(_React$useState9, 2), editing = _React$useState10[0], setEditing = _React$useState10[1];
    var _React$useState11 = _react["default"].useState(null), _React$useState12 = _slicedToArray(_React$useState11, 2), editingSelectedStyle = _React$useState12[0], setEditingSelectedStyle = _React$useState12[1];
    var _React$useState13 = _react["default"].useState(null), _React$useState14 = _slicedToArray(_React$useState13, 2), editingSelectedOption = _React$useState14[0], setEditingSelectedOption = _React$useState14[1];
    var _React$useState15 = _react["default"].useState({
        productType: "virtual",
        ticket: false,
        livestream: false,
        livestreamDef: {
            dates: [],
            tags: [],
            input: ""
        },
        eventDateDef: {
            dates: [],
            input: ""
        },
        lineup: []
    }), _React$useState16 = _slicedToArray(_React$useState15, 2), editingOptionsMeta = _React$useState16[0], setEditingOptionsMeta = _React$useState16[1];
    var _React$useState17 = _react["default"].useState(null), _React$useState18 = _slicedToArray(_React$useState17, 2), shop = _React$useState18[0], setShop = _React$useState18[1];
    var _React$useState19 = _react["default"].useState(null), _React$useState20 = _slicedToArray(_React$useState19, 2), shopProducts = _React$useState20[0], setShopProducts = _React$useState20[1];
    var _React$useState21 = _react["default"].useState({}), _React$useState22 = _slicedToArray(_React$useState21, 2), pageError = _React$useState22[0], setPageError = _React$useState22[1];
    var _React$useState23 = _react["default"].useState(null), _React$useState24 = _slicedToArray(_React$useState23, 2), tempImagesForCurrentlyEditing = _React$useState24[0], setTempImagesForCurrentlyEditing = _React$useState24[1];
    var _React$useState25 = _react["default"].useState(null), _React$useState26 = _slicedToArray(_React$useState25, 2), currentLineupEditing = _React$useState26[0], setCurrentLineupEditing = _React$useState26[1];
    var styleInput = _react["default"].useRef();
    var optionInput = _react["default"].useRef();
    var quantityInput = _react["default"].useRef();
    var priceInput = _react["default"].useRef();
    var optionSelect = _react["default"].useRef();
    var nameRef = _react["default"].useRef();
    var lineupNameRef = _react["default"].useRef();
    var lineupDescriptionRef = _react["default"].useRef();
    var lineupTimeRef = _react["default"].useRef();
    _react["default"].useEffect(function() {
        var selector = props.profile ? "shopProfileData" : "shop";
        if (props && props[selector]) {
            var f = props[selector].products && Array.isArray(props[selector].products) ? props[selector].products.concat(feed) : [];
            var s = props[selector].shop;
            var update = false;
            for(var i = 0; i < combinedFeed.length; i++){
                if (!(0, _util.compareObjects)(combinedFeed, f)) {
                    update = true;
                    break;
                }
            }
            if (!shop || !s || s && !s.id) {
                setShop(s);
            }
            if (!shopProducts) {
                setShopProducts(f);
            }
            if (combinedFeed.length === 0 && f.length !== 0) {
                setCombinedFeed(f);
            }
        }
    }, [
        props.shopData,
        props.shopProfileData,
        feed,
        combinedFeed
    ]);
    var defaultOption = function defaultOption() {
        var addOption = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;
        var o = {
            sid: (0, _uuid.v4)(),
            quantity: 1
        };
        if (addOption) {
            o.option = "";
        }
        return o;
    };
    var defaultStyle = function defaultStyle() {
        return {
            price: 1,
            sid: (0, _uuid.v4)(),
            style: "",
            option: [
                defaultOption(false)
            ]
        };
    };
    var defaultLineup = function defaultLineup() {
        return {
            id: (0, _uuid.v4)(),
            title: "",
            description: "",
            time: null,
            image: ""
        };
    };
    var adminAuth = props._loggedIn && props._loggedIn.identifier && props.profileData && props.profileData.user && props.profileData.user.id && props._loggedIn.identifier === props.profileData.user.id;
    var handleEdit = function handleEdit(product) {
        console.log(product);
        if (shop && shop.id) {
            setEditing(product);
            setTimeout(function() {
                var temp = _objectSpread({}, product);
                temp.name = product.name;
                setEditing(temp);
            }, 200);
        }
    };
    var createNewProduct = _react["default"].useCallback(function(e) {
        try {
            console.log(e);
            if (shop && shop.id && (0, _util.isObjectEmpty)(editing)) {
                var style = defaultStyle();
                var product = {
                    id: (0, _uuid.v4)(),
                    shop: shop.id,
                    name: "",
                    detailmeta: {},
                    styles: [
                        style
                    ],
                    shipping: [],
                    published: false,
                    images: [],
                    protype: {
                        type: "virtual"
                    },
                    infinite: false,
                    meta: {},
                    files: {},
                    "new": true
                };
                setEditing(product);
                setEditingSelectedStyle(style.sid);
                var tempMeta = editingOptionsMeta;
                tempMeta.productType = "virtual";
                setEditingOptionsMeta(tempMeta);
                setTimeout(function() {
                    styleInput.current.value = style.style;
                    if (style.option[0] && Object.hasOwnProperty.call(style.option[0], "option")) {
                        optionInput.current.value = style.option[0].option;
                    }
                }, 200);
            }
        // create template for new product
        } catch (err) {
            console.log(err); // fail silently
        }
    });
    var handleCancelProduct = _react["default"].useCallback(function(e) {
        setEditing({});
    });
    var resolveOptions = function resolveOptions(product) {
        if (product && product.styles) {
            var f = product.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                return product.styles[f].option;
            }
        }
        return [];
    };
    var resolveOption = function resolveOption(option, prop) {
        console.log(option);
        var o = option.find(function(m) {
            return m.sid === editingSelectedOption;
        });
        if (o) {
            return o[prop];
        }
        return null;
    };
    var setCurrentStyleName = _react["default"].useCallback(function(e) {
        console.log(e.currentTarget.value);
        if (e.currentTarget) {
            var temp = _objectSpread({}, editing);
            var f = editing.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                temp.styles[f].style = e.currentTarget.value;
            }
            setEditing(temp);
        }
    });
    var setCurrentOptionName = _react["default"].useCallback(function(e) {
        console.log(e.currentTarget.value, editingSelectedOption);
        if (e.currentTarget) {
            var temp = _objectSpread({}, editing);
            var f = temp.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                if (editingSelectedOption == null) {
                    setEditingSelectedOption(editing.styles[f].option && editing.styles[f].option[0] ? editing.styles[f].option[0].sid : "");
                }
                console.log(f, temp.styles[f].option, editingSelectedOption);
                var f2 = temp.styles[f].option.findIndex(function(m) {
                    return m.sid === editingSelectedOption;
                });
                console.log(f2);
                if (f2 > -1) {
                    temp.styles[f].option[f2].option = e.currentTarget.value;
                }
                setEditing(temp);
            }
        }
    });
    var setCurrentQuantity = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            var temp = _objectSpread({}, editing);
            var f = temp.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                console.log(f, editingSelectedStyle, temp);
                var f2 = temp.styles[f].option.length === 1 ? 0 : temp.styles[f].option.findIndex(function(m) {
                    return m.sid === editingSelectedOption;
                });
                console.log(f2);
                if (f2 > -1) {
                    if (!isNaN(Number(e.currentTarget.value))) {
                        temp.styles[f].option[f2].quantity = Number(e.currentTarget.value);
                    }
                }
                setEditing(temp);
            }
        }
    });
    var setInfinity = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            var temp = _objectSpread({}, editing);
            var f = temp.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                var f2 = temp.styles[f].option.length === 1 ? 0 : temp.styles[f].option.findIndex(function(m) {
                    return m.sid === editingSelectedOption;
                });
                if (f2 > -1) {
                    if (!Object.prototype.hasOwnProperty.call(temp.styles[f].option[f2], "quantity") || temp.styles[f].option[f2].quantity && temp.styles[f].option[f2].quantity !== 10000000) {
                        temp.styles[f].option[f2].quantity = Number(10000000);
                    } else {
                        temp.styles[f].option[f2].quantity = 1;
                    }
                }
                setEditing(temp);
            }
        }
    });
    var setCurrentPrice = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            var temp = _objectSpread({}, editing);
            var f = temp.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                if (!isNaN(Number(e.currentTarget.value))) {
                    temp.styles[f].price = Number(e.currentTarget.value);
                    setEditing(temp);
                }
            }
        }
    });
    var changeCurrentStyle = _react["default"].useCallback(function(e) {
        console.log(e.currentTarget.value);
        if (e.currentTarget) {
            setEditingSelectedStyle(e.currentTarget.value);
            var f = editing.styles.findIndex(function(m) {
                return m.sid === e.currentTarget.value;
            });
            styleInput.current.value = editing.styles[f].style;
            console.log(editing.styles);
            setTimeout(function() {
                if (optionInput && optionInput.current) {
                    optionInput.current.value = editing.styles[f].option && editing.styles[f].option[0] ? editing.styles[f].option[0].option : "";
                    setEditingSelectedOption(editing.styles[f].option && editing.styles[f].option[0] ? editing.styles[f].option[0].sid : "");
                    if (optionSelect.current) {
                        optionSelect.current.selectedIndex = 0;
                    }
                }
            }, 250);
            quantityInput.current.value = editing.styles[f].option && editing.styles[f].option[0] ? editing.styles[f].option[0].quantity : 1;
            priceInput.current.value = editing.styles[f] ? editing.styles[f].price : 1;
        }
    });
    var changeCurrentOption = _react["default"].useCallback(function(e) {
        console.log(e.currentTarget.value);
        if (e.currentTarget) {
            var f = editing.styles.findIndex(function(m) {
                return m.sid === editingSelectedStyle;
            });
            if (f > -1) {
                var temp = editing.styles[f].option.find(function(m) {
                    return m.sid === e.currentTarget.value;
                });
                console.log(temp);
                if (temp) {
                    optionInput.current.value = temp.option;
                    setEditingSelectedOption(temp.sid);
                    quantityInput.current.value = temp.quantity;
                }
            }
        }
    });
    var addStyle = _react["default"].useCallback(function(e) {
        var temp = _objectSpread({}, editing);
        temp.styles.push(defaultStyle());
        setEditing(temp);
    });
    var addOption = _react["default"].useCallback(function(e) {
        console.log(editing, editingSelectedStyle);
        var temp = _objectSpread({}, editing);
        var f = editing.styles.findIndex(function(m) {
            return m.sid === editingSelectedStyle;
        });
        console.log(f);
        if (f > -1) {
            var o = defaultOption();
            if (editing.styles[f].option[0] && !Object.hasOwnProperty.call(editing.styles[f].option[0], "option")) {
                editing.styles[f].option[0].option = "";
                setEditingSelectedOption(editing.styles[f].option[0].sid);
            } else {
                editing.styles[f].option.push(o);
                setEditingSelectedOption(o.sid);
            }
        }
        setEditing(temp);
    });
    var onProductTypeChange = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            var value = e.currentTarget.value;
            var temp = _objectSpread({}, editingOptionsMeta);
            temp.productType = value;
            setEditingOptionsMeta(temp);
        }
    });
    var setOptionsMetaData = _react["default"].useCallback(function(e) {
        console.log(e.currentTarget.checked, e.currentTarget.getAttribute("option"));
        if (e.currentTarget) {
            if (e.currentTarget.getAttribute("option")) {
                if (Object.prototype.hasOwnProperty.call(e.currentTarget, "checked")) {
                    var temp = _objectSpread({}, editingOptionsMeta);
                    temp[e.currentTarget.getAttribute("option")] = e.currentTarget.checked;
                    setEditingOptionsMeta(temp);
                    setEditingOptionsMeta(function(prev) {
                        return _objectSpread({}, prev);
                    });
                } else if (e.currentTarget.getAttribute("option") === "livestreamDef" || e.currentTarget.getAttribute("option") === "eventDateDef") {
                    var _temp = _objectSpread({}, editingOptionsMeta);
                    if (e.currentTarget.getAttribute("option2")) {
                        console.log(e.currentTarget);
                        _temp[e.currentTarget.getAttribute("option")][e.currentTarget.getAttribute("option2")] = e.currentTarget.value;
                        var values = e.currentTarget.value.split(" ");
                        var dates = [];
                        var tags = [];
                        values.map(function(v) {
                            if (!isNaN(new Date(v))) {
                                dates.push(new Date(v));
                            } else {
                                tags.push(v);
                            }
                        });
                        _temp[e.currentTarget.getAttribute("option")].dates = dates;
                        _temp[e.currentTarget.getAttribute("option")].tags = tags;
                        setEditingOptionsMeta(_temp);
                    }
                } else if (e.currentTarget.getAttribute("option") === "lineupTemp") {
                    var _temp2 = _objectSpread({}, editingOptionsMeta);
                    if (!_temp2.lineup) {
                        _temp2.lineup = [];
                    }
                    var cur = currentLineupEditing;
                    if (_temp2.lineup.length < 10) {
                        console.log(cur);
                        if (cur === null) {
                            cur = _temp2.lineup.length; // Set valid index for currently editing
                            setCurrentLineupEditing(cur);
                        }
                        var temp2 = _objectSpread({}, editing);
                        if (!_temp2.lineup[cur]) {
                            _temp2.lineup[cur] = defaultLineup();
                            if (editing && !temp2.detailmeta.lineup) {
                                temp2.detailmeta.lineup = [];
                            }
                        }
                        temp2.detailmeta.lineup[cur] = _temp2.lineup[cur];
                        setEditing(temp2);
                        _temp2.lineup[cur][e.currentTarget.getAttribute("option2")] = e.currentTarget.value;
                        setEditingOptionsMeta(_temp2);
                    }
                }
            }
        }
    });
    var updateLineup = _react["default"].useCallback(function(e) {
        if (e.currentTarget) {
            if (e.currentTarget.getAttribute("option")) {
                var temp = _objectSpread({}, editingOptionsMeta);
                if (e.currentTarget.getAttribute("option") === "add") {
                    if (temp.lineup && temp.lineup.length < 10) {
                        temp.lineup.push(defaultLineup());
                        setCurrentLineupEditing(temp.lineup.length - 1);
                        lineupNameRef.current.value = "";
                        lineupDescriptionRef.current.value = "";
                        lineupTimeRef.current.value = null;
                    }
                } else if (e.currentTarget.getAttribute("option") === "remove") {
                    if (temp.lineup && temp.lineup.length > 0) {
                        temp.lineup.pop();
                        setCurrentLineupEditing(temp.lineup.length - 1 > -1 ? temp.lineup.length - 1 : null);
                        lineupNameRef.current.value = "";
                        lineupDescriptionRef.current.value = "";
                        lineupTimeRef.current.value = null;
                    }
                } else if (e.currentTarget.getAttribute("option") === "setSelected") {
                    var index = e.currentTarget.getAttribute("index");
                    if (!isNaN(index)) {
                        setCurrentLineupEditing(index);
                        lineupNameRef.current.value = temp.lineup[index].title;
                        lineupDescriptionRef.current.value = temp.lineup[index].description;
                        lineupTimeRef.current.value = temp.lineup[index].time;
                    }
                }
            }
        }
    });
    var setCurrentName = _react["default"].useCallback(function(e) {
        if (e.currentTarget && e.currentTarget.getAttribute) {
            if (e.currentTarget.getAttribute("modif") && e.currentTarget.getAttribute("modif") === "product_name") {
                var temp = _objectSpread({}, editing);
                temp.name = e.currentTarget.value;
                setEditing(temp);
            }
        }
    });
    var publishProduct = function publishProduct(modif, existing) {
        try {
            var fn = /*#__PURE__*/ function() {
                var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                    var product, formData, imgNames, data;
                    return _regeneratorRuntime().wrap(function _callee$(_context) {
                        while(1)switch(_context.prev = _context.next){
                            case 0:
                                if (fetchBusy) {
                                    _context.next = 26;
                                    break;
                                }
                                setPageError({});
                                product = _objectSpread({}, editing);
                                console.log(product);
                                product.detailmeta = _objectSpread({}, editingOptionsMeta);
                                if (!(product.name === "")) {
                                    _context.next = 9;
                                    break;
                                }
                                setPageError({
                                    message: "Please enter a name for your product",
                                    location: "product_name"
                                });
                                setFetchBusy(false);
                                return _context.abrupt("return", 1);
                            case 9:
                                formData = new FormData();
                                imgNames = [];
                                if (tempImagesForCurrentlyEditing && tempImagesForCurrentlyEditing.editing === product.id) {
                                    // Retrieve files for upload if matching upload image edit
                                    tempImagesForCurrentlyEditing.images.forEach(function(img) {
                                        console.log("Img", img);
                                        formData.append("image", img);
                                        imgNames.push(img.name);
                                    });
                                    formData.append("imgNames", JSON.stringify(imgNames));
                                }
                                formData.append("domainKey", props.domainKey);
                                formData.append("hash", props._loggedIn.hash);
                                formData.append("identifier", props._loggedIn.identifier);
                                formData.append("product", JSON.stringify(product));
                                formData.append("shop", shop.id);
                                formData.append("status", modif);
                                formData.append("existing", existing);
                                setFetchBusy(true);
                                setTimeout(function() {
                                    setFetchBusy(false);
                                }, 10000);
                                _context.next = 23;
                                return (0, _ecommerce.doPublishProduct)(props.apiUrl, props.domainKey, shop.id, props._loggedIn, product, formData);
                            case 23:
                                data = _context.sent;
                                console.log(data);
                                if (data) {
                                    if (data.product) {
                                        if (data.product.products) {
                                            setShopProducts(data.product.products);
                                            setCombinedFeed(data.product.products);
                                            setEditing({});
                                            setFetchBusy(false);
                                        }
                                    }
                                }
                            case 26:
                            case "end":
                                return _context.stop();
                        }
                    }, _callee);
                }));
                return function fn() {
                    return _ref.apply(this, arguments);
                };
            }();
            fn();
        } catch (err) {
        // fail silently
        }
    };
    var handlePublishProduct = _react["default"].useCallback(function(e) {
        if (e.currentTarget && e.currentTarget.getAttribute) {
            if (e.currentTarget.getAttribute("modif")) {
                var modif = e.currentTarget.getAttribute("modif");
                var existing = e.currentTarget.getAttribute("existing");
                publishProduct(modif, existing);
            }
        }
    });
    var passTempImages = function passTempImages(images) {
        setTempImagesForCurrentlyEditing({
            editing: editing.id,
            images: images
        });
    };
    // list all shop items
    // allow for creation of shop item with
    // product name, description, options, size per option (os or custom) w/ quantity, type, publish, images
    // console.log(adminAuth, props, combinedFeed, shop, editing, editingOptionsMeta, editingOptionsMeta.productType, editingSelectedOption, editingSelectedStyle)
    var selectedStyle = editing && editing.styles ? editing.styles.find(function(m) {
        return m.sid === editingSelectedStyle;
    }) : null;
    var selectedOption = editing && selectedStyle && selectedStyle.option ? ((_selectedStyle$option = selectedStyle.option.find(function(m) {
        return m.sid === editingSelectedOption;
    })) !== null && _selectedStyle$option !== void 0 ? _selectedStyle$option : selectedStyle.option.length === 1) ? selectedStyle.option[0] : null : null;
    console.log(adminAuth, shop);
    var noShop = shop && shop.status && shop.status === "nonexistent";
    console.log(noShop, editing, tempImagesForCurrentlyEditing);
    console.log(editingOptionsMeta, currentLineupEditing);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(fetchBusy ? "fetchNotBusy fetchBusy" : "fetchNotBusy")
    }), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ShopModule["default"].container)
    }, adminAuth && !noShop ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ShopModule["default"].adminContainer)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "heading"
    }, "Shop"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex options",
        style: {
            gap: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        disabled: !(0, _util.isObjectEmpty)(editing),
        onClick: createNewProduct
    }, "Create New"), editing && !(0, _util.isObjectEmpty)(editing) ? /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleCancelProduct,
        modif: "save"
    }, editing["new"] ? "Abandon" : "Cancel") : null)) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_flex_container"
    }, editing && !(0, _util.isObjectEmpty)(editing) && editing["new"] ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_col"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_img_container"
    }, /*#__PURE__*/ _react["default"].createElement(_product.ProductImageManager, _extends({}, props, {
        editing: editing,
        passTempImages: passTempImages
    }))), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Product_meta_container"
    }, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Name of Product",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        name: "name",
        placeholder: "Product Name",
        style: {
            width: "100%"
        },
        onChange: setCurrentName,
        ref: nameRef,
        modif: "product_name"
    })), pageError.location && pageError.location === "product_name" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "error"
    }, pageError.message) : null), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "If your product has multiple styles, set them here. A style should be an alternate design or color for a single product that you want to track as single product. For example you might have white, black, grey for t-shirts as individual styles.",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "Style:"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "dropdown_input"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        ref: styleInput,
        onChange: setCurrentStyleName
    }), /*#__PURE__*/ _react["default"].createElement("select", {
        id: editing.id + "_styles",
        name: editing.id + "_styles",
        style: {
            width: "100%"
        },
        onChange: changeCurrentStyle
    }, (0, _ecommerce.resolveStyles)(editing).map(function(style, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: style.sid,
            className: "style_option",
            key: i
        }, style.style);
    }))))), selectedStyle && selectedStyle.option.length > 0 && selectedStyle.option[0] && Object.hasOwnProperty.call(selectedStyle.option[0], "option") ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "If your product has options, set them here. An option should be a sizing or format choice that exists for all or most styles. For example you might have sizes XS, S, M, L, XL or OS as individual options per style.",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "Option:"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "dropdown_input"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        ref: optionInput,
        onChange: setCurrentOptionName
    }), /*#__PURE__*/ _react["default"].createElement("select", {
        id: editing.id + "_options",
        name: editing.id + "_options",
        style: {
            width: "100%"
        },
        onChange: changeCurrentOption,
        ref: optionSelect
    }, editing.styles.find(function(m) {
        return m.sid === editingSelectedStyle;
    }).option.map(function(option, i) {
        return /*#__PURE__*/ _react["default"].createElement("option", {
            value: option.sid,
            className: "option_option",
            key: i
        }, option.option);
    }))))) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the price for the currently selected Style"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600
        }
    }, "$")), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "currency",
        style: {
            width: "100%"
        },
        defaultValue: "1.00",
        ref: priceInput,
        onChange: setCurrentPrice
    }), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the quantity for the currently selected Style & Option combo"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600,
            display: selectedOption && selectedOption.quantity && selectedOption.quantity === 10000000 ? "none" : "block"
        }
    }, "Qty")), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "number",
        style: {
            width: "100%",
            display: selectedOption && selectedOption.quantity && selectedOption.quantity === 10000000 ? "none" : "block"
        },
        defaultValue: "1",
        ref: quantityInput,
        onChange: setCurrentQuantity
    }), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Infinite stock"
    }, /*#__PURE__*/ _react["default"].createElement(_AllInclusive["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        onChange: setInfinity,
        checked: selectedOption && selectedOption.quantity && selectedOption.quantity === 10000000
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 Product_admin_choice_container"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: addStyle
    }, "Add Style"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: addOption
    }, "Add Option")), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center",
            height: "18px"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Set the product type"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: 600,
            paddingTop: ".2rem"
        }
    }, "Type: ")), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            fontSize: ".8rem",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "radio",
        id: "virtual",
        name: "fav_language",
        value: "virtual",
        defaultChecked: true,
        onChange: onProductTypeChange
    }), /*#__PURE__*/ _react["default"].createElement("label", {
        "for": "virtual"
    }, "Virtual"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "radio",
        id: "physical",
        name: "fav_language",
        value: "physical",
        onChange: onProductTypeChange
    }), /*#__PURE__*/ _react["default"].createElement("label", {
        "for": "physical"
    }, "Physical"))), editingOptionsMeta && editingOptionsMeta.productType === "virtual" ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 promptContainer",
        style: {
            alignItems: "center",
            height: "20px",
            borderRadius: ".5rem",
            margin: ".25rem 0"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Ticketed Products offer universally unique ids that are unique across the product being sold and can be stamped onto Virtual Ticket Images",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Is this a ticket?"), /*#__PURE__*/ _react["default"].createElement(_ConfirmationNumber["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        value: editingOptionsMeta.ticket,
        defaultChecked: editingOptionsMeta.ticket,
        onChange: setOptionsMetaData,
        option: "ticket"
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "promptContainer",
        style: {
            borderRadius: ".5rem",
            margin: ".25rem 0"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center",
            height: "20px"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "You can use a date to authorize all users that purchase this ticket for access to your livestreams on that day. Or you can use a tag that you must include in the livestream tags field when you create it. Please use this if you want to put your livestream behind this paywalled purchase",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "bottom",
        paddin: true
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Is this for a livestream?"), /*#__PURE__*/ _react["default"].createElement(_Stadium["default"], {
        style: {
            width: "15px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        style: {
            margin: 0
        },
        value: editingOptionsMeta.livestream,
        defaultChecked: editingOptionsMeta.livestream,
        onChange: setOptionsMetaData,
        option: "livestream"
    })), editingOptionsMeta.livestream ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            paddingBottom: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter dates or words for matching authorization. Enter dates in the following format MON-DD-YYYY-HH:MM or they will not be parsed as dates. Time must be input in 24 H military time. Values that do not match dates will be parsed as tags that can be added to livestreams. Any matches will authorize viewership of the stream for purchases of this ticket",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        style: {
            marginBottom: ".125rem",
            width: "-webkit-fill-available"
        },
        placeholder: "Date in DD/MM/YY format or a tag",
        onInput: setOptionsMetaData,
        option: "livestreamDef",
        option2: "input",
        defaultValue: editingOptionsMeta.livestreamDef.input
    })), editingOptionsMeta.livestreamDef.dates.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, editingOptionsMeta.livestreamDef.dates.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d ? (0, _util.getFormattedDate)(d, {
            pretty: true
        }) : "");
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), editingOptionsMeta.livestreamDef.tags.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, editingOptionsMeta.livestreamDef.tags.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d);
    })) : /*#__PURE__*/ _react["default"].createElement("div", null)) : null, editingOptionsMeta.ticket ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem"
        }
    }, "Date for Event"), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter dates in the following format MON-DD-YYYY-HH:MM or they will not be parsed as dates. Time must be input in 24 H military time. Values that do not match dates will be parsed as tags that can be added to livestreams. Any matches will authorize viewership of the stream for purchases of this ticket",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        style: {
            marginBottom: ".125rem",
            width: "-webkit-fill-available"
        },
        placeholder: "Date in MON-DD-YYYY-HH:MM format. If the ticket does not have an event date leave empty",
        onInput: setOptionsMetaData,
        option: "eventDateDef",
        option2: "input",
        defaultValue: editingOptionsMeta.eventDateDef.input
    })), editingOptionsMeta.eventDateDef.dates.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, editingOptionsMeta.eventDateDef.dates.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d ? (0, _util.getFormattedDate)(d, {
            pretty: true
        }) : "");
    })) : /*#__PURE__*/ _react["default"].createElement("div", null)) : null, editingOptionsMeta.livestream ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            background: "#222222",
            marginTop: ".25rem",
            marginBottom: ".25rem",
            borderRadius: ".25rem",
            padding: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            fontWeight: "600"
        }
    }, "Lineup"), editingOptionsMeta.lineup && editingOptionsMeta.lineup.length < 10 || !editingOptionsMeta.lineup ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter participants name",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        placeholder: "Name",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: setOptionsMetaData,
        option: "lineupTemp",
        option2: "title",
        ref: lineupNameRef
    })), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Optional: Enter description of participant",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        placeholder: "Description",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: setOptionsMetaData,
        option: "lineupTemp",
        option2: "description",
        ref: lineupDescriptionRef
    })), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Optional: Enter expected time for lineup participant to be performing",
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "time",
        placeholder: "Time",
        style: {
            fontSize: ".8rem",
            width: "100%"
        },
        onInput: setOptionsMetaData,
        option: "lineupTemp",
        option2: "time",
        ref: lineupTimeRef
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".75rem",
            padding: ".125rem",
            paddingTop: ".25rem"
        }
    }, "After you publish this product you will be able to add Lineup participant images"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        }
    }, editingOptionsMeta.lineup && editingOptionsMeta.lineup.length < 10 && editingOptionsMeta.lineup.length > 0 ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Add another Lineup Participant",
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%"
        },
        onClick: updateLineup,
        option: "add"
    }, "Add")) : null, editingOptionsMeta.lineup && editingOptionsMeta.lineup[currentLineupEditing] ? /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Remove this Lineup Participant",
        placement: "bottom"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%"
        },
        onClick: updateLineup,
        option: "remove"
    }, "Remove")) : null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2",
        style: {
            overflow: "auto"
        }
    }, editingOptionsMeta.lineup && editingOptionsMeta.lineup.map ? editingOptionsMeta.lineup.map(function(m, i) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_editing",
            style: {
                maxWidth: "75px"
            },
            onClick: updateLineup,
            option: "setSelected",
            index: i,
            key: i
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_id",
            style: {
                fontSize: ".5rem",
                overflow: "hidden",
                whiteSpace: "nowrap"
            }
        }, m.id), /*#__PURE__*/ _react["default"].createElement("div", {
            style: {
                fontSize: ".7rem",
                fontWeight: "600",
                overflowWrap: "anywhere"
            }
        }, m.title), m.time ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "lineupItem_time",
            style: {
                fontSize: "1rem"
            }
        }, (0, _util.getFormattedTime)(m.time, {
            simple: true
        })) : null);
    }) : null)) : null) : null)) : /*#__PURE__*/ _react["default"].createElement("div", null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2 Product_admin_choice_container",
        style: {
            marginTop: ".125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handlePublishProduct,
        modif: "publish"
    }, "Publish"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handlePublishProduct,
        modif: "save"
    }, "Save"), editing ? /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleCancelProduct,
        modif: "save"
    }, editing["new"] ? "Abandon" : "Cancel") : null))) : null, combinedFeed && combinedFeed.map ? combinedFeed.map(function(item, i) {
        return /*#__PURE__*/ _react["default"].createElement(_product.Product, _extends({}, props, {
            product: item,
            key: i,
            apiUrl: props.apiUrl,
            domainKey: props.domainKey,
            _loggedIn: props._loggedIn,
            fetchBusy: fetchBusy,
            setFetchBusy: setFetchBusy,
            _setLoggedIn: props._setLoggedIn,
            handleEdit: handleEdit,
            editing: editing,
            setEditing: setEditing,
            setCurrentName: setCurrentName,
            pageError: pageError,
            styleInput: styleInput,
            setCurrentStyleName: setCurrentStyleName,
            changeCurrentStyle: changeCurrentStyle,
            resolveStyles: _ecommerce.resolveStyles,
            selectedStyle: selectedStyle,
            setCurrentOptionName: setCurrentOptionName,
            optionInput: optionInput,
            changeCurrentOption: changeCurrentOption,
            optionSelect: optionSelect,
            editingSelectedStyle: editingSelectedStyle,
            priceInput: priceInput,
            setCurrentPrice: setCurrentPrice,
            selectedOption: selectedOption,
            quantityInput: quantityInput,
            setCurrentQuantity: setCurrentQuantity,
            setInfinity: setInfinity,
            addStyle: addStyle,
            addOption: addOption,
            onProductTypeChange: onProductTypeChange,
            editingOptionsMeta: editingOptionsMeta,
            setEditingOptionsMeta: setEditingOptionsMeta,
            setOptionsMetaData: setOptionsMetaData,
            handlePublishProduct: handlePublishProduct,
            handleCancelProduct: handleCancelProduct,
            nameRef: nameRef,
            setEditingSelectedStyle: setEditingSelectedStyle,
            setEditingSelectedOption: setEditingSelectedOption,
            setShopProducts: setShopProducts,
            setCombinedFeed: setCombinedFeed,
            setCurrentLineupEditing: setCurrentLineupEditing,
            currentLineupEditing: currentLineupEditing,
            defaultLineup: defaultLineup
        }));
    }) : null)));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 3380:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "Shop", ({
    enumerable: true,
    get: function get() {
        return _Shop["default"];
    }
}));
var _Shop = _interopRequireDefault(__webpack_require__(6363));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 7785:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _uuid = __webpack_require__(5828);
var _SliderModule = _interopRequireDefault(__webpack_require__(8331));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _props$height;
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), componentId = _React$useState2[0], setComponentId = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), componentDidMount = _React$useState4[0], setComponentDidMount = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(false), _React$useState6 = _slicedToArray(_React$useState5, 2), stagger = _React$useState6[0], setStagger = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), fetching = _React$useState8[0], setFetching = _React$useState8[1];
    var staggerRef = _react["default"].useRef();
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            if (props.stagger) {
                staggerRef.current = setTimeout(function() {
                    setStagger(true);
                }, props.stagger);
            }
            var id = (0, _uuid.v4)();
            setComponentId(id);
            setComponentDidMount(true);
        }
    }, [
        componentDidMount,
        props.stagger
    ]);
    _react["default"].useEffect(function() {
        if (componentId && window && window.Glide) {
            new window.Glide(".glide_".concat(componentId), {
                type: "carousel",
                perView: 3,
                focusAt: "center",
                breakpoints: {
                    1200: {
                        perView: 2
                    },
                    480: {
                        perView: 1
                    }
                }
            }).mount();
        }
    }, [
        componentId
    ]);
    // console.log(window.Glide)
    return /*#__PURE__*/ _react["default"].createElement("div", {
        "class": "glide_".concat(componentId, " ").concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        "data-glide-el": "track",
        "class": "glide__track",
        style: {
            height: (_props$height = props.height) !== null && _props$height !== void 0 ? _props$height : "240px"
        }
    }, /*#__PURE__*/ _react["default"].createElement("ul", {
        "class": "glide__slides",
        style: {
            height: "inherit"
        }
    }, props.items && props.items.map ? props.items.map(function(m) {
        var _m$buttonLink, _m$width, _m$borderRadius;
        return /*#__PURE__*/ _react["default"].createElement("li", {
            "class": "glide_slide"
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_SliderModule["default"].textContainer, " glider_text_container"),
            style: {
                position: "absolute"
            }
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_SliderModule["default"].textOffsetContainer, " glider_text_offset_container")
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_SliderModule["default"].container1, " glider_container1")
        }, m.cta ? /*#__PURE__*/ _react["default"].createElement("h2", {
            className: "".concat(_SliderModule["default"].cta, " glider_cta")
        }, m.cta) : null, m.heading ? /*#__PURE__*/ _react["default"].createElement("h5", {
            className: "".concat(_SliderModule["default"].heading, " glider_heading")
        }, m.heading) : null, m.description ? /*#__PURE__*/ _react["default"].createElement("h6", {
            className: "".concat(_SliderModule["default"].description, " glider_description")
        }, m.description) : null), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_SliderModule["default"].container2, " glider_container2")
        }, m.button ? /*#__PURE__*/ _react["default"].createElement("a", {
            className: "".concat(_SliderModule["default"].button, " glider_button"),
            href: (_m$buttonLink = m.buttonLink) !== null && _m$buttonLink !== void 0 ? _m$buttonLink : ""
        }, /*#__PURE__*/ _react["default"].createElement("button", null, m.button)) : null, m.status ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_SliderModule["default"].status, " glider_status"),
            style: {
                background: "red"
            }
        }, m.status) : null))), /*#__PURE__*/ _react["default"].createElement("img", {
            src: m.img,
            style: {
                width: (_m$width = m.width) !== null && _m$width !== void 0 ? _m$width : "auto",
                borderRadius: (_m$borderRadius = m.borderRadius) !== null && _m$borderRadius !== void 0 ? _m$borderRadius : "1rem"
            }
        }));
    }) : /*#__PURE__*/ _react["default"].createElement("div", null))));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 6256:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "SliderBasic", ({
    enumerable: true,
    get: function get() {
        return _SliderBasic["default"];
    }
}));
var _SliderBasic = _interopRequireDefault(__webpack_require__(7785));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 3832:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _router = __webpack_require__(1853);
var _SignIn = __webpack_require__(5203);
var _index = __webpack_require__(3183);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
// import RegisterUsername from './RegisterUsername.js'
var Module = function Module(props) {
    var router = (0, _router.useRouter)();
    var query = router.query, asPath = router.asPath;
    var googleSignIn = _react["default"].useRef();
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), registerUsernameOn = _React$useState2[0], setRegisterUsernameOn = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), googleSignInRendered = _React$useState4[0], googleSignInRenderedSet = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(false), _React$useState6 = _slicedToArray(_React$useState5, 2), hideGoogleSignIn = _React$useState6[0], setHideGoogleSignIn = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(null), _React$useState8 = _slicedToArray(_React$useState7, 2), pageError = _React$useState8[0], setPageError = _React$useState8[1];
    props._LocalEventEmitter.unsubscribe("showSignIn");
    props._LocalEventEmitter.subscribe("showSignIn", function(e) {
        setHideGoogleSignIn(false);
        buildButtonAndTryPrompt(500);
    });
    _react["default"].useEffect(function() {
        var muteLoginErr = function muteLoginErr() {
            setPageError(null);
        };
        document.addEventListener("mute-login-error", muteLoginErr, {
            once: true
        });
    }, []);
    var buildLoginAndUpdate = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(data) {
            var status;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        _context.next = 2;
                        return (0, _SignIn.attemptThirdPartySignIn)(data, props.apiUrl, props.domainKey);
                    case 2:
                        status = _context.sent;
                        if (status && status.hasOwnProperty("username")) {
                            if (!status.username) {
                                setRegisterUsernameOn(true);
                            }
                        }
                        (0, _index.setStripeSecretData)(props.apiUrl, props.domainKey, status, props._setStripeSecret);
                        props._setLoggedIn(status);
                        console.log(props.redirectOnAuth, status.username);
                        if (props.redirectOnAuth && status.username && asPath !== props.redirectOnAuth) {
                            router.push(props.redirectOnAuth);
                        }
                        setTimeout(function() {
                            setPageError(null);
                        }, 20000);
                        setTimeout(function() {
                            setHideGoogleSignIn(true);
                        });
                    case 10:
                    case "end":
                        return _context.stop();
                }
            }, _callee);
        }));
        return function buildLoginAndUpdate(_x2) {
            return _ref.apply(this, arguments);
        };
    }();
    console.log(props, query, asPath, router);
    var buildButtonAndTryPrompt = function buildButtonAndTryPrompt(delay) {
        try {
            var googleBtn = {
                theme: "outline",
                size: "medium",
                logo_alignment: "center"
            };
            setTimeout(function() {
                try {
                    var signInStatus = (0, _SignIn.checkSignedIn)();
                    if (!signInStatus) {
                        google.accounts.id.renderButton(googleSignIn.current, googleBtn);
                        googleSignInRenderedSet(true);
                        google.accounts.id.prompt(function(notification) {
                            console.log("on prompt notification", notification);
                        });
                    } else {
                        props._setLoggedIn(signInStatus);
                    }
                } catch (err) {
                    setTimeout(function() {
                        try {
                            var _signInStatus = (0, _SignIn.checkSignedIn)();
                            if (!_signInStatus) {
                                // @ts-ignore
                                google.accounts.id.renderButton(googleSignIn.current, googleBtn);
                                googleSignInRenderedSet(true);
                                // @ts-ignore
                                google.accounts.id.prompt(function(notification) {
                                    console.log("on prompt notification", notification);
                                });
                            } else {
                                props._setLoggedIn(_signInStatus);
                            }
                        } catch (err) {
                            console.log(err); // fail silently
                        }
                    }, 10000);
                }
            }, delay);
        } catch (err) {
            console.log(err); // fail silently
        }
    };
    // Register google sign in button. Necessary for register CC and login
    _react["default"].useEffect(function() {
        document.addEventListener("thirdparty-signin", buildLoginAndUpdate, {
            once: true
        });
        buildButtonAndTryPrompt(500);
    }, []);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            maxWidth: "170px"
        },
        className: "".concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: hideGoogleSignIn ? "display-none" : null
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: googleSignInRendered ? "googleSignInContainer googleSignInContainer-padding" : "googleSignInContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "g_id_signin google-sign-in-btn",
        ref: googleSignIn,
        "data-size": "medium",
        "data-logo_alignment": "center",
        "data-theme": "outline"
    }))), pageError ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            paddingLeft: 1 + "rem",
            paddingRight: 1 + "rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("p", {
        className: "googleSignInPromptSmall error errorBg"
    }, pageError)) : null);
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 4457:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _index = __webpack_require__(9358);
var _cta = __webpack_require__(2345);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
var Module = function Module(props) {
    var styleSafety = props.StyleSafety;
    console.log(props);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "",
        style: {
            background: "url(".concat(props.backgroundUrl, ")"),
            padding: styleSafety ? styleSafety.padding : 0,
            margin: styleSafety ? styleSafety.margin : 0
        }
    }, props.children, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex sign-in-page-container"
    }, props.imageSplash && props.imageSplash.url ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "SignIn_ImageSplashContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "SignIn_ImageSplash",
        style: {
            background: "url(".concat(props.imageSplash.url, ") no-repeat center center / cover")
        }
    })) : /*#__PURE__*/ _react["default"].createElement("div", {
        className: "SignIn_ImageSplashContainer"
    }), /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_cta.IndexCta, _extends({}, props, {
        marginTop: "7rem",
        definition: props.OnboardCta,
        children: /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_index.SignIn, props), /*#__PURE__*/ _react["default"].createElement(_index.Username, props)),
        ctaTopVideos: props.ctaTopVideos
    }))))));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 2559:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _router = __webpack_require__(5925);
var _SignIn = __webpack_require__(5203);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var registerUsername = function registerUsername(props) {
    var _props$prompt, _props$confirm;
    var router = (0, _router.useRouter)();
    var query = router.query, asPath = router.asPath;
    var proposed = _react["default"].useRef();
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), pageError = _React$useState2[0], setPageError = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(true), _React$useState4 = _slicedToArray(_React$useState3, 2), registerUsernameOn = _React$useState4[0], setRegisterUsernameOn = _React$useState4[1];
    var handleSaveUsername = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(e) {
            var data, res;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        if (!(proposed && proposed.current && proposed.current.value)) {
                            _context.next = 23;
                            break;
                        }
                        data = {
                            proposedUsername: proposed.current.value
                        };
                        _context.next = 4;
                        return (0, _SignIn.grabUsername)(props.apiUrl, props.domainKey, data, _SignIn.checkSignedIn, props._setLoggedIn);
                    case 4:
                        res = _context.sent;
                        if (!res) {
                            _context.next = 22;
                            break;
                        }
                        if (!(res == "disauthenticated")) {
                            _context.next = 12;
                            break;
                        }
                        setLoggedIn(false);
                        setRegisterUsernameOn(false);
                        setPageError(null);
                        _context.next = 20;
                        break;
                    case 12:
                        if (!(res == "username taken")) {
                            _context.next = 17;
                            break;
                        }
                        setPageError("Sorry, that username is already taken. Please try another one or contact admin@minipost.app");
                        return _context.abrupt("return");
                    case 17:
                        setRegisterUsernameOn(false);
                        setPageError(null);
                        if (props.redirectOnAuth && asPath !== props.redirectOnAuth) {
                            router.push(props.redirectOnAuth);
                        }
                    case 20:
                        _context.next = 23;
                        break;
                    case 22:
                        setPageError("Sorry, that username is already taken. Please try another one or contact admin@minipost.app");
                    case 23:
                    case "end":
                        return _context.stop();
                }
            }, _callee);
        }));
        return function handleSaveUsername(_x2) {
            return _ref.apply(this, arguments);
        };
    }();
    _react["default"].useEffect(function() {
        if (props._loggedIn) {
            if (!props._loggedIn.username && !registerUsernameOn) {
                setRegisterUsernameOn(true);
            } else if (props._loggedIn.username && registerUsernameOn) {
                setRegisterUsernameOn(false);
            }
        } else if (registerUsernameOn) {
            setRegisterUsernameOn(false);
        }
    }, [
        props._loggedIn,
        registerUsernameOn
    ]);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, props._loggedIn && !props._loggedIn.username && registerUsernameOn ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Username_Container Username_ContainerBg"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Username_ItemsContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Username_PromptContainer"
    }, /*#__PURE__*/ _react["default"].createElement("h4", {
        style: {
            margin: 0
        }
    }, (_props$prompt = props.prompt) !== null && _props$prompt !== void 0 ? _props$prompt : "What username do you want?"), /*#__PURE__*/ _react["default"].createElement("span", {
        style: {
            margin: 0 + " auto"
        }
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        ref: proposed,
        type: "text",
        placeholder: "Username",
        className: "simpleTextInput"
    }), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: function onClick(e) {
            handleSaveUsername(e);
        }
    }, (_props$confirm = props.confirm) !== null && _props$confirm !== void 0 ? _props$confirm : "Give me that one!"))), pageError ? /*#__PURE__*/ _react["default"].createElement("p", {
        style: {
            marginTop: ".5rem"
        }
    }, pageError) : null)) : null);
};
var _default = registerUsername;
exports["default"] = _default;


/***/ }),

/***/ 9358:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "SignIn", ({
    enumerable: true,
    get: function get() {
        return _SignIn["default"];
    }
}));
Object.defineProperty(exports, "SignInPage", ({
    enumerable: true,
    get: function get() {
        return _SignInPage["default"];
    }
}));
Object.defineProperty(exports, "Username", ({
    enumerable: true,
    get: function get() {
        return _Username["default"];
    }
}));
var _SignIn = _interopRequireDefault(__webpack_require__(3832));
var _SignInPage = _interopRequireDefault(__webpack_require__(4457));
var _Username = _interopRequireDefault(__webpack_require__(2559));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 8771:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _reactStripeJs = __webpack_require__(4515);
var _stripeJs = __webpack_require__(943);
var _index = __webpack_require__(3183);
var _SignIn = __webpack_require__(5203);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _props$marginBottom;
    var nameOnCard = _react["default"].useRef();
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), componentDidMount = _React$useState2[0], setComponentDidMount = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), stagger = _React$useState4[0], setStagger = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(false), _React$useState6 = _slicedToArray(_React$useState5, 2), validCc = _React$useState6[0], setValidCc = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), fetchingCc = _React$useState8[0], setFetchingCc = _React$useState8[1];
    var _React$useState9 = _react["default"].useState(null), _React$useState10 = _slicedToArray(_React$useState9, 2), stripePromise = _React$useState10[0], setStripePromise = _React$useState10[1];
    var _React$useState11 = _react["default"].useState(false), _React$useState12 = _slicedToArray(_React$useState11, 2), registerNewCard = _React$useState12[0], setRegisterNewCard = _React$useState12[1];
    var _React$useState13 = _react["default"].useState(false), _React$useState14 = _slicedToArray(_React$useState13, 2), fetchBusy = _React$useState14[0], setFetchBusy = _React$useState14[1];
    var staggerRef = _react["default"].useRef();
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            if (props.stagger) {
                staggerRef.current = setTimeout(function() {
                    setStagger(true);
                }, props.stagger);
            }
            setComponentDidMount(true);
        }
    }, [
        componentDidMount,
        props.stagger
    ]);
    _react["default"].useEffect(function() {
        if (props.stripeKey && !stripePromise) {
            var prom = (0, _stripeJs.loadStripe)(props.stripeKey);
            if (prom) {
                setStripePromise(prom);
            }
        }
    }, [
        props.stripeKey
    ]);
    _react["default"].useEffect(function() {
        function fn() {
            return _fn.apply(this, arguments);
        }
        function _fn() {
            _fn = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                var data;
                return _regeneratorRuntime().wrap(function _callee$(_context) {
                    while(1)switch(_context.prev = _context.next){
                        case 0:
                            if (!(!validCc && props._loggedIn && !fetchingCc && !props._stripeSecret)) {
                                _context.next = 18;
                                break;
                            }
                            _context.prev = 1;
                            setFetchingCc(true);
                            _context.next = 5;
                            return (0, _index.getStripeSecretData)(props.apiUrl, props.domainKey, props._loggedIn);
                        case 5:
                            data = _context.sent;
                            if (!(data && data.client_secret && data.card)) {
                                _context.next = 11;
                                break;
                            }
                            props._setStripeSecret(data);
                            setFetchingCc(false);
                            _context.next = 12;
                            break;
                        case 11:
                            throw new Error();
                        case 12:
                            _context.next = 18;
                            break;
                        case 14:
                            _context.prev = 14;
                            _context.t0 = _context["catch"](1);
                            console.log(_context.t0);
                            setFetchingCc(false);
                        case 18:
                            ;
                        case 19:
                        case "end":
                            return _context.stop();
                    }
                }, _callee, null, [
                    [
                        1,
                        14
                    ]
                ]);
            }));
            return _fn.apply(this, arguments);
        }
        fn();
    }, [
        props._loggedIn,
        props._stripeSecret
    ]);
    var handleSaveBillingInfo = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(e, elements, stripe, nameOnCard) {
            var user, data, res;
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                while(1)switch(_context2.prev = _context2.next){
                    case 0:
                        _context2.prev = 0;
                        e.preventDefault();
                        console.log(e, elements, stripe, nameOnCard);
                        if (fetchBusy) {
                            _context2.next = 22;
                            break;
                        }
                        setFetchBusy(true);
                        setTimeout(function() {
                            setFetchBusy(false);
                        }, 15000);
                        user = (0, _SignIn.checkSignedInAndPrompt)();
                        if (!user) {
                            _context2.next = 22;
                            break;
                        }
                        if (!(nameOnCard && nameOnCard.current && nameOnCard.current.value)) {
                            _context2.next = 20;
                            break;
                        }
                        data = {
                            fullName: "",
                            result: null,
                            stripeSecret: props._stripeSecret
                        };
                        data.fullName = nameOnCard.current.value;
                        _context2.next = 13;
                        return stripe.confirmCardSetup(props._stripeSecret.client_secret, {
                            // Stores credit card on users account
                            payment_method: {
                                card: elements.getElement(_reactStripeJs.CardElement),
                                billing_details: {
                                    name: data.fullName
                                }
                            }
                        });
                    case 13:
                        data.result = _context2.sent;
                        _context2.next = 16;
                        return (0, _index.saveCreditCardInfo)(props.apiUrl, props.domainKey, data, _SignIn.checkSignedIn);
                    case 16:
                        res = _context2.sent;
                        if (!res) {
                            props._setPageError("Failed to save Credit Card");
                            setFetchBusy(false);
                        } else if (res == "disauthenticated") {
                            props._setLoggedIn(false);
                            props._setStripeSecret(false);
                            (0, _SignIn.logout)();
                            setFetchBusy(false);
                        } else if (res.status == "success" && res.newSecret) {
                            setRegisterNewCard(false);
                            // On successfull credit card received, purchase phone number and then update locally
                            props._setStripeSecret(res.newSecret);
                            setFetchBusy(false);
                        }
                        _context2.next = 22;
                        break;
                    case 20:
                        props._setPageError("Please type in your Full Name as it appears on your Credit Card");
                        setFetchBusy(false);
                    case 22:
                        _context2.next = 28;
                        break;
                    case 24:
                        _context2.prev = 24;
                        _context2.t0 = _context2["catch"](0);
                        console.log(_context2.t0); // fail silently
                        setFetchBusy(false);
                    case 28:
                    case "end":
                        return _context2.stop();
                }
            }, _callee2, null, [
                [
                    0,
                    24
                ]
            ]);
        }));
        return function handleSaveBillingInfo(_x2, _x3, _x4, _x5) {
            return _ref.apply(this, arguments);
        };
    }();
    _react["default"].useEffect(function() {
        buildValidCc(props._stripeSecret);
    }, [
        props._stripeSecret
    ]);
    var buildValidCc = function buildValidCc(secret) {
        if (secret && secret.card && secret.card.data && secret.card.data[0] && secret.card.data[0].card && secret.card.data[0].billing_details) {
            if (secret.card.data[0].card.last4 && secret.card.data[0].card.exp_month && secret.card.data[0].card.exp_year) {
                var convExp = function convExp(exp) {
                    try {
                        var temp = exp.toString();
                        if (temp.length === 4) {
                            return temp.substring(2, 4);
                        }
                        throw new Error();
                    } catch (err) {
                        return exp;
                    }
                };
                setValidCc({
                    name: secret.card.data[0].billing_details.name ? secret.card.data[0].billing_details.name : null,
                    last4: secret.card.data[0].card.last4,
                    exp_month: secret.card.data[0].card.exp_month,
                    exp_year: convExp(secret.card.data[0].card.exp_year)
                });
            }
        }
    };
    if (props.setValidCc && props.validCc !== validCc) {
        props.setValidCc(validCc);
    }
    var handleRegisterNewCard = _react["default"].useCallback(function(e) {
        if (registerNewCard) {
            setRegisterNewCard(false);
            return 1;
        }
        setRegisterNewCard(true);
    });
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className),
        style: {
            marginBottom: (_props$marginBottom = props.marginBottom) !== null && _props$marginBottom !== void 0 ? _props$marginBottom : "0"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(fetchBusy ? "fetchNotBusy fetchBusy" : "fetchNotBusy")
    }), !props.stagger || props.stagger && stagger ? /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, validCc && !registerNewCard ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Ecommerce_CreditCard_Container",
        style: {
            padding: ".125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("span", null, props.purchaseDescription), /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("p", {
        style: {
            marginBottom: .1 + "rem",
            paddingBottom: 0 + "rem",
            margin: 0
        }
    }, "Ending in ", /*#__PURE__*/ _react["default"].createElement("span", null, validCc.last4)), /*#__PURE__*/ _react["default"].createElement("p", {
        style: {
            marginBottom: .1 + "rem",
            paddingBottom: 0 + "rem",
            margin: 0
        }
    }, "Expiry ", /*#__PURE__*/ _react["default"].createElement("span", null, validCc.exp_month, " / ", validCc.exp_year))), validCc.name ? /*#__PURE__*/ _react["default"].createElement("p", {
        style: {
            marginTop: .4 + "rem",
            margin: 0
        }
    }, validCc.name) : null)) : props._stripeSecret && props._stripeSecret.client_secret ? /*#__PURE__*/ _react["default"].createElement(_reactStripeJs.Elements, {
        stripe: stripePromise,
        options: {
            clientSecret: props._stripeSecret.client_secret
        }
    }, /*#__PURE__*/ _react["default"].createElement(_reactStripeJs.ElementsConsumer, null, function(_ref2) {
        var elements = _ref2.elements, stripe = _ref2.stripe;
        return /*#__PURE__*/ _react["default"].createElement("form", {
            onSubmit: function onSubmit(e) {
                handleSaveBillingInfo(e, elements, stripe, nameOnCard);
            },
            style: {
                display: "grid",
                gap: ".125rem"
            }
        }, /*#__PURE__*/ _react["default"].createElement("input", {
            type: "text",
            placeholder: "Full Name on Card",
            ref: nameOnCard
        }), /*#__PURE__*/ _react["default"].createElement(_reactStripeJs.CardElement, {
            options: {
                iconStyle: "solid",
                style: {
                    base: {
                        fontSize: "16px",
                        color: "black",
                        fontWeight: 500,
                        "::placeholder": {
                            color: "grey"
                        },
                        fontSmoothing: "antialiased",
                        width: 100 + "%",
                        backgroundColor: "white"
                    },
                    invalid: {
                        color: "#9e2146"
                    }
                }
            }
        }), /*#__PURE__*/ _react["default"].createElement("button", {
            type: "submit"
        }, "Save Billing Info"));
    })) : null, validCc ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "grid",
            gap: ".125rem",
            marginTop: ".125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        type: "submit",
        onClick: handleRegisterNewCard
    }, registerNewCard ? "Use Current Card" : "Register New Card")) : null) : null, props.children);
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 5847:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "CreditCard", ({
    enumerable: true,
    get: function get() {
        return _CreditCard["default"];
    }
}));
var _CreditCard = _interopRequireDefault(__webpack_require__(8771));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 2463:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _gridList = _interopRequireDefault(__webpack_require__(542));
var _manager = __webpack_require__(8958);
var _shop = __webpack_require__(3380);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _React$useState = _react["default"].useState({}), _React$useState2 = _slicedToArray(_React$useState, 2), currentLive = _React$useState2[0], setCurrentLive = _React$useState2[1];
    var _React$useState3 = _react["default"].useState([]), _React$useState4 = _slicedToArray(_React$useState3, 2), feed = _React$useState4[0], setFeed = _React$useState4[1];
    var _React$useState5 = _react["default"].useState([]), _React$useState6 = _slicedToArray(_React$useState5, 2), combinedFeed = _React$useState6[0], setCombinedFeed = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), adminPanelState = _React$useState8[0], setAdminPanelState = _React$useState8[1];
    var styleSafety = props.StyleSafety;
    _react["default"].useEffect(function() {
        if (props && props.profileData && props.profileData.currentLive) {
            setCurrentLive(props.profileData.currentLive);
            setCombinedFeed([
                props.profileData.currentLive
            ].concat(feed));
        }
    }, [
        props.profileData,
        feed
    ]);
    var adminAuth = props._loggedIn && props._loggedIn.identifier && props.profileData && props.profileData.user && props.profileData.user.id && props._loggedIn.identifier === props.profileData.user.id;
    var toggleAdminPanel = _react["default"].useCallback(function(e) {
        var temp = adminPanelState;
        console.log(temp);
        if (temp) {
            temp = false;
        } else {
            temp = true;
        }
        setAdminPanelState(temp);
    }, [
        adminPanelState
    ]);
    console.log(props, adminPanelState);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, adminAuth ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "AdminPanel_Container ".concat(adminPanelState ? "AdminPanel_ContainerOpen" : "")
    }, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement(_manager.Manager, _extends({}, props, {
        adminPanelState: adminPanelState
    })))), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            position: "absolute",
            right: ".5rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        className: "simpleBtn",
        style: {
            height: "20px",
            padding: ".25rem 1rem",
            borderRadius: ".125rem",
            paddingTop: ".125rem"
        },
        onClick: toggleAdminPanel
    }, adminPanelState ? "Close" : "Open", " Admin Panel"))) : null, props.children, props.profileData && props.profileData.user && !props.hideDefault ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "",
        style: {
            padding: styleSafety ? styleSafety.padding : 0,
            margin: styleSafety ? styleSafety.margin : 0
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "PagePadding PagePaddingTop ProfilePage_MetaContainer"
    }, /*#__PURE__*/ _react["default"].createElement("img", {
        className: "ProfilePage_Icon",
        src: props.profileData && props.profileData.user && props.profileData.user.icon ? props.profileData.user.icon : ""
    }), /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "ProfilePage_ProfileName"
    }, props.profileData.user.username)))), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "ProfilePage_Feed"
    }, /*#__PURE__*/ _react["default"].createElement(_gridList["default"], _extends({
        loggedIn: props._loggedIn,
        _gridItems: combinedFeed,
        _gridListType: "video"
    }, props))), /*#__PURE__*/ _react["default"].createElement(_shop.Shop, _extends({}, props, {
        profile: true
    }))) : /*#__PURE__*/ _react["default"].createElement("div", null, "No User here :/"));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 6437:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "ProfilePage", ({
    enumerable: true,
    get: function get() {
        return _ProfilePage["default"];
    }
}));
var _ProfilePage = _interopRequireDefault(__webpack_require__(2463));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 9368:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _image = _interopRequireDefault(__webpack_require__(5675));
var _link = _interopRequireDefault(__webpack_require__(1664));
var _FeatureModule = _interopRequireDefault(__webpack_require__(5432));
var _router = __webpack_require__(1853);
var _util = __webpack_require__(8131);
var _search = __webpack_require__(8838);
var _uuid = __webpack_require__(5828);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var isOverflown = function isOverflown(clientWidth, clientHeight, scrollWidth, scrollHeight) {
    console.log(clientWidth, clientHeight, scrollWidth, scrollHeight);
    return scrollHeight > clientHeight || scrollWidth > clientWidth;
};
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), pageError = _React$useState2[0], setPageError = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), componentDidMount = _React$useState4[0], setComponentDidMount = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), componentId = _React$useState6[0], setComponentId = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), fetchBusy = _React$useState8[0], setFetchBusy = _React$useState8[1];
    var _React$useState9 = _react["default"].useState([]), _React$useState10 = _slicedToArray(_React$useState9, 2), feed = _React$useState10[0], setFeed = _React$useState10[1];
    var _React$useState11 = _react["default"].useState([]), _React$useState12 = _slicedToArray(_React$useState11, 2), combinedFeed = _React$useState12[0], setCombinedFeed = _React$useState12[1];
    var _React$useState13 = _react["default"].useState({}), _React$useState14 = _slicedToArray(_React$useState13, 2), featureData = _React$useState14[0], setFeatureData = _React$useState14[1];
    var _React$useState15 = _react["default"].useState({
        size: "thin"
    }), _React$useState16 = _slicedToArray(_React$useState15, 2), featureState = _React$useState16[0], setFeatureState = _React$useState16[1];
    var _React$useState17 = _react["default"].useState(false), _React$useState18 = _slicedToArray(_React$useState17, 2), stagger = _React$useState18[0], setStagger = _React$useState18[1];
    var _React$useState19 = _react["default"].useState(null), _React$useState20 = _slicedToArray(_React$useState19, 2), checkContainerOverflownTime = _React$useState20[0], setCheckContainerOverflownTime = _React$useState20[1];
    var _React$useState21 = _react["default"].useState(null), _React$useState22 = _slicedToArray(_React$useState21, 2), containerOverflownInterval = _React$useState22[0], setContainerOverflownInterval = _React$useState22[1];
    var _React$useState23 = _react["default"].useState(false), _React$useState24 = _slicedToArray(_React$useState23, 2), useOverflown = _React$useState24[0], setUseOverflown = _React$useState24[1];
    var router = (0, _router.useRouter)();
    var staggerRef = _react["default"].useRef();
    var featureContainerRef = _react["default"].useRef();
    if (componentId) {
        props._LocalEventEmitter.unsubscribe(componentId);
        props._LocalEventEmitter.subscribe(componentId, function(d) {
            if (d && d.dispatch) {
                if (d.dispatch === "checkContainerOverflown") {
                    checkFeatureContainerOverflown();
                }
            }
        });
    }
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            setComponentDidMount(new Date().getTime());
            if (props.stagger) {
                staggerRef.current = setTimeout(function() {
                    setStagger(true);
                }, props.stagger);
            } else {
                setStagger(true);
            }
            var id = (0, _uuid.v4)();
            setComponentId(id);
        }
    }, [
        componentDidMount,
        props.stagger
    ]);
    _react["default"].useEffect(function() {
        if (componentId && props._LocalEventEmitter && !containerOverflownInterval) {
            var r = setInterval(function() {
                props._LocalEventEmitter.dispatch(componentId, {
                    dispatch: "checkContainerOverflown"
                });
            }, 5000);
            setContainerOverflownInterval(r);
        }
    }, [
        props._LocalEventEmitter,
        componentId,
        containerOverflownInterval
    ]);
    _react["default"].useEffect(function() {
        if (stagger) {
            if (props.defaultSize) {
                var temp = _objectSpread({}, featureState);
                temp.size = props.defaultSize;
                setFeatureState(temp);
            }
        }
    }, [
        stagger
    ]);
    var cycleFeatureSize = _react["default"].useCallback(function(e) {
        if (featureState) {
            var temp = _objectSpread({}, featureState);
            if (temp.size === "thin") {
                temp.size = props.defaultSize !== "thin" ? props.defaultSize : "medium";
            } else if (temp.size === "medium") {
                temp.size = props.defaultSize !== "medium" ? props.defaultSize : "thin";
            } else if (temp.size === "large") {
                temp.size = props.defaultSize !== "large" ? props.defaultSize : "thin";
            }
            setFeatureState(temp);
        }
    });
    _react["default"].useEffect(function() {
        var f = /*#__PURE__*/ function() {
            var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                var selector, useData, _props$s, args, res;
                return _regeneratorRuntime().wrap(function _callee$(_context) {
                    while(1)switch(_context.prev = _context.next){
                        case 0:
                            selector = props.featureData ? "featureData" : "noSelection";
                            useData = (0, _util.isObjectEmpty)(featureData) ? props[selector] : featureData;
                            if (!(useData && !fetchBusy)) {
                                _context.next = 13;
                                break;
                            }
                            console.log("Use Data!", useData);
                            if (!(!useData.user && props._loggedIn && props._loggedIn.identifier)) {
                                _context.next = 12;
                                break;
                            }
                            args = {
                                identifier: props._loggedIn.identifier,
                                hash: props._loggedIn.hash,
                                domainKey: props.domainKey,
                                params: {
                                    u: props._loggedIn.identifier,
                                    s: (_props$s = props.s) !== null && _props$s !== void 0 ? _props$s : ""
                                }
                            };
                            _context.next = 8;
                            return (0, _search.fetchSearchData)(props.apiUrl, [
                                "featureData"
                            ], args);
                        case 8:
                            res = _context.sent;
                            if (res) {
                                if (res && res.data && res.data[selector]) {
                                    setFeatureData(res.data[selector]);
                                }
                            }
                            _context.next = 13;
                            break;
                        case 12:
                            setFeatureData(props[selector]);
                        case 13:
                        case "end":
                            return _context.stop();
                    }
                }, _callee);
            }));
            return function f() {
                return _ref.apply(this, arguments);
            };
        }();
        f();
    }, [
        props.featureData,
        feed,
        fetchBusy,
        combinedFeed,
        props._loggedIn,
        props.domainKey
    ]);
    _react["default"].useEffect(function() {
        var f = featureData.data && Array.isArray(featureData.data) ? featureData.data.concat(feed) : [];
        var update = false;
        for(var i = 0; i < combinedFeed.length; i++){
            if (!(0, _util.compareObjects)(combinedFeed, f)) {
                update = true;
                break;
            }
        }
        if (combinedFeed.length === 0 && f.length !== 0) {
            setCombinedFeed(f);
        }
    }, [
        featureData
    ]);
    var myLoader = function myLoader(_ref2) {
        var src = _ref2.src;
        if (src.match(/greythumb/)) {
            return "".concat(src);
        } else if (props.cdn && props.cdn["static"] && props.cdn["static"].length > 0) {
            return "".concat(props.cdn["static"], "/").concat(src);
        }
    };
    var checkFeatureContainerOverflown = function checkFeatureContainerOverflown() {
        if (!checkContainerOverflownTime || checkContainerOverflownTime && checkContainerOverflownTime < new Date().getTime() - 5000) {
            if (featureContainerRef.current) {
                setCheckContainerOverflownTime(new Date().getTime());
                var clientWidth = featureContainerRef.current.clientWidth;
                var clientHeight = featureContainerRef.current.clientHeight;
                var scrollWidth = featureContainerRef.current.scrollWidth;
                var scrollHeight = featureContainerRef.current.scrollHeight;
                var overflown = isOverflown(clientWidth, clientHeight, scrollWidth, scrollHeight);
                if (overflown) {
                    setUseOverflown(overflown);
                    return overflown;
                }
            }
            return false;
        }
    };
    console.log(combinedFeed);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_FeatureModule["default"].featureExternalContainer, " ").concat(combinedFeed.length > 0 ? featureState.size === "thin" ? "FeatureContainerOpen" : featureState.size === "medium" ? "FeatureContainerOpen ".concat(_FeatureModule["default"].featureContainerOpen, " FeatureContainerOpenMedium") : featureState.size === "large" ? "FeatureContainerOpen ".concat(_FeatureModule["default"].featureContainerOpen, " FeatureContainerOpenLarge") : "" : "", " ").concat(props.className)
    }, !props.hideToggle && combinedFeed.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_FeatureModule["default"].sizeExpandContainer)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_FeatureModule["default"].sizeExpand),
        onClick: cycleFeatureSize
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), combinedFeed.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_FeatureModule["default"].featureContainer, " ").concat(featureState && featureState.size ? featureState.size === "medium" ? _FeatureModule["default"].featureContainerMedium : featureState.size === "large" ? _FeatureModule["default"].featureContainerLarge : "" : "", " ").concat(useOverflown ? featureState.size === "medium" ? "featureContainerOverflown featureContainerOverflown_medium" : featureState.size === "large" ? "featureContainerOverflown featureContainerOverflown_large" : "" : ""),
        ref: featureContainerRef
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_FeatureModule["default"].itemContainer, " ").concat(featureState.size === "thin" ? _FeatureModule["default"].itemContainerThin : "")
    }, combinedFeed.map(function(item) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].item, " ").concat(featureState.size === "thin" ? _FeatureModule["default"].itemThin : "")
        }, /*#__PURE__*/ _react["default"].createElement(_link["default"], {
            href: "w?v=".concat(item.id)
        }, item.status === "live" && featureState.size !== "thin" ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "LiveTag ".concat(_FeatureModule["default"].statusContainer)
        }, "LIVE", /*#__PURE__*/ _react["default"].createElement("div", {
            className: "RecordingCircle RecordingCircle_Small"
        })) : "", featureState.size !== "thin" ? /*#__PURE__*/ _react["default"].createElement(_image["default"], {
            loader: myLoader,
            src: item.thumbnail && props.cdn && props.cdn["static"] ? item.thumbnail : "img/default/greythumb.jpg",
            alt: item.title ? item.title : "",
            width: 60,
            height: 30,
            layout: "responsive"
        }) : null, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].itemMetaContainer, " ").concat(featureState.size === "thin" ? _FeatureModule["default"].thinMetaContainerSize : "")
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].itemMetaContainerPadding)
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].itemMetaText)
        }, item.status === "live" && featureState.size === "thin" ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "LiveTag ".concat(_FeatureModule["default"].statusContainerInline)
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "RecordingCircle RecordingCircle_Small"
        })) : "", console.log(item.title.length), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "flex gap-p2 ".concat((item.title.length ? item.title.length : "".concat(item.author_username, " is Streaming Now").length) + item.author_username.length > 20 ? "marquee" : "", " ").concat(featureState.size === "thin" ? _FeatureModule["default"].thinMeta : "")
        }, (item.title.length ? item.title.length : "".concat(item.author_username, " is Streaming Now").length) + item.author_username.length > 20 ? /*#__PURE__*/ _react["default"].createElement("div", {
            className: "marqueeContainer"
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "marquee1"
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].titleText)
        }, item.title ? item.title : "".concat(item.author_username, " is Streaming Now")), /*#__PURE__*/ _react["default"].createElement("span", null, " - "), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].authorUser)
        }, item.author_username)), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "marquee2"
        }, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].titleText)
        }, item.title ? item.title : "".concat(item.author_username, " is Streaming Now")), /*#__PURE__*/ _react["default"].createElement("span", null, " - "), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].authorUser)
        }, item.author_username))) : /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].titleText)
        }, item.title ? item.title : "".concat(item.author_username, " is Streaming Now")), /*#__PURE__*/ _react["default"].createElement("span", null, " - "), /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_FeatureModule["default"].authorUser)
        }, item.author_username))))))));
    }))) : null);
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 7173:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "Feature", ({
    enumerable: true,
    get: function get() {
        return _Feature["default"];
    }
}));
var _Feature = _interopRequireDefault(__webpack_require__(9368));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 3750:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _image = _interopRequireDefault(__webpack_require__(5675));
var _link = _interopRequireDefault(__webpack_require__(1664));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), pageError = _React$useState2[0], setPageError = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), componentDidMount = _React$useState4[0], setComponentDidMount = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), componentId = _React$useState6[0], setComponentId = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), fetchBusy = _React$useState8[0], setFetchBusy = _React$useState8[1];
    var myLoader = function myLoader(_ref) {
        var src = _ref.src;
        if (src.match(/greythumb/)) {
            return "".concat(src);
        } else if (props.cdn && props.cdn["static"] && props.cdn["static"].length > 0) {
            return "".concat(props.cdn["static"], "/").concat(src);
        }
    };
    console.log(props, props.image1);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "WideFeatureContainer ".concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "WideFeatureInnerContainer"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            maxHeight: "200px"
        }
    }, /*#__PURE__*/ _react["default"].createElement(_image["default"], {
        loader: myLoader,
        src: props.image1 && props.cdn && props.cdn["static"] ? props.image1 : "img/default/greythumb.jpg",
        width: 320,
        height: 180,
        layout: "responsive",
        style: {
            borderRadius: "1rem"
        }
    }))));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 9101:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "WideFeature", ({
    enumerable: true,
    get: function get() {
        return _WideFeature["default"];
    }
}));
var _WideFeature = _interopRequireDefault(__webpack_require__(3750));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 731:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _router = __webpack_require__(1853);
var _streaming = __webpack_require__(8308);
var _SignIn = __webpack_require__(5203);
var _ecommerce = __webpack_require__(6102);
var _uuid = __webpack_require__(5828);
var _Tooltip = _interopRequireDefault(__webpack_require__(7229));
var _ManagerModule = _interopRequireDefault(__webpack_require__(6428));
var _material = __webpack_require__(5692);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), pageError = _React$useState2[0], setPageError = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), componentDidMount = _React$useState4[0], setComponentDidMount = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), componentId = _React$useState6[0], setComponentId = _React$useState6[1];
    var _React$useState7 = _react["default"].useState(false), _React$useState8 = _slicedToArray(_React$useState7, 2), didCheckStream = _React$useState8[0], setDidCheckStream = _React$useState8[1];
    var _React$useState9 = _react["default"].useState(false), _React$useState10 = _slicedToArray(_React$useState9, 2), currentlyStreaming = _React$useState10[0], setCurrentlyStreaming = _React$useState10[1];
    var _React$useState11 = _react["default"].useState(null), _React$useState12 = _slicedToArray(_React$useState11, 2), streamKey = _React$useState12[0], setStreamKey = _React$useState12[1];
    var _React$useState13 = _react["default"].useState(null), _React$useState14 = _slicedToArray(_React$useState13, 2), streamTo = _React$useState14[0], setStreamTo = _React$useState14[1];
    var _React$useState15 = _react["default"].useState(false), _React$useState16 = _slicedToArray(_React$useState15, 2), fetchBusy = _React$useState16[0], setFetchBusy = _React$useState16[1];
    var _React$useState17 = _react["default"].useState("stream"), _React$useState18 = _slicedToArray(_React$useState17, 2), openMenu = _React$useState18[0], setOpenMenu = _React$useState18[1];
    var _React$useState19 = _react["default"].useState({}), _React$useState20 = _slicedToArray(_React$useState19, 2), creatingShop = _React$useState20[0], setCreatingShop = _React$useState20[1];
    var _React$useState21 = _react["default"].useState({
        password: null,
        "private": false,
        dates: [],
        tags: [],
        input: ""
    }), _React$useState22 = _slicedToArray(_React$useState21, 2), streamSettings = _React$useState22[0], setStreamSettings = _React$useState22[1];
    var _React$useState23 = _react["default"].useState(false), _React$useState24 = _slicedToArray(_React$useState23, 2), askEndStream = _React$useState24[0], setAskEndStream = _React$useState24[1];
    var _React$useState25 = _react["default"].useState(false), _React$useState26 = _slicedToArray(_React$useState25, 2), updatingStreamConfig = _React$useState26[0], setUpdatingStreamConfig = _React$useState26[1];
    var fetchTimeoutRef = _react["default"].useRef();
    var proposedShopName = _react["default"].useRef();
    var proposedShopDesc = _react["default"].useRef();
    var privateRef = _react["default"].useRef();
    var privateRef2 = _react["default"].useRef();
    var passwordRef = _react["default"].useRef();
    var passwordRef2 = _react["default"].useRef();
    var titleRef = _react["default"].useRef();
    var descriptionRef = _react["default"].useRef();
    var myTagsRef = _react["default"].useRef();
    if (componentId) {
        props._LocalEventEmitter.unsubscribe(componentId);
        props._LocalEventEmitter.subscribe(componentId, function(d) {
            if (d && d.dispatch) {
                if (d.dispatch === "paintStreamData") {
                    setStreamData(currentlyStreaming);
                }
            }
        });
    }
    var router = (0, _router.useRouter)();
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            var id = (0, _uuid.v4)();
            setComponentId(id);
            setComponentDidMount(true);
        }
    }, [
        componentDidMount
    ]);
    _react["default"].useEffect(function() {
        if (props._loggedIn && props._loggedIn.username && !didCheckStream) {
            setDidCheckStream(true);
            checkStream(true);
        }
    }, [
        props._loggedIn,
        didCheckStream
    ]);
    var checkStream = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
            var dontForce, data, res, d, _args = arguments;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        dontForce = _args.length > 0 && _args[0] !== undefined ? _args[0] : false;
                        _context.prev = 1;
                        if (fetchBusy) {
                            _context.next = 19;
                            break;
                        }
                        setFetchBusy(true);
                        fetchTimeoutRef.current = setTimeout(function() {
                            setFetchBusy(false);
                        }, 10000);
                        data = {
                            stripeSecret: props._stripeSecret,
                            dontForce: dontForce,
                            streamSettings: streamSettings
                        };
                        _context.next = 8;
                        return (0, _streaming.beginStream)(props.apiUrl, props.domainKey, data, _SignIn.checkSignedIn);
                    case 8:
                        res = _context.sent;
                        if (fetchTimeoutRef.current) {
                            clearTimeout(fetchTimeoutRef.current);
                        }
                        if (res) {
                            _context.next = 18;
                            break;
                        }
                        if (!dontForce) {
                            _context.next = 14;
                            break;
                        }
                        setFetchBusy(false);
                        return _context.abrupt("return");
                    case 14:
                        props._setPageError("Failed to save begin stream");
                        setFetchBusy(false);
                        _context.next = 19;
                        break;
                    case 18:
                        if (res == "disauthenticated") {
                            props._setLoggedIn(false);
                            props._setStripeSecret(false);
                            setFetchBusy(false);
                            (0, _SignIn.logout)();
                        } else if (res.status == "success") {
                            // On successfull credit card received, purchase phone number and then update locally
                            setFetchBusy(false);
                            console.log("check stream", res);
                            if (res.data && res.data.status == "streaming" && res.data.stream) {
                                setCurrentlyStreaming(res.data.stream);
                                setStreamData(res.data.stream);
                                if (res.data.key) {
                                    setStreamKey(res.data.key);
                                }
                                if (res.data.streamTo) {
                                    setStreamTo(res.data.streamTo);
                                }
                                if (res.data.stream.meta && res.data.stream.meta.streamSettings) {
                                    d = res.data.stream.meta.streamSettings;
                                    setStreamSettings(d);
                                }
                                if (props._LocalEventEmitter) {
                                    props._LocalEventEmitter.dispatch("refetchDefaults", {
                                        dispatch: "simple"
                                    });
                                }
                            }
                        }
                    case 19:
                        _context.next = 25;
                        break;
                    case 21:
                        _context.prev = 21;
                        _context.t0 = _context["catch"](1);
                        if (fetchTimeoutRef.current) {
                            clearTimeout(fetchTimeoutRef.current);
                        }
                        setFetchBusy(false);
                    case 25:
                    case "end":
                        return _context.stop();
                }
            }, _callee, null, [
                [
                    1,
                    21
                ]
            ]);
        }));
        return function checkStream() {
            return _ref.apply(this, arguments);
        };
    }();
    var setStreamData = function setStreamData(stream) {
        try {
            if (stream) {
                titleRef.current.value = stream.title;
                descriptionRef.current.value = stream.description;
                myTagsRef.current.value = stream.tags;
            }
        } catch (err) {
        // fail silently
        }
    };
    var updateStreamConfig = _react["default"].useCallback(function(e) {
        updateStreamConfigFn();
    });
    var updateStreamConfigFn = /*#__PURE__*/ function() {
        var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2() {
            var streamData, data, res, d;
            return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                while(1)switch(_context2.prev = _context2.next){
                    case 0:
                        _context2.prev = 0;
                        if (fetchBusy) {
                            _context2.next = 12;
                            break;
                        }
                        setFetchBusy(true);
                        setUpdatingStreamConfig(true);
                        fetchTimeoutRef.current = setTimeout(function() {
                            setFetchBusy(false);
                            setUpdatingStreamConfig(false);
                        }, 10000);
                        streamData = {
                            title: titleRef.current && titleRef.current.value ? titleRef.current.value : null,
                            description: descriptionRef.current && descriptionRef.current.value ? descriptionRef.current.value : null,
                            tags: myTagsRef.current && myTagsRef.current.value ? myTagsRef.current.value : null
                        };
                        data = {
                            stream: currentlyStreaming.id,
                            streamData: streamData,
                            streamSettings: streamSettings
                        };
                        _context2.next = 9;
                        return (0, _streaming.updateStreamConfigRequest)(props.apiUrl, props.domainKey, data, _SignIn.checkSignedIn);
                    case 9:
                        res = _context2.sent;
                        if (fetchTimeoutRef.current) {
                            clearTimeout(fetchTimeoutRef.current);
                        }
                        if (!res) {
                            props._setPageError("Failed to save begin stream");
                            setFetchBusy(false);
                            setUpdatingStreamConfig(false);
                        } else if (res == "disauthenticated") {
                            props._setLoggedIn(false);
                            props._setStripeSecret(false);
                            setFetchBusy(false);
                            setUpdatingStreamConfig(false);
                            (0, _SignIn.logout)();
                        } else if (res.status == "success") {
                            // On successfull credit card received, purchase phone number and then update locally
                            console.log("check stream", res);
                            setFetchBusy(false);
                            setUpdatingStreamConfig(false);
                            if (res.data && res.data.status == "streaming") {
                                setCurrentlyStreaming(res.data.stream);
                                if (res.data.key) {
                                    setStreamKey(res.data.key);
                                }
                                if (res.data.streamTo) {
                                    setStreamTo(res.data.streamTo);
                                }
                                if (res.data.stream) {
                                    if (res.data.stream.meta && res.data.stream.meta.streamSettings) {
                                        d = res.data.stream.meta.streamSettings;
                                        setStreamSettings(d);
                                    }
                                }
                            }
                        }
                    case 12:
                        _context2.next = 20;
                        break;
                    case 14:
                        _context2.prev = 14;
                        _context2.t0 = _context2["catch"](0);
                        console.log(_context2.t0);
                        if (fetchTimeoutRef.current) {
                            clearTimeout(fetchTimeoutRef.current);
                        }
                        setFetchBusy(false);
                        setUpdatingStreamConfig(false);
                    case 20:
                    case "end":
                        return _context2.stop();
                }
            }, _callee2, null, [
                [
                    0,
                    14
                ]
            ]);
        }));
        return function updateStreamConfigFn() {
            return _ref2.apply(this, arguments);
        };
    }();
    var beginStreaming = _react["default"].useCallback(function(e) {
        checkStream();
    });
    var handleSetAdminMenu = _react["default"].useCallback(function(e) {
        try {
            if (e.target.getAttribute("menu")) {
                var menu = e.target.getAttribute("menu");
                setOpenMenu(menu);
            }
        } catch (err) {
        // fail silently
        }
    });
    _react["default"].useEffect(function() {
        if (streamSettings) {
            resolveState(streamSettings);
            props._LocalEventEmitter.dispatch(componentId, {
                dispatch: "paintStreamData"
            });
        }
    }, [
        componentId,
        props._LocalEventEmitter,
        props.adminPanelState,
        streamSettings
    ]);
    var resolveState = function resolveState(d) {
        var useSettings = d ? d : streamSettings;
        privateRef.current ? privateRef.current.checked = useSettings["private"] : null;
        privateRef2.current ? privateRef2.current.checked = useSettings["private"] : null;
        passwordRef.current ? passwordRef.current.value = useSettings.password : null;
        passwordRef2.current ? passwordRef2.current.value = useSettings.password : null;
        console.log(streamSettings);
    };
    console.log(props, streamSettings);
    var handleCreateShop = _react["default"].useCallback(/*#__PURE__*/ function() {
        var _ref3 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee3(e) {
            var phase, res;
            return _regeneratorRuntime().wrap(function _callee3$(_context3) {
                while(1)switch(_context3.prev = _context3.next){
                    case 0:
                        _context3.prev = 0;
                        setPageError(null);
                        if (!e.target.getAttribute("phase")) {
                            _context3.next = 19;
                            break;
                        }
                        phase = e.target.getAttribute("phase");
                        if (!(phase == "1")) {
                            _context3.next = 8;
                            break;
                        }
                        setCreatingShop({
                            status: "start"
                        });
                        _context3.next = 19;
                        break;
                    case 8:
                        if (!(phase == "end")) {
                            _context3.next = 19;
                            break;
                        }
                        console.log("Run request create shop", proposedShopName.current);
                        setFetchBusy(true);
                        if (!(proposedShopName.current && proposedShopName.current.value)) {
                            _context3.next = 18;
                            break;
                        }
                        _context3.next = 14;
                        return (0, _ecommerce.createShop)(props.apiUrl, props.domainKey, props._loggedIn, {
                            shopName: proposedShopName.current.value,
                            shopDescription: proposedShopDesc.current.value
                        });
                    case 14:
                        res = _context3.sent;
                        if (res) {
                            console.log(res);
                            router.reload(window.location.pathname);
                        } else {
                            setPageError({
                                message: "Shop creation submission failed",
                                placement: "openshop"
                            });
                        }
                        _context3.next = 19;
                        break;
                    case 18:
                        setPageError({
                            message: "Please fill out a Shop Name",
                            placement: "description"
                        });
                    case 19:
                        _context3.next = 24;
                        break;
                    case 21:
                        _context3.prev = 21;
                        _context3.t0 = _context3["catch"](0);
                        console.log(_context3.t0); // fail silently
                    case 24:
                    case "end":
                        return _context3.stop();
                }
            }, _callee3, null, [
                [
                    0,
                    21
                ]
            ]);
        }));
        return function(_x2) {
            return _ref3.apply(this, arguments);
        };
    }());
    var handleClearError = _react["default"].useCallback(function(e) {
        setPageError(null);
    });
    var updateTags = _react["default"].useCallback(function(e) {
        var temp = _objectSpread({}, streamSettings);
        var values = e.currentTarget.value.split(" ");
        var dates = [];
        var tags = [];
        values.map(function(v) {
            if (!isNaN(new Date(v))) {
                dates.push(new Date(v));
            } else {
                tags.push(v);
            }
        });
        temp.dates = dates;
        temp.tags = tags;
        setStreamSettings(temp);
    });
    var setPrivate = _react["default"].useCallback(function(e) {
        var temp = _objectSpread({}, streamSettings);
        temp["private"] = e.currentTarget.checked;
        setStreamSettings(temp);
    });
    var setPassword = _react["default"].useCallback(function(e) {
        var temp = _objectSpread({}, streamSettings);
        temp.password = e.currentTarget.value;
        setStreamSettings(temp);
    });
    var handleAskEndStream = _react["default"].useCallback(function(e) {
        if (e.currentTarget.getAttribute("modif")) {
            var m = e.currentTarget.getAttribute("modif");
            if (m == "yes") {
                // end stream
                try {
                    var f = /*#__PURE__*/ function() {
                        var _ref4 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee4() {
                            var data, res;
                            return _regeneratorRuntime().wrap(function _callee4$(_context4) {
                                while(1)switch(_context4.prev = _context4.next){
                                    case 0:
                                        console.log("end st", fetchBusy);
                                        if (fetchBusy) {
                                            _context4.next = 10;
                                            break;
                                        }
                                        setFetchBusy(true);
                                        fetchTimeoutRef.current = setTimeout(function() {
                                            setFetchBusy(false);
                                        }, 10000);
                                        data = {
                                            stream: currentlyStreaming.id
                                        };
                                        _context4.next = 7;
                                        return (0, _streaming.endStream)(props.apiUrl, props.domainKey, data, _SignIn.checkSignedIn);
                                    case 7:
                                        res = _context4.sent;
                                        if (fetchTimeoutRef.current) {
                                            clearTimeout(fetchTimeoutRef.current);
                                        }
                                        if (!res) {
                                            setAskEndStream(false);
                                            props._setPageError("Failed to end stream");
                                            setFetchBusy(false);
                                        } else if (res == "disauthenticated") {
                                            setAskEndStream(false);
                                            props._setLoggedIn(false);
                                            props._setStripeSecret(false);
                                            setFetchBusy(false);
                                            (0, _SignIn.logout)();
                                        } else if (res.status == "success") {
                                            setAskEndStream(false);
                                            // On successfull credit card received, purchase phone number and then update locally
                                            setFetchBusy(false);
                                            setCurrentlyStreaming(false);
                                            setStreamKey(null);
                                            setStreamTo(null);
                                            setStreamSettings({
                                                password: null,
                                                "private": false,
                                                dates: [],
                                                tags: [],
                                                input: ""
                                            });
                                            if (props._LocalEventEmitter) {
                                                props._LocalEventEmitter.dispatch("refetchDefaults", {
                                                    dispatch: "simple"
                                                });
                                            }
                                        }
                                    case 10:
                                    case "end":
                                        return _context4.stop();
                                }
                            }, _callee4);
                        }));
                        return function f() {
                            return _ref4.apply(this, arguments);
                        };
                    }();
                    f();
                } catch (err) {
                    setAskEndStream(false);
                    if (fetchTimeoutRef.current) {
                        clearTimeout(fetchTimeoutRef.current);
                    }
                    setFetchBusy(false);
                }
            } else {
                setAskEndStream(false);
            }
        } else if (!askEndStream) {
            setAskEndStream(true);
        }
    });
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, pageError && pageError.message && !pageError.placement ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "error",
        style: {
            margin: ".25rem",
            marginBottom: "0"
        },
        onClick: handleClearError
    }, pageError.message) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2"
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_ManagerModule["default"].itemsContainer, " Manager_Items"),
        style: {
            padding: ".5rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        className: "".concat(openMenu == "stream" ? _ManagerModule["default"].activeItem : "", " ").concat(_ManagerModule["default"].item),
        onClick: handleSetAdminMenu,
        menu: "stream"
    }, "Stream"), /*#__PURE__*/ _react["default"].createElement("button", {
        className: "".concat(openMenu == "shop" ? _ManagerModule["default"].activeItem : "", " ").concat(_ManagerModule["default"].item),
        onClick: handleSetAdminMenu,
        menu: "shop"
    }, "Shop")), openMenu === "stream" ? props._loggedIn && props._loggedIn.username ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p5",
        style: {
            padding: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            height: "90px",
            maxWidth: "300px"
        }
    }, !currentlyStreaming ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            height: "100%"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            paddingTop: "0",
            paddingBottom: ".125rem",
            textAlign: "center"
        }
    }, "Stream on ", props.siteTitle, " Now"), !fetchBusy ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            alignItems: "center",
            marginBottom: ".125rem",
            height: "inherit"
        }
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        className: "simpleBtn",
        onClick: beginStreaming,
        style: {
            padding: ".125rem 2rem",
            fontSize: "1.5rem",
            paddingTop: ".125rem",
            width: "-webkit-fill-available",
            height: "75px"
        }
    }, "Begin Stream"), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center",
            background: "black",
            padding: "0 .25rem",
            borderRadius: ".25rem",
            marginTop: ".25rem",
            justifyContent: "space-between"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("label", {
        style: {
            fontSize: ".8rem"
        }
    }, "Private"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        onChange: setPrivate,
        ref: privateRef
    })), streamSettings["private"] ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("label", {
        style: {
            fontSize: ".8rem"
        }
    }, "Password"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        onChange: setPassword,
        style: {
            maxWidth: "100px",
            maxHeight: "16px",
            fontSize: ".85rem",
            marginLeft: ".25rem",
            borderRadius: ".25rem"
        },
        ref: passwordRef
    })) : null)) : /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem"
        }
    }, "Please wait...")) : /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "importantPrompt"
    }, "Now Streaming ", /*#__PURE__*/ _react["default"].createElement("div", {
        className: "RecordingCircle RecordingCircle_Small"
    })), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem",
            overflowWrap: "anywhere"
        }
    }, /*#__PURE__*/ _react["default"].createElement("b", null, "Share your stream link:"), " ", /*#__PURE__*/ _react["default"].createElement("span", {
        style: {
            background: "black",
            padding: "0 .125rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("a", {
        href: "".concat(props.devLocal ? props.devAddress : "https://" + props.domainUrl, "/w?u=").concat(props._loggedIn.username)
    }, "".concat(props.devLocal ? props.devAddress : props.domainUrl, "/w?u=").concat(props._loggedIn.username)))), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem",
            fontWeight: 600,
            color: "#94ff94",
            overflowWrap: "anywhere"
        }
    }, "Stream Endpoint: ", /*#__PURE__*/ _react["default"].createElement("span", {
        style: {
            fontWeight: 400,
            background: "black",
            padding: "0 .125rem"
        }
    }, streamTo)), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem",
            fontWeight: 600,
            color: "#ff81ca",
            overflowWrap: "anywhere"
        }
    }, "Private Stream Key: ", /*#__PURE__*/ _react["default"].createElement("span", {
        style: {
            fontWeight: 400,
            background: "black",
            padding: "0 .125rem"
        }
    }, streamKey)))), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            paddingBottom: ".25rem",
            width: "250px"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        modif: "title",
        ref: titleRef,
        placeholder: "Title",
        style: {
            width: "100%"
        }
    })), /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("textarea", {
        modif: "description",
        ref: descriptionRef,
        placeholder: "Description",
        style: {
            maxWidth: "100%",
            marginTop: ".25rem",
            width: "100%",
            height: "90px"
        }
    })), /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        modif: "tags",
        ref: myTagsRef,
        placeholder: "Tags",
        style: {
            width: "100%"
        }
    }))), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            paddingBottom: ".25rem",
            maxWidth: "250px"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".8rem",
            marginBottom: ".125rem",
            marginTop: ".125rem"
        }
    }, "Create your own Auth Tags to provide authorization to watch the stream for any tickets with matching tags"), /*#__PURE__*/ _react["default"].createElement(_Tooltip["default"], {
        title: "Enter dates in the following format MON-DD-YYYY or they will not be parsed as dates. Values that do not match dates will be parsed as tags that can be added to livestreams. Any matches will authorize viewership of tickets with matching tags for the stream",
        className: "flex gap-p2",
        style: {
            alignItems: "center"
        },
        placement: "right"
    }, /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        style: {
            marginBottom: ".125rem",
            width: "-webkit-fill-available"
        },
        placeholder: "Date in DD/MM/YY format or a Tag",
        onInput: updateTags,
        option: "livestreamDef",
        defaultValue: streamSettings.input
    })), streamSettings.dates.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, streamSettings.dates.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d && d.toLocaleString ? d.toLocaleString("en-US", {
            year: "numeric",
            month: "long",
            day: "2-digit"
        }) : "");
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), streamSettings.tags.length > 0 ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "tagContainer",
        style: {
            marginTop: ".25rem"
        }
    }, streamSettings.tags.map(function(d) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "tagItem"
        }, d);
    })) : /*#__PURE__*/ _react["default"].createElement("div", null), currentlyStreaming ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center",
            background: "black",
            padding: "0 .25rem",
            borderRadius: ".25rem",
            marginTop: ".25rem",
            justifyContent: "space-between"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("label", {
        style: {
            fontSize: ".8rem"
        }
    }, "Private"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "checkbox",
        onChange: setPrivate,
        ref: privateRef2
    })), streamSettings && streamSettings["private"] ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            alignItems: "center"
        }
    }, /*#__PURE__*/ _react["default"].createElement("label", {
        style: {
            fontSize: ".8rem"
        }
    }, "Password"), /*#__PURE__*/ _react["default"].createElement("input", {
        type: "text",
        onChange: setPassword,
        style: {
            maxWidth: "100px",
            maxHeight: "16px",
            fontSize: ".85rem",
            marginLeft: ".25rem",
            borderRadius: ".25rem"
        },
        ref: passwordRef2
    })) : null) : null, currentlyStreaming ? !askEndStream ? /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, !updatingStreamConfig ? /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%",
            marginTop: ".25rem",
            lineHeight: "12.5px",
            fontSize: ".8rem"
        },
        onClick: updateStreamConfig
    }, "Update") : /*#__PURE__*/ _react["default"].createElement(_material.LinearProgress, {
        color: "inherit",
        style: {
            height: "18.25px",
            marginTop: ".25rem"
        }
    }), /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%",
            marginTop: ".25rem",
            lineHeight: "12.5px",
            fontSize: ".8rem"
        },
        onClick: handleAskEndStream
    }, "Terminate Stream")) : /*#__PURE__*/ _react["default"].createElement(_react["default"].Fragment, null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontWeight: 600,
            textAlign: "center",
            marginTop: ".42rem"
        }
    }, "Terminate the Stream?"), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "flex gap-p2"
    }, /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%",
            marginTop: ".25rem",
            lineHeight: "12.5px",
            fontSize: ".8rem"
        },
        onClick: handleAskEndStream,
        modif: "yes"
    }, "Yes"), /*#__PURE__*/ _react["default"].createElement("button", {
        style: {
            width: "100%",
            marginTop: ".25rem",
            lineHeight: "12.5px",
            fontSize: ".8rem"
        },
        onClick: handleAskEndStream,
        modif: "no"
    }, "No"))) : null))) : /*#__PURE__*/ _react["default"].createElement("div", null, props._loggedIn ? !props._loggedIn.username ? "Please register Username to begin streaming" : "Please login to begin streaming" : null) : openMenu === "shop" ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            padding: ".25rem"
        }
    }, props.shopProfileData && props.shopProfileData.shop && props.shopProfileData.shop.status && props.shopProfileData.shop.status == "nonexistent" ? /*#__PURE__*/ _react["default"].createElement("div", null, !creatingShop.status ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            flexDirection: "column",
            gap: ".25rem",
            paddingTop: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem"
        }
    }, "You do not currently own a shop. Would you like to request to open one?"), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleCreateShop,
        phase: "1"
    }, "Start Creating Shop"), /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem"
        }
    }, "A shop allows for you to sell products on ", props.siteTitle, " with ease to all customers, fans, collectors, enthusiasts and passerbys utilizing all the tools offered on the platform. You will be able to track pending orders that have yet to be completed, products in carts, your personal inventory, sales and much more as well as sell products in such a way that makes it easier for your customers.")) : creatingShop.status && creatingShop.status == "start" ? /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            display: "flex",
            flexDirection: "column",
            gap: ".25rem",
            paddingTop: ".25rem"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem"
        }
    }, "Name your Shop"), /*#__PURE__*/ _react["default"].createElement("input", {
        ref: proposedShopName,
        type: "text",
        placeholder: "Shop Name",
        className: "simpleTextInput"
    }), /*#__PURE__*/ _react["default"].createElement("textarea", {
        rows: "5",
        style: {
            height: "auto",
            resize: "none"
        },
        ref: proposedShopDesc,
        type: "text",
        placeholder: "You can describe your Shop here. You might put a company slogan, introduce your business, describe the products you sell or nothing at all. It is up to you and your stakeholders.",
        className: "simpleTextInput"
    }), pageError && pageError.message && pageError.placement == "description" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "error",
        onClick: handleClearError
    }, pageError.message) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".75rem",
            background: "black",
            padding: ".125rem"
        }
    }, "When creating your shop, you must set up your vendor account. Please have your banking details ready for direct deposit setup. If you don't have banking details prepared at the moment, you can always set them up later. Once your shop is created, you can start creating products and showcasing them to the public. For all physical products, it is your responsibility to ensure that you have sufficient inventory available for direct-to-consumer sales through the platform. If any products offered for sale are out of stock, any payments received must be fully refunded to customers without exceptions. As a shop owner, you will be subject to platform fees, which will be deducted from your total revenues on the platform. ", props.siteTitle, " reserves the right to close any shop that is suspected of operating in a manner that jeopardizes the quality of service and integrity of the platform. All transactions on ", props.siteTitle, " are handled using Tycoon Systems Ecommerce Services. Any disputes on ", props.siteTitle, " are settled by the ", props.siteTitle, " platform. By submitting a request to open your shop below, you agree to the above terms and conditions."), /*#__PURE__*/ _react["default"].createElement("button", {
        onClick: handleCreateShop,
        phase: "end"
    }, "Open Shop"), pageError && pageError.message && pageError.placement == "openshop" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "error",
        onClick: handleClearError
    }, pageError.message) : null) : null) : props.shopProfileData && props.shopProfileData.shop && props.shopProfileData.shop.name ? /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        style: {
            fontSize: ".85rem"
        }
    }, props.shopProfileData.shop.name)) : null) : null));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 8958:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "Manager", ({
    enumerable: true,
    get: function get() {
        return _Manager["default"];
    }
}));
var _Manager = _interopRequireDefault(__webpack_require__(731));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 1713:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _video = _interopRequireDefault(__webpack_require__(5335));
var _WatchPageModule = _interopRequireDefault(__webpack_require__(4334));
var _onboarding = __webpack_require__(4137);
var _streaming = __webpack_require__(8308);
var _utility = __webpack_require__(615);
var _uuid = __webpack_require__(5828);
var _util = __webpack_require__(8131);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var defaultPoster = "img/internal/videoposter.png";
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), componentDidMount = _React$useState2[0], setComponentDidMount = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(null), _React$useState4 = _slicedToArray(_React$useState3, 2), componentId = _React$useState4[0], setComponentId = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(false), _React$useState6 = _slicedToArray(_React$useState5, 2), fetchBusy = _React$useState6[0], setFetchBusy = _React$useState6[1];
    var _React$useState7 = _react["default"].useState({
        action: "page_loaded",
        trying: "play_video",
        src: ""
    }), _React$useState8 = _slicedToArray(_React$useState7, 2), intent = _React$useState8[0], setIntent = _React$useState8[1];
    var _React$useState9 = _react["default"].useState(false), _React$useState10 = _slicedToArray(_React$useState9, 2), authorized = _React$useState10[0], setAuthorized = _React$useState10[1];
    var _React$useState11 = _react["default"].useState({}), _React$useState12 = _slicedToArray(_React$useState11, 2), authRequirement = _React$useState12[0], setAuthRequirement = _React$useState12[1];
    var _React$useState13 = _react["default"].useState({}), _React$useState14 = _slicedToArray(_React$useState13, 2), streamLeadPrompt = _React$useState14[0], setStreamLeadPrompt = _React$useState14[1];
    var _React$useState15 = _react["default"].useState(null), _React$useState16 = _slicedToArray(_React$useState15, 2), password = _React$useState16[0], setPassword = _React$useState16[1];
    var _React$useState17 = _react["default"].useState({}), _React$useState18 = _slicedToArray(_React$useState17, 2), relevantTicket = _React$useState18[0], setRelevantTicket = _React$useState18[1];
    var _React$useState19 = _react["default"].useState(defaultPoster), _React$useState20 = _slicedToArray(_React$useState19, 2), currentPoster = _React$useState20[0], setCurrentPoster = _React$useState20[1];
    var videoPlayer = _react["default"].useRef();
    var videoContainer = _react["default"].useRef();
    var videoComponent = _react["default"].useRef();
    var controlsContainer = _react["default"].useRef();
    var authContainer = _react["default"].useRef();
    var checkAuthThreshold = 2500;
    if (componentId) {
        props._LocalEventEmitter.unsubscribe(componentId);
        props._LocalEventEmitter.subscribe(componentId, function(d) {
            if (d && d.dispatch) {
                if (d.dispatch === "updateAuth") {
                    if (!authorized && authContainer.current) {
                        var prompt = {
                            type: "auth",
                            lead: "Not Authorized",
                            description: "You have not been authorized to watch the stream"
                        };
                        console.log("auth req", authRequirement);
                        if (authRequirement) {
                            if (authRequirement.password) {
                                prompt.password = "The stream requires a password";
                            }
                            if (authRequirement.tags && authRequirement.dates && (authRequirement.tags.length > 0 || authRequirement.dates.length > 0)) {
                                prompt.tags = "The stream has tags that authorize viewership of the stream. Please purchase tickets from the users shop to watch";
                                prompt.tagsList = "".concat(authRequirement.tags.map(function(m) {
                                    return m;
                                }), " ").concat(authRequirement.dates.map(function(m) {
                                    return m;
                                }));
                            }
                        }
                        setStreamLeadPrompt(prompt);
                    }
                }
            }
        });
    }
    _react["default"].useEffect(function() {
        var fn = /*#__PURE__*/ function() {
            var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                var data;
                return _regeneratorRuntime().wrap(function _callee$(_context) {
                    while(1)switch(_context.prev = _context.next){
                        case 0:
                            if (fetchBusy) {
                                _context.next = 9;
                                break;
                            }
                            if (!(props.watchData && props.watchData.id)) {
                                _context.next = 9;
                                break;
                            }
                            if (!(!relevantTicket.stream || relevantTicket.stream && relevantTicket.stream !== props.watchData.id)) {
                                _context.next = 9;
                                break;
                            }
                            setFetchBusy(true);
                            // Make request for relevant ticket of all users purchases for this stream to get auth
                            _context.next = 6;
                            return (0, _streaming.doFetchAuthForStream)(props.apiUrl, props.domainKey, props.watchData.id, _onboarding.checkSignedIn);
                        case 6:
                            data = _context.sent;
                            console.log("do fetch auth", data);
                            if (data) {
                                setRelevantTicket({
                                    stream: props.watchData.id,
                                    allowed: data.allowed ? data.allowed : false,
                                    meta: data.meta
                                });
                            }
                        case 9:
                        case "end":
                            return _context.stop();
                    }
                }, _callee);
            }));
            return function fn() {
                return _ref.apply(this, arguments);
            };
        }();
        fn();
    }, [
        props.watchData,
        relevantTicket,
        fetchBusy
    ]);
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            setComponentDidMount(new Date().getTime());
            var id = (0, _uuid.v4)();
            setComponentId(id);
            setTimeout(function() {
                props._LocalEventEmitter.dispatch(id, {
                    dispatch: "updateAuth"
                });
            }, checkAuthThreshold);
            var options = {};
            if (props.cdn && props.watchData) {
                initializePlayer(options);
            }
        }
    }, [
        componentDidMount,
        videoPlayer.current,
        intent,
        props.cdn,
        props.watchData
    ]);
    _react["default"].useEffect(function() {
        if (props.cdn && props.watchData) {
            console.log(props);
            var options = {};
            initializePlayer(options);
        }
    }, [
        videoPlayer.current,
        intent,
        props.cdn,
        props.watchData
    ]);
    var initializePlayer = function initializePlayer(options) {
        if (!videoPlayer.current) {
            var players = _video["default"].players;
            if (players && Object.keys(players).length) {
                if (players["my-player"]) {
                    players["my-player"].dispose();
                }
            }
            videoPlayer.current = (0, _video["default"])("my-player", options, /*#__PURE__*/ function() {
                var _onPlayerReady = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2() {
                    var src, temp;
                    return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                        while(1)switch(_context2.prev = _context2.next){
                            case 0:
                                _video["default"].log("Your player is ready!");
                                // In this context, `this` is the player that was created by Video.js.
                                console.log(intent, props);
                                if (intent.trying === "play_video" && props.watchData) {
                                    if (props.watchData.__typename == "Live") {
                                        if (props.watchData.id && props.cdn && props.cdn.live) {
                                            // const src = `${props.cdn.live}/${props.dborigin}_live${props.dev ? '_dev' : ''}${props.devLocal ? '_local' : ''}/${props.watchData.id}/index.m3u8`
                                            if (props.watchData.meta && props.watchData.meta.channel && props.watchData.meta.channel.playbackUrl) {
                                                temp = _objectSpread({}, intent);
                                                src = props.watchData.meta.channel.playbackUrl;
                                                temp.src = src;
                                                setIntent(temp);
                                            }
                                        }
                                    }
                                }
                                this.on("error", function(e) {
                                    console.log(e);
                                });
                                // How about an event listener?
                                this.on("ended", function() {
                                    _video["default"].log("Awww...over so soon?!");
                                    this.dispose();
                                });
                                if (intent.src) {
                                    (0, _utility.ensureAutoPlay)(this.play(), this);
                                }
                            case 6:
                            case "end":
                                return _context2.stop();
                        }
                    }, _callee2, this);
                }));
                function onPlayerReady() {
                    return _onPlayerReady.apply(this, arguments);
                }
                return onPlayerReady;
            }());
        }
    };
    var resetAuthPrompt = function resetAuthPrompt() {
        if (streamLeadPrompt && streamLeadPrompt.type && streamLeadPrompt.type === "prompt") {
            setStreamLeadPrompt({});
        }
    };
    var checkAuthorization = function checkAuthorization(video) {
        if (video && video.meta && video.meta.streamSettings) {
            var settings = video.meta.streamSettings;
            console.log("Settings", settings);
            if (settings["private"]) {
                // Stream is private. Check for auth. Private requires login
                if (props._loggedIn && props._loggedIn.identifier && video.author == props._loggedIn.identifier) {
                    resetAuthPrompt();
                    return true;
                } else if (relevantTicket && relevantTicket.allowed) {
                    console.log("relevant ticket", relevantTicket);
                    resetAuthPrompt();
                    return true;
                } else {
                    return false;
                }
            }
        }
        resetAuthPrompt();
        return true;
    };
    _react["default"].useEffect(function() {
        if (props.watchData && props.watchData.__typename == "Live" && props.watchData.id && videoPlayer.current && videoPlayer.current.paused()) {
            // const src = `${props.cdn.live}/${props.dborigin}_live${props.dev ? '_dev' : ''}${props.devLocal ? '_local' : ''}/${props.watchData.id}/index.m3u8`
            console.log("source", props.watchData);
            var src;
            if (props.watchData.meta && props.watchData.meta.channel && props.watchData.meta.channel.playbackUrl) {
                if (intent.src !== props.watchData.meta.channel.playbackUrl) {
                    var temp = _objectSpread({}, intent);
                    src = props.watchData.meta.channel.playbackUrl;
                    temp.src = src;
                    setIntent(temp);
                    (0, _utility.ensureAutoPlay)(videoPlayer.current.play(), videoPlayer.current);
                }
            }
        }
    }, [
        props.watchData,
        videoPlayer.current,
        intent
    ]);
    _react["default"].useEffect(function() {
        if (props.watchData) {
            var auth = checkAuthorization(props.watchData);
            if (props.watchData.meta && props.watchData.meta.streamSettings) {
                setAuthRequirement(props.watchData.meta.streamSettings);
            }
            if (authorized !== auth && props.watchData && props.watchData.meta && props.watchData.meta.channel && props.watchData.meta.channel.playbackUrl && intent && intent.src === props.watchData.meta.channel.playbackUrl) {
                setAuthorized(auth);
                if (auth) {
                    videoPlayer.current.src({
                        src: intent.src,
                        type: "application/x-mpegURL"
                    });
                }
            }
        }
    }, [
        intent,
        authorized,
        props.watchData,
        videoPlayer.current,
        relevantTicket
    ]);
    // Check if watching user is owner -> give admin access
    // Smoothly display livestream
    // Play livestream without audio if no interaction/no audio access
    // Play livestream with audio if available
    // Title, Description, Tags, Author, Author Icon, Click to go to auhor profile
    // TODO:
    // Subscribe, Purchase Ticket, Donate
    console.log(props);
    var menuHeight = props.menuConfig && props.menuConfig.height ? props.menuConfig.height + 2 + "px" : "35px"; // Handles user menuConfig height for height of video page
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_WatchPageModule["default"].videoQuadrant),
        style: {
            height: "calc(100vh - ".concat(menuHeight, ")")
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_WatchPageModule["default"].streamLeadPrompt, " ").concat(!(0, _util.isObjectEmpty)(streamLeadPrompt) ? _WatchPageModule["default"].streamLeadPrompt_Visible : ""),
        ref: authContainer
    }, streamLeadPrompt ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.lead ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.lead) : null, streamLeadPrompt.description ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.description) : null, streamLeadPrompt.password ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.password) : null, streamLeadPrompt.tags ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.tags) : null, streamLeadPrompt.tagsList ? /*#__PURE__*/ _react["default"].createElement("div", null, streamLeadPrompt.tagsList) : null) : null), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_WatchPageModule["default"].videoContainer)
    }, /*#__PURE__*/ _react["default"].createElement("video", {
        id: "my-player",
        "class": "".concat(_WatchPageModule["default"].videoPlayer, " video-js"),
        controls: true,
        preload: "auto",
        poster: currentPoster
    }, /*#__PURE__*/ _react["default"].createElement("p", {
        "class": "vjs-no-js"
    }, "To view this video please enable JavaScript, and consider upgrading to a web browser that", /*#__PURE__*/ _react["default"].createElement("a", {
        href: "https://videojs.com/html5-video-support/",
        target: "_blank"
    }, "supports HTML5 video"))))), /*#__PURE__*/ _react["default"].createElement("div", null));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 5956:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "WatchPage", ({
    enumerable: true,
    get: function get() {
        return _WatchPage["default"];
    }
}));
var _WatchPage = _interopRequireDefault(__webpack_require__(1713));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 4108:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
__webpack_unused_export__ = ({
    value: true
});
__webpack_unused_export__ = void 0;
exports.iR = generateComponent;
exports.mS = exports.Fx = __webpack_unused_export__ = exports.oC = exports.nG = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _app = _interopRequireWildcard(__webpack_require__(139));
var _watch = __webpack_require__(5956);
var _index = __webpack_require__(9358);
var _index2 = __webpack_require__(6437);
var _receipt = __webpack_require__(190);
var _index3 = __webpack_require__(5847);
var _manager = __webpack_require__(8958);
var _feature = __webpack_require__(7173);
var _wideFeature = __webpack_require__(9101);
var _index4 = __webpack_require__(6033);
var _indexing = __webpack_require__(6256);
var _router = __webpack_require__(1853);
var _fetch = __webpack_require__(23);
var _onboarding = __webpack_require__(4137);
var _util = __webpack_require__(8131);
var _customModules = _interopRequireDefault(__webpack_require__(2643));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interopRequireWildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
        return {
            "default": obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj["default"] = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _toConsumableArray(arr) {
    return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread();
}
function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _iterableToArray(iter) {
    if (typeof Symbol !== "undefined" && iter[Symbol.iterator] != null || iter["@@iterator"] != null) return Array.from(iter);
}
function _arrayWithoutHoles(arr) {
    if (Array.isArray(arr)) return _arrayLikeToArray(arr);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
var resolveComponent = function resolveComponent(json) {
    if (json.type) {
        switch(json.type){
            case "WatchPage":
                return /*#__PURE__*/ _react["default"].createElement(_watch.WatchPage, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "SignIn":
                return /*#__PURE__*/ _react["default"].createElement(_index.SignIn, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "SignInPage":
                return /*#__PURE__*/ _react["default"].createElement(_index.SignInPage, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "ProfilePage":
                return /*#__PURE__*/ _react["default"].createElement(_index2.ProfilePage, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "ReceiptPage":
                return /*#__PURE__*/ _react["default"].createElement(_receipt.ReceiptPage, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "CreditCard":
                return /*#__PURE__*/ _react["default"].createElement(_index3.CreditCard, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "Streaming_Manager":
                return /*#__PURE__*/ _react["default"].createElement(_manager.Manager, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "Onboarding_SignIn_Username":
                return /*#__PURE__*/ _react["default"].createElement(_index.Username, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "Video_Test_Live_Player":
                return /*#__PURE__*/ _react["default"].createElement(_index4.LivePlayer, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "Feature":
                return /*#__PURE__*/ _react["default"].createElement(_feature.Feature, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "WideFeature":
                return /*#__PURE__*/ _react["default"].createElement(_wideFeature.WideFeature, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "SliderBasic":
                return /*#__PURE__*/ _react["default"].createElement(_indexing.SliderBasic, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "FetchHandler":
                return /*#__PURE__*/ _react["default"].createElement(_fetch.FetchHandler, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
            case "CustomModule":
                if (json.props && json.props.customModule) {
                    var UseModule = _customModules["default"][json.props.customModule];
                    if (UseModule) {
                        return /*#__PURE__*/ _react["default"].createElement(UseModule, json.props, json.children && json.children.map ? json.children.map(generateComponent) : null);
                    }
                }
                return null;
            default:
                return null;
        }
    }
    return null;
};
__webpack_unused_export__ = resolveComponent;
var resolvePage = function resolvePage(def, path) {
    if (def && def.temporaryComponents && def.temporaryComponents.pages) {
        var match = def.temporaryComponents.pages.find(function(pg) {
            var route = pg.url;
            var matchWithParam = new RegExp("^\\".concat(route, "(?:\\?.*)?$"));
            if (path && path == pg.url || matchWithParam.test(path)) {
                return true;
            } else if (global && global.location && global.location.pathname && pg.url === global.location.pathname || global && global.location && global.location.pathname && matchWithParam.test(global.location.pathname)) {
                return true;
            }
            return false;
        });
        return match;
    }
    return null;
};
exports.mS = resolvePage;
function generateComponent(json) {
    if (json) {
        var type = json.type, props = json.props, children = json.children;
        // If the type is a string, create a React element
        if (typeof type === "string") {
            // Check if the type is the custom component
            var matchComponent = resolveComponent(json);
            if (matchComponent) {
                return matchComponent;
            }
            if (children && children.map) {
                var childElements = children && children.map(generateComponent);
                return /*#__PURE__*/ _react["default"].createElement.apply(_react["default"], [
                    type,
                    props
                ].concat(_toConsumableArray(childElements)));
            }
        }
        if (type) {
            return type;
        }
    }
    // If the type is a function/component, directly return it
    return json;
}
var resolveDefaults = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(url, props, variables, query, asPath, setFetching, force) {
        var doPreReq, newProps, queryParams, body, user, defaults;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    setFetching(true);
                    doPreReq = false;
                    newProps = {};
                    queryParams = {};
                    if (query && !(0, _util.isObjectEmpty)(query)) {
                        queryParams = query;
                    } else {
                        queryParams.u = (0, _onboarding.checkSignedIn)() && (0, _onboarding.checkSignedIn)().username ? (0, _onboarding.checkSignedIn)().username : null;
                    }
                    body = {
                        url: asPath,
                        params: queryParams
                    };
                    if (url === "/p" && (!props.profileData || force)) {
                        doPreReq = true;
                        body.profileReq = true;
                        body.shopProfileReq = true;
                    } else if (url == "/w" && (!props.watchData || force)) {
                        doPreReq = true;
                        body.watchReq = true;
                        body.shopProfileReq = true;
                    } else if (url == "/r") {
                        doPreReq = true;
                        body.profileReq = true;
                        body.receiptReq = true;
                        body.domainKey = variables.domainKey;
                        user = (0, _onboarding.checkSignedIn)();
                        if (user && user.identifier && user.hash) {
                            body.identifier = user.identifier;
                            body.hash = user.hash;
                        }
                    }
                    if (!(doPreReq === true)) {
                        _context.next = 12;
                        break;
                    }
                    _context.next = 10;
                    return (0, _fetch.fetchPost)(variables.apiUrl + "/m/pagedefaults", null, null, body);
                case 10:
                    defaults = _context.sent;
                    if (defaults && defaults.data) {
                        newProps = Object.keys(defaults.data).reduce(function(acc, key) {
                            acc[key] = defaults.data[key];
                            return acc;
                        }, newProps);
                    }
                case 12:
                    newProps._loggedIn = (0, _onboarding.checkSignedIn)();
                    return _context.abrupt("return", newProps);
                case 14:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function resolveDefaults(_x, _x2, _x3, _x4, _x5, _x6, _x7) {
        return _ref.apply(this, arguments);
    };
}();
exports.Fx = resolveDefaults;
var handlePropsPriority = function handlePropsPriority(mergeProps, props) {
    var temp = (0, _util.isObjectEmpty)(mergeProps) ? props : mergeProps;
    for(var key in temp){
        if (key.startsWith("_")) {
            var desc = Object.getOwnPropertyDescriptor(temp, key);
            if (desc && desc.writable) {
                temp[key] = props[key];
            }
        }
    }
    return temp;
};
exports.oC = handlePropsPriority;
var basicError = {
    error: "failed",
    code: 404
};
__webpack_unused_export__ = basicError;
var getServerSidePropsDefault = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(context, pageDefaults) {
        var paramOveride, data, variables, config, resolvedPage, body, doPreReq, i, defaults, _args2 = arguments;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    paramOveride = _args2.length > 2 && _args2[2] !== undefined ? _args2[2] : {};
                    data = {
                        props: {
                            data: {},
                            profileData: null,
                            params: {},
                            resolvedDefinition: null,
                            path: null,
                            log: "",
                            error: ""
                        }
                    };
                    variables = (0, _app.resolveVariables)();
                    config = (0, _app["default"])(variables);
                    resolvedPage = resolvePage(config, context.req.url);
                    data.props.path = context.req.url;
                    body = {
                        url: context.req.url,
                        params: context.query,
                        domainKey: variables.domainKey
                    };
                    doPreReq = false;
                    if (resolvedPage && resolvedPage.url === "/p") {
                        doPreReq = true;
                        body.profileReq = true;
                        body.shopProfileReq = true;
                    } else if (resolvedPage && resolvedPage.url === "/w") {
                        doPreReq = true;
                        body.watchReq = true;
                        body.shopProfileReq = true;
                    }
                    if (resolvedPage && resolvePage.data) {
                        data.props.resolvedDefinition = resolvedPage.data; // Access the `data` property
                    }
                    if (pageDefaults) {
                        for(i = 0; i < pageDefaults.length; i++){
                            doPreReq = true;
                            body[pageDefaults[i] + "Req"] = true;
                        }
                    }
                    Object.entries(paramOveride).map(function(p) {
                        body.params[p[0]] = p[1];
                    });
                    if (!doPreReq) {
                        _context2.next = 17;
                        break;
                    }
                    _context2.next = 15;
                    return (0, _fetch.fetchPost)(variables.apiUrl + "/m/pagedefaults", null, null, body);
                case 15:
                    defaults = _context2.sent;
                    if (defaults && defaults.data) {
                        data.props = Object.keys(defaults.data).reduce(function(acc, key) {
                            acc[key] = defaults.data[key];
                            return acc;
                        }, data.props);
                    }
                case 17:
                    if (context && context.query) {
                        data.props.params = context.query;
                    }
                    if (doPreReq) {
                        if (!defaults || defaults && defaults.status === "failed") {
                            data.props.error = basicError;
                        }
                    }
                    return _context2.abrupt("return", data);
                case 20:
                case "end":
                    return _context2.stop();
            }
        }, _callee2);
    }));
    return function getServerSidePropsDefault(_x8, _x9) {
        return _ref2.apply(this, arguments);
    };
}();
exports.nG = getServerSidePropsDefault;


/***/ }),

/***/ 3513:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _fetch = __webpack_require__(6699);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(false), _React$useState2 = _slicedToArray(_React$useState, 2), fetchBusy = _React$useState2[0], setFetchBusy = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), didFetch = _React$useState4[0], setDidFetch = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(-1), _React$useState6 = _slicedToArray(_React$useState5, 2), lastFetch = _React$useState6[0], setLastFetch = _React$useState6[1];
    _react["default"].useEffect(function() {
        var f = /*#__PURE__*/ function() {
            var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee() {
                var fetchBody, res;
                return _regeneratorRuntime().wrap(function _callee$(_context) {
                    while(1)switch(_context.prev = _context.next){
                        case 0:
                            _context.prev = 0;
                            if (!props.apiUrl) {
                                _context.next = 25;
                                break;
                            }
                            console.log(props, didFetch);
                            if (!(!fetchBusy && props.handlerName && props.handlerArgs && props.domainKey && props.apiUrl && !didFetch)) {
                                _context.next = 25;
                                break;
                            }
                            setFetchBusy(true);
                            setTimeout(function() {
                                setFetchBusy(false);
                            }, 15000);
                            setLastFetch(new Date().getTime());
                            setDidFetch(true);
                            fetchBody = {
                                domainKey: props.domainKey,
                                handlerName: props.handlerName,
                                handlerArgs: props.handlerArgs
                            };
                            _context.next = 11;
                            return (0, _fetch.fetchPost)(props.apiUrl + "/m/fetchhandler", null, null, fetchBody);
                        case 11:
                            res = _context.sent;
                            console.log("Handler", res);
                            if (res) {
                                _context.next = 18;
                                break;
                            }
                            setFetchBusy(false);
                            return _context.abrupt("return", false);
                        case 18:
                            if (!res.hasOwnProperty("status")) {
                                _context.next = 25;
                                break;
                            }
                            if (!(res.status == "failed")) {
                                _context.next = 24;
                                break;
                            }
                            setFetchBusy(false);
                            return _context.abrupt("return", false);
                        case 24:
                            if (res.status == "success") {
                                setFetchBusy(false);
                                if (props.receiveData) {
                                    props.receiveData(res);
                                }
                            }
                        case 25:
                            _context.next = 31;
                            break;
                        case 27:
                            _context.prev = 27;
                            _context.t0 = _context["catch"](0);
                            console.log(_context.t0);
                            setFetchBusy(false);
                        case 31:
                        case "end":
                            return _context.stop();
                    }
                }, _callee, null, [
                    [
                        0,
                        27
                    ]
                ]);
            }));
            return function f() {
                return _ref.apply(this, arguments);
            };
        }();
        f();
    }, [
        didFetch,
        fetchBusy,
        props.handlerName,
        props.handlerArgs,
        props.domainKey
    ]);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(props.className)
    });
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 23:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "FetchHandler", ({
    enumerable: true,
    get: function get() {
        return _FetchHandler["default"];
    }
}));
Object.defineProperty(exports, "fetchGet", ({
    enumerable: true,
    get: function get() {
        return _fetch.fetchGet;
    }
}));
Object.defineProperty(exports, "fetchPost", ({
    enumerable: true,
    get: function get() {
        return _fetch.fetchPost;
    }
}));
Object.defineProperty(exports, "retrieveUrlParams", ({
    enumerable: true,
    get: function get() {
        return _fetch.retrieveUrlParams;
    }
}));
var _fetch = __webpack_require__(6699);
var _FetchHandler = _interopRequireDefault(__webpack_require__(3513));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 4137:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "attemptThirdPartySignIn", ({
    enumerable: true,
    get: function get() {
        return _SignIn.attemptThirdPartySignIn;
    }
}));
Object.defineProperty(exports, "checkSignedIn", ({
    enumerable: true,
    get: function get() {
        return _SignIn.checkSignedIn;
    }
}));
Object.defineProperty(exports, "checkSignedInAndPrompt", ({
    enumerable: true,
    get: function get() {
        return _SignIn.checkSignedInAndPrompt;
    }
}));
Object.defineProperty(exports, "grabUsername", ({
    enumerable: true,
    get: function get() {
        return _SignIn.grabUsername;
    }
}));
Object.defineProperty(exports, "logout", ({
    enumerable: true,
    get: function get() {
        return _SignIn.logout;
    }
}));
Object.defineProperty(exports, "updateLocalLoginSession", ({
    enumerable: true,
    get: function get() {
        return _SignIn.updateLocalLoginSession;
    }
}));
var _SignIn = __webpack_require__(5203);


/***/ }),

/***/ 3183:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "fetchStripeSecret", ({
    enumerable: true,
    get: function get() {
        return _payment.fetchStripeSecret;
    }
}));
Object.defineProperty(exports, "getStripeSecretData", ({
    enumerable: true,
    get: function get() {
        return _payment.getStripeSecretData;
    }
}));
Object.defineProperty(exports, "saveCreditCardInfo", ({
    enumerable: true,
    get: function get() {
        return _payment.saveCreditCardInfo;
    }
}));
Object.defineProperty(exports, "setStripeSecretData", ({
    enumerable: true,
    get: function get() {
        return _payment.setStripeSecretData;
    }
}));
var _payment = __webpack_require__(1243);


/***/ }),

/***/ 1243:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.setStripeSecretData = exports.saveCreditCardInfo = exports.getStripeSecretData = exports.fetchStripeSecret = void 0;
var _fetch = __webpack_require__(6699);
var _SignIn = __webpack_require__(5203);
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
// Will fetch stripe secret using id or username
var fetchStripeSecret = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(uri, domainKey, user) {
        var _fetchBody, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    if (!(user && user.identifier && user.hash && domainKey)) {
                        _context.next = 6;
                        break;
                    }
                    fetchBody = (_fetchBody = {
                        domainKey: domainKey
                    }, _defineProperty(_fetchBody, "domainKey", domainKey), _defineProperty(_fetchBody, "hash", user.hash), _defineProperty(_fetchBody, "identifier", user.identifier), _fetchBody);
                    _context.next = 4;
                    return (0, _fetch.fetchPost)(uri + "/m/getclientsecret", null, null, fetchBody);
                case 4:
                    res = _context.sent;
                    return _context.abrupt("return", res);
                case 6:
                    return _context.abrupt("return", false);
                case 7:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function fetchStripeSecret(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();
exports.fetchStripeSecret = fetchStripeSecret;
var getStripeSecretData = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(uri, domainKey, data) {
        var secret;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    _context2.next = 2;
                    return fetchStripeSecret(uri, domainKey, data);
                case 2:
                    secret = _context2.sent;
                    if (!secret) {
                        _context2.next = 5;
                        break;
                    }
                    return _context2.abrupt("return", secret);
                case 5:
                    return _context2.abrupt("return", false);
                case 6:
                case "end":
                    return _context2.stop();
            }
        }, _callee2);
    }));
    return function getStripeSecretData(_x4, _x5, _x6) {
        return _ref2.apply(this, arguments);
    };
}();
exports.getStripeSecretData = getStripeSecretData;
var setStripeSecretData = /*#__PURE__*/ function() {
    var _ref3 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee3(uri, domainKey, data, f) {
        var secret;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
            while(1)switch(_context3.prev = _context3.next){
                case 0:
                    _context3.next = 2;
                    return getStripeSecretData(uri, domainKey, data);
                case 2:
                    secret = _context3.sent;
                    if (secret) {
                        f(secret);
                    }
                case 4:
                case "end":
                    return _context3.stop();
            }
        }, _callee3);
    }));
    return function setStripeSecretData(_x7, _x8, _x9, _x10) {
        return _ref3.apply(this, arguments);
    };
}();
/**
* Save single Credit card information to backend
* @param {*} data 
* @returns 
*/ exports.setStripeSecretData = setStripeSecretData;
var saveCreditCardInfo = /*#__PURE__*/ function() {
    var _ref4 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee4(uri, domainKey, data, checkSignedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
            while(1)switch(_context4.prev = _context4.next){
                case 0:
                    user = checkSignedIn();
                    if (!user) {
                        _context4.next = 30;
                        break;
                    }
                    if (!(user.identifier && user.hash)) {
                        _context4.next = 27;
                        break;
                    }
                    fetchBody = {
                        cus_id: data.stripeSecret.user,
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    if (data.result && data.result.setupIntent && data.result.setupIntent.payment_method) {
                        fetchBody.payment_id = data.result.setupIntent.payment_method;
                    }
                    _context4.next = 7;
                    return (0, _fetch.fetchPost)(uri + "/m/saveccinfo", null, null, fetchBody);
                case 7:
                    res = _context4.sent;
                    if (res) {
                        _context4.next = 12;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 12:
                    if (!res.hasOwnProperty("status")) {
                        _context4.next = 24;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context4.next = 18;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context4.abrupt("return", "disauthenticated");
                case 18:
                    if (!(res.status == "failed")) {
                        _context4.next = 22;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 22:
                    if (!(res.status == "success")) {
                        _context4.next = 24;
                        break;
                    }
                    return _context4.abrupt("return", res);
                case 24:
                    return _context4.abrupt("return", false);
                case 27:
                    return _context4.abrupt("return", false);
                case 28:
                    _context4.next = 31;
                    break;
                case 30:
                    return _context4.abrupt("return", false);
                case 31:
                case "end":
                    return _context4.stop();
            }
        }, _callee4);
    }));
    return function saveCreditCardInfo(_x11, _x12, _x13, _x14) {
        return _ref4.apply(this, arguments);
    };
}();
exports.saveCreditCardInfo = saveCreditCardInfo;


/***/ }),

/***/ 8838:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "fetchSearchData", ({
    enumerable: true,
    get: function get() {
        return _search.fetchSearchData;
    }
}));
var _search = __webpack_require__(7346);


/***/ }),

/***/ 7346:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.fetchSearchData = void 0;
var _fetch = __webpack_require__(23);
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
/**
* Begin single live stream
* @param {string} uri
* @param {string} domainKey
* @param {*} data
* @param {function} checkSignedIn
* @returns 
*/ var fetchSearchData = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(apiUrl, dataFetch, args) {
        var body, i, defaults;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    body = args;
                    for(i = 0; i < dataFetch.length; i++){
                        body[dataFetch[i] + "Req"] = true;
                    }
                    _context.next = 4;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/pagedefaults", null, null, body);
                case 4:
                    defaults = _context.sent;
                    console.log("Defaults", defaults);
                    return _context.abrupt("return", defaults);
                case 7:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function fetchSearchData(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();
exports.fetchSearchData = fetchSearchData;


/***/ }),

/***/ 8308:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "beginStream", ({
    enumerable: true,
    get: function get() {
        return _stream.beginStream;
    }
}));
Object.defineProperty(exports, "doFetchAuthForStream", ({
    enumerable: true,
    get: function get() {
        return _stream.doFetchAuthForStream;
    }
}));
Object.defineProperty(exports, "endStream", ({
    enumerable: true,
    get: function get() {
        return _stream.endStream;
    }
}));
Object.defineProperty(exports, "updateStreamConfigRequest", ({
    enumerable: true,
    get: function get() {
        return _stream.updateStreamConfigRequest;
    }
}));
var _stream = __webpack_require__(410);


/***/ }),

/***/ 410:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.updateStreamConfigRequest = exports.endStream = exports.doFetchAuthForStream = exports.beginStream = void 0;
var _fetch = __webpack_require__(6699);
var _SignIn = __webpack_require__(5203);
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
/**
* Begin single live stream
* @param {string} uri
* @param {string} domainKey
* @param {*} data
* @param {function} checkSignedIn
* @returns 
*/ var beginStream = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(apiUrl, domainKey, data, checkSignedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    user = checkSignedIn();
                    if (!user) {
                        _context.next = 29;
                        break;
                    }
                    if (!(user.identifier && user.hash)) {
                        _context.next = 26;
                        break;
                    }
                    fetchBody = {
                        cus_id: data.stripeSecret.user,
                        dontForce: data.dontForce,
                        streamSettings: data.streamSettings,
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    _context.next = 6;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/beginstream", null, null, fetchBody);
                case 6:
                    res = _context.sent;
                    if (res) {
                        _context.next = 11;
                        break;
                    }
                    return _context.abrupt("return", false);
                case 11:
                    if (!res.hasOwnProperty("status")) {
                        _context.next = 23;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context.next = 17;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context.abrupt("return", "disauthenticated");
                case 17:
                    if (!(res.status == "failed")) {
                        _context.next = 21;
                        break;
                    }
                    return _context.abrupt("return", false);
                case 21:
                    if (!(res.status == "success")) {
                        _context.next = 23;
                        break;
                    }
                    return _context.abrupt("return", res);
                case 23:
                    return _context.abrupt("return", false);
                case 26:
                    return _context.abrupt("return", false);
                case 27:
                    _context.next = 30;
                    break;
                case 29:
                    return _context.abrupt("return", false);
                case 30:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function beginStream(_x, _x2, _x3, _x4) {
        return _ref.apply(this, arguments);
    };
}();
/**
* Begin single live stream
* @param {string} uri
* @param {string} domainKey
* @param {*} data
* @param {function} checkSignedIn
* @returns 
*/ exports.beginStream = beginStream;
var endStream = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(apiUrl, domainKey, data, checkSignedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    user = checkSignedIn();
                    if (!user) {
                        _context2.next = 29;
                        break;
                    }
                    if (!(user.identifier && user.hash)) {
                        _context2.next = 26;
                        break;
                    }
                    fetchBody = {
                        stream: data.stream,
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    _context2.next = 6;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/endstream", null, null, fetchBody);
                case 6:
                    res = _context2.sent;
                    if (res) {
                        _context2.next = 11;
                        break;
                    }
                    return _context2.abrupt("return", false);
                case 11:
                    if (!res.hasOwnProperty("status")) {
                        _context2.next = 23;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context2.next = 17;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context2.abrupt("return", "disauthenticated");
                case 17:
                    if (!(res.status == "failed")) {
                        _context2.next = 21;
                        break;
                    }
                    return _context2.abrupt("return", false);
                case 21:
                    if (!(res.status == "success")) {
                        _context2.next = 23;
                        break;
                    }
                    return _context2.abrupt("return", res);
                case 23:
                    return _context2.abrupt("return", false);
                case 26:
                    return _context2.abrupt("return", false);
                case 27:
                    _context2.next = 30;
                    break;
                case 29:
                    return _context2.abrupt("return", false);
                case 30:
                case "end":
                    return _context2.stop();
            }
        }, _callee2);
    }));
    return function endStream(_x5, _x6, _x7, _x8) {
        return _ref2.apply(this, arguments);
    };
}();
/**
* Check auth for stream
* @param {string} uri
* @param {string} domainKey
* @param {*} stream
* @param {function} checkSignedIn
* @returns 
*/ exports.endStream = endStream;
var doFetchAuthForStream = /*#__PURE__*/ function() {
    var _ref3 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee3(apiUrl, domainKey, stream, checkSignedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
            while(1)switch(_context3.prev = _context3.next){
                case 0:
                    user = checkSignedIn();
                    if (!user) {
                        _context3.next = 29;
                        break;
                    }
                    if (!(user.identifier && user.hash)) {
                        _context3.next = 26;
                        break;
                    }
                    fetchBody = {
                        stream: stream,
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    _context3.next = 6;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/getauthforstream", null, null, fetchBody);
                case 6:
                    res = _context3.sent;
                    if (res) {
                        _context3.next = 11;
                        break;
                    }
                    return _context3.abrupt("return", false);
                case 11:
                    if (!res.hasOwnProperty("status")) {
                        _context3.next = 23;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context3.next = 17;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context3.abrupt("return", "disauthenticated");
                case 17:
                    if (!(res.status == "failed")) {
                        _context3.next = 21;
                        break;
                    }
                    return _context3.abrupt("return", false);
                case 21:
                    if (!(res.status == "success")) {
                        _context3.next = 23;
                        break;
                    }
                    return _context3.abrupt("return", res);
                case 23:
                    return _context3.abrupt("return", false);
                case 26:
                    return _context3.abrupt("return", false);
                case 27:
                    _context3.next = 30;
                    break;
                case 29:
                    return _context3.abrupt("return", false);
                case 30:
                case "end":
                    return _context3.stop();
            }
        }, _callee3);
    }));
    return function doFetchAuthForStream(_x9, _x10, _x11, _x12) {
        return _ref3.apply(this, arguments);
    };
}();
/**
* Begin single live stream
* @param {string} uri
* @param {string} domainKey
* @param {*} data
* @param {function} checkSignedIn
* @returns 
*/ exports.doFetchAuthForStream = doFetchAuthForStream;
var updateStreamConfigRequest = /*#__PURE__*/ function() {
    var _ref4 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee4(apiUrl, domainKey, data, checkSignedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
            while(1)switch(_context4.prev = _context4.next){
                case 0:
                    user = checkSignedIn();
                    if (!user) {
                        _context4.next = 30;
                        break;
                    }
                    if (!(user.identifier && user.hash)) {
                        _context4.next = 27;
                        break;
                    }
                    fetchBody = {
                        stream: data.stream,
                        streamData: data.streamData,
                        streamSettings: data.streamSettings,
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    console.log(fetchBody);
                    _context4.next = 7;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/updatestreamconfig", null, null, fetchBody);
                case 7:
                    res = _context4.sent;
                    if (res) {
                        _context4.next = 12;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 12:
                    if (!res.hasOwnProperty("status")) {
                        _context4.next = 24;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context4.next = 18;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context4.abrupt("return", "disauthenticated");
                case 18:
                    if (!(res.status == "failed")) {
                        _context4.next = 22;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 22:
                    if (!(res.status == "success")) {
                        _context4.next = 24;
                        break;
                    }
                    return _context4.abrupt("return", res);
                case 24:
                    return _context4.abrupt("return", false);
                case 27:
                    return _context4.abrupt("return", false);
                case 28:
                    _context4.next = 31;
                    break;
                case 30:
                    return _context4.abrupt("return", false);
                case 31:
                case "end":
                    return _context4.stop();
            }
        }, _callee4);
    }));
    return function updateStreamConfigRequest(_x13, _x14, _x15, _x16) {
        return _ref4.apply(this, arguments);
    };
}();
exports.updateStreamConfigRequest = updateStreamConfigRequest;


/***/ }),

/***/ 5349:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.fireGlobalEvent = void 0;
var fireGlobalEvent = function fireGlobalEvent(e, emitter) {
    if (e && emitter) {
        var _e$currentTarget;
        var action = e === null || e === void 0 ? void 0 : (_e$currentTarget = e.currentTarget) === null || _e$currentTarget === void 0 ? void 0 : _e$currentTarget.getAttribute("action");
        if (action) {
            if (action === "buy") {
                var _e$currentTarget2, _e$currentTarget3, _e$currentTarget4;
                var item = e === null || e === void 0 ? void 0 : (_e$currentTarget2 = e.currentTarget) === null || _e$currentTarget2 === void 0 ? void 0 : _e$currentTarget2.getAttribute("item");
                var style = e === null || e === void 0 ? void 0 : (_e$currentTarget3 = e.currentTarget) === null || _e$currentTarget3 === void 0 ? void 0 : _e$currentTarget3.getAttribute("selectedstyle");
                var option = e === null || e === void 0 ? void 0 : (_e$currentTarget4 = e.currentTarget) === null || _e$currentTarget4 === void 0 ? void 0 : _e$currentTarget4.getAttribute("currentoption");
                emitter.dispatch("global_event", {
                    action: action,
                    e: e,
                    item: item,
                    style: style,
                    option: option
                });
            } else if (action === "add_to_cart") {
                var _e$currentTarget5, _e$currentTarget6, _e$currentTarget7;
                var _item = e === null || e === void 0 ? void 0 : (_e$currentTarget5 = e.currentTarget) === null || _e$currentTarget5 === void 0 ? void 0 : _e$currentTarget5.getAttribute("item");
                var _style = e === null || e === void 0 ? void 0 : (_e$currentTarget6 = e.currentTarget) === null || _e$currentTarget6 === void 0 ? void 0 : _e$currentTarget6.getAttribute("selectedstyle");
                var _option = e === null || e === void 0 ? void 0 : (_e$currentTarget7 = e.currentTarget) === null || _e$currentTarget7 === void 0 ? void 0 : _e$currentTarget7.getAttribute("currentoption");
                emitter.dispatch("global_event", {
                    action: action,
                    e: e,
                    item: _item,
                    style: _style,
                    option: _option
                });
            } else {
                emitter.dispatch("global_event", {
                    custom: true,
                    action: action,
                    e: e
                });
            }
        }
    }
};
exports.fireGlobalEvent = fireGlobalEvent;


/***/ }),

/***/ 5329:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "fireGlobalEvent", ({
    enumerable: true,
    get: function get() {
        return _event.fireGlobalEvent;
    }
}));
Object.defineProperty(exports, "normalizeText", ({
    enumerable: true,
    get: function get() {
        return _type.normalizeText;
    }
}));
var _type = __webpack_require__(1479);
var _event = __webpack_require__(5349);


/***/ }),

/***/ 1479:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.normalizeText = void 0;
var normalizeText = function normalizeText(s) {
    var doNormalize = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
    var temp = s;
    if (doNormalize) {
        if (typeof temp === "string") {
            temp = temp.replace(/:nbsp;/g, " ");
        }
    }
    return temp;
};
exports.normalizeText = normalizeText;


/***/ }),

/***/ 7154:
/***/ (() => {

"use strict";
// /** Video player VideoPlayer.js
//  @version 0.1
//  @author lovgrandma
// File is used to handle high level lifecycle of video player */
// import dynamic from 'next/dynamic';
// import encryptionSchemePolyfills from 'eme-encryption-scheme-polyfill'
// import muxjs from "mux.js"
// // mainShakaImport "shaka-player/dist/shaka-player.ui.js";
// // testShakaImport "../../../../../../../shaka/shaka-player/dist/shaka-player.ui.js";
// const mainShakaImport = 'shaka-player/dist/shaka-player.ui.js'
// const testShakaImport = '../../../../../../../shaka/shaka-player/dist/shaka-player.ui.js'
// export default class VideoPlayer {
//     constructor() {
//         if (!VideoPlayer.intance) {
//             VideoPlayer.instance = this
//         }
//         this.encryptionSchemePolyfills
//         this.shaka
//         this.player
//         this.cdn = ""
//         this.init = false
//         this.videoLoadedSuccessfully = false // Tracks success of load
//         this.supportedPlaybackType = null
//         this.iosRevertFunctionality = [ 'iphone', 'ipad', 'ipod', 'applewatch', 'iphone simulator', 'ipod simulator', 'ipad simulator' ]
//         return VideoPlayer.instance
//     }
//     async importShakaPlayer() {
//         this.shaka = (await import('shaka-player/dist/shaka-player.ui.js')).default;
//         return this.shaka
//     }
//     async initPlayer(videoComponent, conf) {
//         try {
//             if (!window.muxjs) {
//                 window.muxjs = muxjs
//             }
//             let promise = new Promise(async (resolve, reject) => {
//                 try {
//                     let shakaContainer = await this.installPolyfills()
//                     this.init = true;
//                     if (shakaContainer.Player) {
//                         let player = await new shakaContainer.Player(videoComponent)
//                         if (conf) {
//                             player.configure(conf)
//                         }
//                         this.player = player
//                         await this.checkPlaybackSupportType()
//                         return resolve({
//                             shaka: this.shaka,
//                             player: this.player
//                         })
//                     }
//                     return ({})
//                 } catch (err) {
//                     reject(err)
//                 }
//             })
//             return await promise;
//         } catch (err) {
//             console.log(err);
//             return false;
//         }
//     }
//     checkAltDevice() {
//         try {
//             const ios = navigator && navigator.platform && navigator.platform.toLowerCase() ? navigator.platform.toLowerCase() : null
//             if (ios && this.iosRevertFunctionality.indexOf(ios) > -1) {
//                 return {
//                     alternateLoadFunctionality: 'src',
//                     ios: ios,
//                     format: 'hls'
//                 }
//             }
//             return null
//         } catch (err) {
//             return null
//         }
//     }
//     /**
//      * 
//      * @param {*} media 
//      * @param {*} cdn 
//      * @param {*} postfix 
//      * @param {Boolean} forceLoad Forces load even if video has been loaded already
//      * @param {Boolean} dontForceIfSameMedia Flag to avoid reloading if media already loaded to player
//      * @returns 
//      */
//     async loadMedia(media, cdn, postfix = "", forceLoad = false, dontForceIfSameMedia = false) {
//         try {
//             console.log("Load Media", media, cdn, this.player, this.cdn, forceLoad, this.videoLoadedSuccessfully)
//             if (!this.videoLoadedSuccessfully || forceLoad) {
//                 if (forceLoad && dontForceIfSameMedia && this.videoLoadedSuccessfully == cdn + postfix + media.hls) {
//                     return // Don't force if same media
//                 }
//                 const s = await this.checkPlaybackSupportType()
//                 if (s == "mpd") {
//                     let l = await this.player.load(cdn + postfix + media.mpd)
//                     if (l !== false) {
//                         this.videoLoadedSuccessfully = cdn + postfix + media.hls
//                     }
//                     return l
//                 } else {
//                     let l = await this.player.load(cdn + postfix + media.hls)
//                     if (l !== false) {
//                         this.videoLoadedSuccessfully = cdn + postfix + media.hls
//                     }
//                     return l
//                 }
//             }
//             return
//         } catch (err) {
//             return false
//         }
//     }
//     /**
//      * Determines whether to use Hls or Mpd
//      * @param none
//      * @return {String} "-hls.m3u8" or "-mpd.mpd"
//      */
//     async checkPlaybackSupportType() {
//         try {
//             const device = this.checkAltDevice()
//             if (device && device.format) {
//                 this.supportedPlaybackType = device.format
//                 return device.format
//             }
//             if (this.supportedPlaybackType) {
//                 return this.supportedPlaybackType
//             }
//             const support = await shaka.Player.probeSupport()
//             let type = support.manifest.mpd ? "mpd" : "hls"
//             this.supportedPlaybackType = type
//             return type
//         } catch (err) {
//             return "mpd";
//         }
//     }
//     async loadLivestreamDirect(url) {
//         let l = await this.player.load(url)
//         if (l !== false) {
//             this.videoLoadedSuccessfully = url
//         }
//     }
//     async installPolyfills() {
//         try {
//             await this.importShakaPlayer()
//             encryptionSchemePolyfills.install()
//             this.shaka.polyfill.installAll()
//             return this.shaka
//         } catch (err) {
//             return false;
//         }
//     }
//     set init(init) {
//         if (this._init != init) {
//             this._init = init
//         }
//     }
//     set supportedPlaybackType(supportedPlaybackType) {
//         if (this._supportedPlaybackType != supportedPlaybackType) {
//             this._supportedPlaybackType = supportedPlaybackType
//         }
//     }
//     get supportedPlaybackType() {
//         return this._supportedPlaybackType
//     }
//     set cdn(cdn) {
//         if (this._cdn != cdn) {
//             this._cdn = cdn
//         }
//     }
//     get cdn() {
//         return this._cdn;
//     }
//     get videoLoadedSuccessfully() {
//         return this._videoLoadedSuccessfully
//     }
//     set videoLoadedSuccessfully(videoLoadedSuccessfully) {
//         if (this._videoLoadedSuccessfully != videoLoadedSuccessfully) {
//             this._videoLoadedSuccessfully = videoLoadedSuccessfully
//         }
//     }
//     get init() {
//         return this._init;
//     }
//     set player(player) {
//         if (this._player != player) {
//             this._player = player
//         }
//     }
//     get player() {
//         return this._player
//     }
// }



/***/ }),

/***/ 542:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _util = __webpack_require__(8131);
var _gridListModule = _interopRequireDefault(__webpack_require__(4012));
var _videoItem = _interopRequireDefault(__webpack_require__(1901));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _extends() {
    _extends = Object.assign ? Object.assign.bind() : function(target) {
        for(var i = 1; i < arguments.length; i++){
            var source = arguments[i];
            for(var key in source){
                if (Object.prototype.hasOwnProperty.call(source, key)) {
                    target[key] = source[key];
                }
            }
        }
        return target;
    };
    return _extends.apply(this, arguments);
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var GridList = function GridList(props) {
    var isMounted = _react["default"].useRef(false);
    var _React$useState = _react["default"].useState(-1), _React$useState2 = _slicedToArray(_React$useState, 2), activeItem = _React$useState2[0], setActiveItem = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(null), _React$useState4 = _slicedToArray(_React$useState3, 2), activeItemData = _React$useState4[0], setActiveItemData = _React$useState4[1];
    var _React$useState5 = _react["default"].useState(null), _React$useState6 = _slicedToArray(_React$useState5, 2), previousActiveItemData = _React$useState6[0], setPreviousActiveItemData = _React$useState6[1];
    var ACTIVE_ITEM_DELAY = 1000;
    _react["default"].useEffect(function() {
        if (!isMounted.current && props.cdn) {
            isMounted.current = true;
        }
        return function() {};
    }, [
        props.cdn
    ]);
    var delayedSetActiveItem = _react["default"].useCallback((0, _util.debounce)(function(e, i, d, p) {
        return handleSetActiveItem(e, i, d, p);
    }, ACTIVE_ITEM_DELAY), []); // Debounce activation of highlighted list item after mouseover
    var handleSetActiveItem = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(e, i, d, p) {
            var gc, mvc, allowPlayback, r;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        _context.prev = 0;
                        setActiveItemData(d);
                        gc = getGhostContainerOfIndex(i, "ghostVideoItem");
                        if (!(gc && moveableVideoComponent && moveableVideoComponent.current && d && videoComponent && videoComponent.current)) {
                            _context.next = 19;
                            break;
                        }
                        gc.appendChild(moveableVideoComponent.current);
                        mvc = document && document.getElementsByClassName("moveableVideoContainer") && document.getElementsByClassName("moveableVideoContainer")[0] ? document.getElementsByClassName("moveableVideoContainer")[0] : null;
                        if (!mvc) {
                            _context.next = 19;
                            break;
                        }
                        mvc.style.display = "block";
                        if (p != d) {
                            videoContainer.current.style.transition = 0 + "ms";
                            mvc.style.opacity = "0";
                        }
                        setPreviousActiveItemData(d);
                        videoContainer.current.style.transition = 200 + "ms";
                        setTimeout(function() {
                            setActiveItem(i); // Sets active grid item for highlight and playback
                            mvc.style.opacity = "1";
                        }, 750);
                        allowPlayback = checkAllowedPlayback(d);
                        if (allowPlayback) {
                            _context.next = 15;
                            break;
                        }
                        return _context.abrupt("return");
                    case 15:
                        _context.next = 17;
                        return videoPlayer.current.loadMedia(d, cdnData.videoCdn, "/video/", true, true);
                    case 17:
                        r = _context.sent;
                        // Get config: videoPlayer.current.player.getConfiguration()
                        videoComponent.current.play();
                    case 19:
                        _context.next = 23;
                        break;
                    case 21:
                        _context.prev = 21;
                        _context.t0 = _context["catch"](0);
                    case 23:
                    case "end":
                        return _context.stop();
                }
            }, _callee, null, [
                [
                    0,
                    21
                ]
            ]);
        }));
        return function handleSetActiveItem(_x2, _x3, _x4, _x5) {
            return _ref.apply(this, arguments);
        };
    }();
    // transition in opacity slowly during playback
    // stop, freeze, disappear on mouseout
    /**
   * Initialize moveable Video Component
   * @param {*} cdn 
   */ var initializeVideoPlayer = /*#__PURE__*/ function() {
        var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee3(cdn) {
            return _regeneratorRuntime().wrap(function _callee3$(_context3) {
                while(1)switch(_context3.prev = _context3.next){
                    case 0:
                        videoPlayer.current = new VideoPlayer();
                        videoPlayer.current.initPlayer(videoComponent.current).then(/*#__PURE__*/ function() {
                            var _ref3 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(data) {
                                return _regeneratorRuntime().wrap(function _callee2$(_context2) {
                                    while(1)switch(_context2.prev = _context2.next){
                                        case 0:
                                            if (videoComponent && videoPlayer && videoPlayer.current) {
                                                videoPlayer.current.cdn = cdn;
                                                //let a = await videoPlayer.current.player.configure('abr.defaultBandwidthEstimate', 1);
                                                // const uiConfig = {};
                                                // uiConfig['controlPanelElements'] = ['time_and_duration', 'spacer'];
                                                // const ui = new videoPlayer.current.shaka.ui.Overlay(videoPlayer.current.player, videoContainer.current, videoComponent.current);
                                                // ui.configure(uiConfig);
                                                // ui.getControls();
                                                // let r = await videoPlayer.current.loadMedia({
                                                //     mpd: '847f6af4d6454924ae606335143bfc74-mpd.mpd',
                                                //     hls: "847f6af4d6454924ae606335143bfc74-hls.m3u8"
                                                // }, cdnData.videoCdn, "/video/");
                                                // videoComponent.current.play();
                                                moveableVideoComponent.current = videoContainer.current;
                                                videoContainer.current.style.opacity = "0";
                                                videoContainer.current.remove();
                                            }
                                        case 1:
                                        case "end":
                                            return _context2.stop();
                                    }
                                }, _callee2);
                            }));
                            return function(_x7) {
                                return _ref3.apply(this, arguments);
                            };
                        }());
                    case 2:
                    case "end":
                        return _context3.stop();
                }
            }, _callee3);
        }));
        return function initializeVideoPlayer(_x6) {
            return _ref2.apply(this, arguments);
        };
    }();
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_gridListModule["default"].leadContainer)
    }, props._gridItems && props._gridItems.map ? props._gridListType == "video" ? props._gridItems.map(function(item, i) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_gridListModule["default"].col),
            key: i
        }, /*#__PURE__*/ _react["default"].createElement(_videoItem["default"], _extends({
            item: item,
            index: i,
            setActive: function setActive(e, i, d, p) {
                delayedSetActiveItem(e, i, d, p);
            },
            unsetActiveItem: function unsetActiveItem(i) {
                // setActiveItem(-1);
                setActiveItemData(null);
            },
            activeItem: activeItem,
            previousActiveItemData: previousActiveItemData,
            allowEditingFlag: (0, _util.detectAllowEditingFlag)(item, props._loggedIn)
        }, props)));
    }) : props._gridListType == "product" ? props._gridItems.map(function(item, i) {
        return /*#__PURE__*/ _react["default"].createElement("div", {
            className: "".concat(_gridListModule["default"].col),
            key: i
        }, "asdasda");
    }) : null : null);
};
var _default = GridList;
exports["default"] = _default;


/***/ }),

/***/ 6033:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "LivePlayer", ({
    enumerable: true,
    get: function get() {
        return _livePlayer["default"];
    }
}));
var _livePlayer = _interopRequireDefault(__webpack_require__(7153));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 7153:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _SignIn = __webpack_require__(5203);
var _video = _interopRequireDefault(__webpack_require__(5335));
var _Player = _interopRequireDefault(__webpack_require__(7154));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var Module = function Module(props) {
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), pageError = _React$useState2[0], setPageError = _React$useState2[1];
    var _React$useState3 = _react["default"].useState(false), _React$useState4 = _slicedToArray(_React$useState3, 2), componentDidMount = _React$useState4[0], setComponentDidMount = _React$useState4[1];
    var videoPlayer = _react["default"].useRef();
    var videoContainer = _react["default"].useRef();
    var videoComponent = _react["default"].useRef();
    var controlsContainer = _react["default"].useRef();
    _react["default"].useEffect(function() {
        if (!componentDidMount) {
            setComponentDidMount(true);
            // initializeVideoPlayer()
            var options = {};
            if (!videoPlayer.current) {
                var player = (0, _video["default"])("my-player", options, function onPlayerReady() {
                    _video["default"].log("Your player is ready!");
                    // In this context, `this` is the player that was created by Video.js.
                    this.src({
                        src: "https://d2lzqfjnvt208m.cloudfront.net/fidio_live_dev/2d4a33e7-d270-49cc-a652-8acfb2601777/index.m3u8",
                        type: "application/x-mpegURL"
                    });
                    this.play();
                    // How about an event listener?
                    this.on("ended", function() {
                        _video["default"].log("Awww...over so soon?!");
                    });
                });
            }
        }
    }, [
        componentDidMount
    ]);
    var initializeVideoPlayer = /*#__PURE__*/ function() {
        var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(cdn) {
            var conf;
            return _regeneratorRuntime().wrap(function _callee$(_context) {
                while(1)switch(_context.prev = _context.next){
                    case 0:
                        console.log(videoPlayer.current);
                        if (!videoPlayer.current) {
                            videoPlayer.current = new _Player["default"]();
                            conf = {
                                // manifest: {
                                //     availabilityWindowOverride: 2 * 60,
                                //     defaultPresentationDelay: 7,
                                //     hls: {
                                //         liveSegmentsDelay: 3
                                //     }
                                // },
                                streaming: {
                                    bufferBehind: 30,
                                    forceTransmux: true,
                                    lowLatencyMode: true,
                                    preferNativeHls: true,
                                    updateIntervalSeconds: .1,
                                    safeSeekOffset: 10,
                                    startAtSegmentBoundary: true,
                                    observeQualityChanges: true,
                                    maxDisabledTime: 120
                                }
                            };
                        }
                    case 2:
                    case "end":
                        return _context.stop();
                }
            }, _callee);
        }));
        return function initializeVideoPlayer(_x2) {
            return _ref.apply(this, arguments);
        };
    }();
    // Handle livestream paused for too long/frozen
    // 
    return /*#__PURE__*/ _react["default"].createElement("div", null, /*#__PURE__*/ _react["default"].createElement("div", {
        id: "splashvideocontainer",
        ref: videoContainer
    }, /*#__PURE__*/ _react["default"].createElement("video", {
        id: "my-player",
        "class": "video-js",
        controls: true,
        preload: "auto",
        poster: "//vjs.zencdn.net/v/oceans.png"
    }, /*#__PURE__*/ _react["default"].createElement("p", {
        "class": "vjs-no-js"
    }, "To view this video please enable JavaScript, and consider upgrading to a web browser that", /*#__PURE__*/ _react["default"].createElement("a", {
        href: "https://videojs.com/html5-video-support/",
        target: "_blank"
    }, "supports HTML5 video"))), /*#__PURE__*/ _react["default"].createElement("video", {
        id: "splashvideo",
        className: "shaka-video",
        style: {
            width: 100 + "%"
        },
        ref: videoComponent,
        muted: true,
        autoplay: "",
        playsinline: true
    }), /*#__PURE__*/ _react["default"].createElement("div", {
        ref: controlsContainer
    })));
};
var _default = Module;
exports["default"] = _default;


/***/ }),

/***/ 615:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.ensureAutoPlay = ensureAutoPlay;
function _callback_onAutoplayBlocked() {
// do something, for example "show big play button"
}
function isSafari() {
    var chr = window.navigator.userAgent.toLowerCase().indexOf("chrome") > -1;
    var sfri = window.navigator.userAgent.toLowerCase().indexOf("safari") > -1;
    return !chr && sfri;
}
function ensureAutoPlay(p, player) {
    var s = window["Promise"] ? window["Promise"].toString() : "";
    if (s.indexOf("function Promise()") !== -1 || s.indexOf("function ZoneAwarePromise()") !== -1) {
        p["catch"](function(error) {
            console.error("_checkAutoPlay, error:", error);
            if (error.name == "NotAllowedError") {
                // For Chrome/Firefox
                console.error("_checkAutoPlay: error.name:", "NotAllowedError");
                _callback_onAutoplayBlocked();
            } else if (error.name == "AbortError" && isSafari()) {
                // Only for Safari
                console.error("_checkAutoPlay: AbortError (Safari)");
                _callback_onAutoplayBlocked();
            } else {
                console.error("_checkAutoPlay: happened something else ", error);
            // throw error; // happened something else
            }
            return error;
        }).then(function(error) {
            console.log("_checkAutoPlay: then");
            console.log(p, player);
            if (error && error.toString && /failed because the user didn\'t interact with the document first/.test(error.toString())) {
                player.muted(true);
            }
            player.play(); // Auto-play should start
        });
    } else {
        console.error("_checkAutoplay: promise could not work in your browser ", p);
    }
}


/***/ }),

/***/ 1901:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _react = _interopRequireDefault(__webpack_require__(6689));
var _image = _interopRequireDefault(__webpack_require__(5675));
var _link = _interopRequireDefault(__webpack_require__(1664));
var _router = _interopRequireDefault(__webpack_require__(1853));
var _videoItemModule = _interopRequireDefault(__webpack_require__(2085));
var _excluded = [
    "item",
    "index",
    "setActive",
    "unsetActiveItem",
    "activeItem",
    "previousActiveItemData",
    "allowEditingFlag"
];
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _objectWithoutProperties(source, excluded) {
    if (source == null) return {};
    var target = _objectWithoutPropertiesLoose(source, excluded);
    var key, i;
    if (Object.getOwnPropertySymbols) {
        var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
        for(i = 0; i < sourceSymbolKeys.length; i++){
            key = sourceSymbolKeys[i];
            if (excluded.indexOf(key) >= 0) continue;
            if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
            target[key] = source[key];
        }
    }
    return target;
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
// import popupStyles from '../../styles/Popup.module.scss';
// import { handleGhostMetaClick } from '../../utility/video';
var VideoItem = function VideoItem(props) {
    var item = props.item, index = props.index, setActive = props.setActive, unsetActiveItem = props.unsetActiveItem, activeItem = props.activeItem, previousActiveItemData = props.previousActiveItemData, allowEditingFlag = props.allowEditingFlag, rest = _objectWithoutProperties(props, _excluded);
    var videoItemImageRef = _react["default"].useRef();
    var myLoader = function myLoader(_ref) {
        var src = _ref.src;
        if (src.match(/greythumb/)) {
            return "".concat(src);
        } else if (props.cdn && props.cdn["static"] && props.cdn["static"].length > 0) {
            return "".concat(props.cdn["static"], "/").concat(src);
        }
    };
    _react["default"].useEffect(function() {
        var setActiveCall = function setActiveCall(e) {
            setActive(e, index, item, previousActiveItemData);
        };
        var unsetActiveItemCall = function unsetActiveItemCall() {
            unsetActiveItem(index);
        };
        if (typeof index == "number" && videoItemImageRef && videoItemImageRef.current && item) {
            videoItemImageRef.current.addEventListener("mouseenter", setActiveCall);
            videoItemImageRef.current.addEventListener("mouseleave", unsetActiveItemCall);
        }
        return function() {
            if (videoItemImageRef && videoItemImageRef.current && item) {
                videoItemImageRef.current.removeEventListener("mouseenter", setActiveCall);
                videoItemImageRef.current.removeEventListener("mouseleave", unsetActiveItemCall);
            }
        };
    }, [
        index,
        videoItemImageRef,
        item,
        activeItem,
        previousActiveItemData
    ]);
    var handleEditVideoClick = function handleEditVideoClick(e, id) {
        e.preventDefault();
        if (id && _router["default"]) {
            _router["default"].push("/upload?v=".concat(id));
        }
    };
    console.log(item, props);
    return /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_videoItemModule["default"].leadContainer, " Item_GhostMetaItemContainer"),
        key: index
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: activeItem == index ? "".concat(_videoItemModule["default"].container, " activeVideoItemContainer") : "".concat(_videoItemModule["default"].container),
        ref: videoItemImageRef
    }, /*#__PURE__*/ _react["default"].createElement(_link["default"], {
        href: "w?v=".concat(item.id),
        style: {
            display: "grid"
        }
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: activeItem == index ? "".concat(_videoItemModule["default"].ghostVideoContainer, " ").concat(_videoItemModule["default"].ghostVideoContainerActive, " ghostVideoContainerItem ghostVideoContainerItemActive") : "".concat(_videoItemModule["default"].ghostVideoContainer, " ghostVideoContainerItem")
    }, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "ghostVideoItem"
    }), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "ghostVideoMeta"
    }, /*#__PURE__*/ _react["default"].createElement("div", null, item.title, allowEditingFlag ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_videoItemModule["default"].editFlagContainer),
        onClick: function onClick(e) {
            return handleEditVideoClick(e, item.id);
        }
    }, "Edit Video", /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_videoItemModule["default"].editFlag, " material-icons edit")
    }, "edit")) : null)))), /*#__PURE__*/ _react["default"].createElement(_link["default"], {
        href: "w?v=".concat(item.id),
        style: {
            display: "grid"
        }
    }, item && item.__typename == "Live" && item.status == "live" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "LiveTag"
    }, "LIVE", /*#__PURE__*/ _react["default"].createElement("div", {
        className: "RecordingCircle RecordingCircle_Small"
    })) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Item_GhostMetaContainer"
    }, item && item.__typename == "Live" ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Item_GhostMeta"
    }, item.creation && !isNaN(item.creation) && !isNaN(new Date(Number(item.creation))) ? /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Item_TinyMetaText",
        style: {
            marginBottom: ".25rem",
            textShadow: "1px 2px 6px rgb(0 0 0 / 75%)"
        }
    }, "Stream started ", new Date(Number(item.creation)).toTimeString()) : null, /*#__PURE__*/ _react["default"].createElement("div", {
        className: "Item_GhostMetaContainerInternal"
    }, /*#__PURE__*/ _react["default"].createElement("div", null, item.description ? item.description : "Watch Livestream Now"))) : null), /*#__PURE__*/ _react["default"].createElement(_image["default"], {
        loader: myLoader,
        src: item.gif && props.cdn && props.cdn["static"] ? item.gif : item.thumbnail && props.cdn && props.cdn["static"] ? item.thumbnail : "img/default/greythumb.jpg",
        alt: item.title ? item.title : "",
        width: 320,
        height: 180,
        layout: "responsive"
    }))), /*#__PURE__*/ _react["default"].createElement("div", {
        className: "".concat(_videoItemModule["default"].metaContainer)
    }, /*#__PURE__*/ _react["default"].createElement("div", null, item && item.title ? item.title : null)));
};
var _default = VideoItem;
exports["default"] = _default;


/***/ })

};
;