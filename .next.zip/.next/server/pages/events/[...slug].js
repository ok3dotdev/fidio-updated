"use strict";
(() => {
var exports = {};
exports.id = 481;
exports.ids = [481];
exports.modules = {

/***/ 6430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const EventsDetails = (props)=>{
    var _props_data, _props_data_detailmeta;
    const data = props === null || props === void 0 ? void 0 : (_props_data = props.data) === null || _props_data === void 0 ? void 0 : (_props_data_detailmeta = _props_data.detailmeta) === null || _props_data_detailmeta === void 0 ? void 0 : _props_data_detailmeta.lineup;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: " pt-[20px] pb-[20px] text-2xl lg:px-8 px-4 max-w-3xl mx-auto",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                className: "text-center lg:text-left mt-8 mb-4",
                children: "Line Up"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "flex flex-col gap-8 lg:flex-row justify-between ",
                children: data === null || data === void 0 ? void 0 : data.slice(0, 5).map((item, index)=>{
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "h-24 w-24 rounded-full bg-green-600"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                className: "text-sm mt-2",
                                children: item.title
                            })
                        ]
                    }, index);
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EventsDetails);


/***/ }),

/***/ 180:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4508);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3559);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _TicketPopup__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2044);
/* harmony import */ var _modules_utility_utility__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5329);
/* harmony import */ var _CountDown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4803);
/* harmony import */ var _modules_utility_fetch__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(23);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_8__);









const FeaturedEvent = (props, showTimer, data)=>{
    var _props_data_, _props_data__detailmeta, _props_data__detailmeta_eventDateDef, _props_data_1, _props_data__detailmeta1, _props_data__detailmeta_eventDateDef1;
    console.log("leee", props);
    const router = useRouter();
    const [isPopupVisible, setIsPopupVisible] = useState(false);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [event, setEvent] = useState([]);
    const handleTicketClaim = ()=>{
        setIsPopupVisible(true);
    };
    const handlePopupClose = ()=>{
        setIsPopupVisible(false);
    };
    const handleCarouselChange = (index)=>{
        setCurrentIndex(index);
    };
    const handleFireGlobalEvent = React.useCallback(async (e)=>{
        fireGlobalEvent(e, props._LocalEventEmitter);
        setIsPopupVisible(true);
    });
    const carouselItems = [
        {
            backgroundImageDesktop: "url(/img/internal/altsound.png)",
            backgroundImageMobile: "url(/img/internal/altsound.png)",
            title: "Alternate Sound",
            date: "NOV 04, 2023 | 06:00 PM EST"
        }
    ];
    const receiveData = (data)=>{
        console.log("data", data);
        setEvent(data.data.fetchedData[0].productReq);
    };
    useEffect(()=>{
        const handleResize = ()=>{
            const isMobile = window.innerWidth <= 768;
            const backgroundImage = isMobile ? carouselItems[currentIndex].backgroundImageMobile : carouselItems[currentIndex].backgroundImageDesktop;
            const carouselItem = document.querySelector(`#carousel-item-${currentIndex}`);
            if (carouselItem) {
                carouselItem.style.backgroundImage = backgroundImage;
            }
        };
        window.addEventListener("resize", handleResize);
        handleResize();
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, [
        currentIndex,
        carouselItems
    ]);
    return /*#__PURE__*/ _jsxs("div", {
        children: [
            /*#__PURE__*/ _jsx(Carousel, {
                selectedItem: currentIndex,
                onChange: handleCarouselChange,
                showThumbs: false,
                showArrows: true,
                showStatus: false,
                children: event.map((item, index)=>{
                    var _item_styles_;
                    /*#__PURE__*/ return _jsxs("div", {
                        id: `carousel-item-${index}`,
                        className: "flex flex-col justify-end relative w-full min-h-[520px] lg:min-h-[700px] max-w-full",
                        style: {
                            backgroundSize: "cover",
                            objectFit: "cover",
                            backgroundRepeat: "no-repeat",
                            textAlign: "left",
                            backgroundImage: `url('/img/internal/tinycafe.jpeg')`
                        },
                        children: [
                            /*#__PURE__*/ _jsx("div", {
                                className: "absolute inset-0 bg-black min-h-[700px] opacity-10"
                            }),
                            /*#__PURE__*/ _jsxs("div", {
                                className: "self-end w-full px-4 lg:px-8 py-12 pb-12 bg-gradient-to-b from-transparent to-black z-20",
                                children: [
                                    /*#__PURE__*/ _jsx("h2", {
                                        className: "text-5xl lg:text-8xl font-bold",
                                        children: item.name
                                    }),
                                    /*#__PURE__*/ _jsxs("div", {
                                        className: "flex gap-4 mt-4 items-center",
                                        children: [
                                            /*#__PURE__*/ _jsx("button", {
                                                onClick: handleTicketClaim,
                                                item: item.id,
                                                selectedstyle: (_item_styles_ = item === null || item === void 0 ? void 0 : item.styles[0]) === null || _item_styles_ === void 0 ? void 0 : _item_styles_.sid,
                                                currentoption: "70756244-2924-48b1-898f-eb7e4228b5cb",
                                                action: "add_to_cart",
                                                className: "bg-orange-800 text-white rounded-md px-4 py-4 text-xs lg:text-xl",
                                                children: "Buy Livestream"
                                            }),
                                            /*#__PURE__*/ _jsx("p", {
                                                className: "lg:text-xl text-white",
                                                children: item.date
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isPopupVisible && /*#__PURE__*/ _jsx(TicketClaimedPopup, {
                                onClose: handlePopupClose
                            })
                        ]
                    }, index);
                })
            }),
            ((_props_data_ = props === null || props === void 0 ? void 0 : props.data[0]) === null || _props_data_ === void 0 ? void 0 : (_props_data__detailmeta = _props_data_.detailmeta) === null || _props_data__detailmeta === void 0 ? void 0 : (_props_data__detailmeta_eventDateDef = _props_data__detailmeta.eventDateDef) === null || _props_data__detailmeta_eventDateDef === void 0 ? void 0 : _props_data__detailmeta_eventDateDef.dates[0]) ? /*#__PURE__*/ _jsx(Countdown, {
                eventDate: (_props_data_1 = props === null || props === void 0 ? void 0 : props.data[0]) === null || _props_data_1 === void 0 ? void 0 : (_props_data__detailmeta1 = _props_data_1.detailmeta) === null || _props_data__detailmeta1 === void 0 ? void 0 : (_props_data__detailmeta_eventDateDef1 = _props_data__detailmeta1.eventDateDef) === null || _props_data__detailmeta_eventDateDef1 === void 0 ? void 0 : _props_data__detailmeta_eventDateDef1.dates[0]
            }) : "",
            /*#__PURE__*/ _jsx(FetchHandler, {
                ...props,
                handlerName: "my_handler",
                handlerArgs: [
                    {
                        productReq: [
                            `${router.query.slug}`
                        ]
                    }
                ],
                receiveData: receiveData
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (FeaturedEvent)));


/***/ }),

/***/ 2103:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "page": () => (/* binding */ page)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(139);
/* harmony import */ var _modules_utility_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4108);
/* harmony import */ var _modules_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8131);
/* harmony import */ var _customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9833);
/* harmony import */ var _customModules_features_FeaturedEventPage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(180);
/* harmony import */ var _customModules_features_EventsDetails__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6430);
/* harmony import */ var _customModules_features_CountDown__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4803);
/* harmony import */ var _modules_utility_fetch__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(23);
/* harmony import */ var _customModules_features_Skeleton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4884);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_6__]);
_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react-hooks/rules-of-hooks */ 











const pageName = "event";
const page = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { query , asPath  } = router;
    const [fetching, setFetching] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [eventsData, setEventsData] = react__WEBPACK_IMPORTED_MODULE_1___default().useState([]);
    const [mergeProps, setMergeProps] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({});
    const [loading, setIsLoading] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(true);
    let resolvedDefinition = props.resolvedDefinition;
    const variables = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__.resolveVariables)();
    let config = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__["default"])(variables, props);
    let resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolvePage */ .mS)(config, props.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const getDefaults = async (force)=>{
        const defaults = await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolveDefaults */ .Fx)(resolvedPage.url, props, variables, query, asPath, setFetching, force);
        if (!(0,_modules_util__WEBPACK_IMPORTED_MODULE_5__.isObjectEmpty)(defaults)) {
            const newProps = Object.assign({
                ...props
            }, defaults);
            setMergeProps(newProps);
        }
    };
    props._LocalEventEmitter.unsubscribe("refetchDefaults");
    props._LocalEventEmitter.subscribe("refetchDefaults", (e)=>{
        getDefaults(true);
    });
    const receiveData = (data)=>{
        setEventsData(data.data.fetchedData[0].productReq);
        setIsLoading(false);
        console.log("datas", eventsData);
    };
    const [componentDidMount, setComponentDidMount] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [fetchingProfile, setFetchingProfile] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [profileLoaded, setProfileLoaded] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const r = react__WEBPACK_IMPORTED_MODULE_1___default().useRef();
    const profileEvent = "fetchProfileData";
    props._LocalEventEmitter.unsubscribe(profileEvent);
    props._LocalEventEmitter.subscribe(profileEvent, (e)=>{
        console.log(e, profileLoaded, fetchingProfile, props._loggedIn, e.dispatch == "fetch");
        if (e.dispatch && e.dispatch == "fetch") {
            if (!profileLoaded && !fetchingProfile && props._loggedIn && props._loggedIn.username) {
                console.log("Running!");
            // getUserProfileData(props);
            }
        }
    });
    const useProps = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .handlePropsPriority */ .oC)(mergeProps, props);
    config = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__["default"])(variables, useProps);
    resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolvePage */ .mS)(config, useProps.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const components = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .generateComponent */ .iR)(resolvedDefinition);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
            useProps: useProps,
            pageName: pageName,
            pageData: "",
            props: useProps,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customModules_features_EventsDetails__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    data: eventsData[0]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modules_utility_fetch__WEBPACK_IMPORTED_MODULE_10__.FetchHandler, {
                    ...props,
                    handlerName: "my_handler",
                    handlerArgs: [
                        {
                            productReq: [
                                `${router.query.slug}`
                            ]
                        }
                    ],
                    receiveData: receiveData
                })
            ]
        })
    });
};
const getServerSideProps = async (context)=>{
    return await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .getServerSidePropsDefault */ .nG)(context, _app_config__WEBPACK_IMPORTED_MODULE_3__.pageDefaults[pageName]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (page);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AllInclusive");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 2818:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronRight");

/***/ }),

/***/ 9605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 5020:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Inventory");

/***/ }),

/***/ 1567:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Notifications");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 227:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Stadium");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5925:
/***/ ((module) => {

module.exports = require("next/router.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5700:
/***/ ((module) => {

module.exports = require("react-fast-marquee");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5828:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 5335:
/***/ ((module) => {

module.exports = require("video.js");

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [172,750,636,262,102,108,386,833], () => (__webpack_exec__(2103)));
module.exports = __webpack_exports__;

})();