"use strict";
(() => {
var exports = {};
exports.id = 144;
exports.ids = [144];
exports.modules = {

/***/ 4167:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "page": () => (/* binding */ page)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _app_config__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(139);
/* harmony import */ var _modules_utility_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4108);
/* harmony import */ var _modules_util__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8131);
/* harmony import */ var _modules_menu___WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9675);
/* harmony import */ var _customModules_features_AltMenu__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8386);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_customModules_features_AltMenu__WEBPACK_IMPORTED_MODULE_7__]);
_customModules_features_AltMenu__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react-hooks/rules-of-hooks */ // If you want to use this as a template for another page, copy entire file and rename "pageName". Use pageDefault variable in app.config.js appropriately.








// import LiveChat from '../../customModules/features/LiveChat';
const pageName = "w";
const page = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { query , asPath  } = router;
    const [fetching, setFetching] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [mergeProps, setMergeProps] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({});
    let resolvedDefinition = props.resolvedDefinition;
    const variables = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__.resolveVariables)();
    let config = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__["default"])(variables, props);
    let resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolvePage */ .mS)(config, props.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const getDefaults = async (force)=>{
        const defaults = await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolveDefaults */ .Fx)(resolvedPage.url, props, variables, query, asPath, setFetching, force);
        if (!(0,_modules_util__WEBPACK_IMPORTED_MODULE_5__.isObjectEmpty)(defaults)) {
            const newProps = Object.assign({
                ...props
            }, defaults);
            setMergeProps(newProps);
        }
    };
    props._LocalEventEmitter.unsubscribe("refetchDefaults");
    props._LocalEventEmitter.subscribe("refetchDefaults", (e)=>{
        getDefaults(true);
    });
    react__WEBPACK_IMPORTED_MODULE_1___default().useEffect(()=>{
        if (resolvedPage && resolvedPage.url && !fetching && (0,_modules_util__WEBPACK_IMPORTED_MODULE_5__.isObjectEmpty)(mergeProps)) {
            getDefaults();
        }
    }, [
        fetching,
        mergeProps,
        resolvedPage
    ]);
    const useProps = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .handlePropsPriority */ .oC)(mergeProps, props);
    config = (0,_app_config__WEBPACK_IMPORTED_MODULE_3__["default"])(variables, useProps);
    resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .resolvePage */ .mS)(config, useProps.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const components = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .generateComponent */ .iR)(resolvedDefinition);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((react__WEBPACK_IMPORTED_MODULE_1___default().Fragment), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customModules_features_AltMenu__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                ...useProps
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `${pageName}_Body`,
                style: {
                    top: useProps.menuConfig.height ? useProps.menuConfig.height + "px" : ""
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex-shrink-0 flex-grow w-[7.5/10]",
                            children: [
                                components,
                                " "
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "flex-shrink-0 w-[2.5/10]",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                                src: "https://www3.cbox.ws/box/?boxid=3532954&boxtag=WXIP9K",
                                width: "100%",
                                height: "450",
                                allowtransparency: "yes",
                                allow: "autoplay",
                                frameborder: "0",
                                marginheight: "0",
                                marginwidth: "0",
                                scrolling: "auto"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
const getServerSideProps = async (context)=>{
    return await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_4__/* .getServerSidePropsDefault */ .nG)(context, _app_config__WEBPACK_IMPORTED_MODULE_3__.pageDefaults[pageName]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (page);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AllInclusive");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 2818:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronRight");

/***/ }),

/***/ 9605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 5020:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Inventory");

/***/ }),

/***/ 1567:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Notifications");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 227:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Stadium");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5925:
/***/ ((module) => {

module.exports = require("next/router.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5700:
/***/ ((module) => {

module.exports = require("react-fast-marquee");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5828:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 5335:
/***/ ((module) => {

module.exports = require("video.js");

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [172,750,636,262,102,108,386,675], () => (__webpack_exec__(4167)));
module.exports = __webpack_exports__;

})();