(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5171:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports["default"] = void 0;
var _index = __webpack_require__(604);
var _react = _interopRequireWildcard(__webpack_require__(6689));
function _getRequireWildcardCache(nodeInterop) {
    if (typeof WeakMap !== "function") return null;
    var cacheBabelInterop = new WeakMap();
    var cacheNodeInterop = new WeakMap();
    return (_getRequireWildcardCache = function _getRequireWildcardCache(nodeInterop) {
        return nodeInterop ? cacheNodeInterop : cacheBabelInterop;
    })(nodeInterop);
}
function _interopRequireWildcard(obj, nodeInterop) {
    if (!nodeInterop && obj && obj.__esModule) {
        return obj;
    }
    if (obj === null || _typeof(obj) !== "object" && typeof obj !== "function") {
        return {
            "default": obj
        };
    }
    var cache = _getRequireWildcardCache(nodeInterop);
    if (cache && cache.has(obj)) {
        return cache.get(obj);
    }
    var newObj = {};
    var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;
    for(var key in obj){
        if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) {
            var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;
            if (desc && (desc.get || desc.set)) {
                Object.defineProperty(newObj, key, desc);
            } else {
                newObj[key] = obj[key];
            }
        }
    }
    newObj["default"] = obj;
    if (cache) {
        cache.set(obj, newObj);
    }
    return newObj;
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var SocketContainer = function SocketContainer(props) {
    var socket = props.socket;
    var socketRef = (0, _react.useRef)(false);
    var initializeTimer = (0, _react.useRef)(null);
    var _React$useState = _react["default"].useState(null), _React$useState2 = _slicedToArray(_React$useState, 2), reconnectScheduled = _React$useState2[0], setReconnectScheduled = _React$useState2[1];
    (0, _react.useEffect)(function() {
        if (!socketRef.current && props._loggedIn && props.dborigin) {
            buildConnection();
        }
    }, [
        socket,
        socketRef.current,
        props._loggedIn,
        props.dborigin
    ]);
    var buildConnection = function buildConnection() {
        return new Promise(function(resolve, reject) {
            /* Sometimes no explicit Connect event fired. Run if connected true */ if (socket.connected && props._loggedIn && props.dborigin) {
                (0, _index.initialize)(socket, props._loggedIn, props.dborigin);
            }
            socket.on("connect", function(data) {
                console.log("Connected to socket ∞\xa6∞", socket);
                socketRef.current = true;
                setTimeout(function() {
                    (0, _index.initialize)(socket, props._loggedIn, props.dborigin);
                }, 300);
            }, {
                "reconnectionAttempts": 5
            });
            socket.on("disconnect", function(reason) {
                // Handles disconnects
                console.log("Disconnected from socket", socket);
                if (!reconnectScheduled) {
                    if (reason === "io server disconnect") {
                        socketRef.current = false;
                        var temp = setTimeout(function() {
                            // disconnect initiated by server. Manually reconnect
                            socket.connect();
                            setReconnectScheduled(null);
                        }, 5000);
                        setReconnectScheduled(temp);
                    }
                }
            });
            socket.on("connect_error", function(err) {
                console.log("Connection failed", err);
                socketRef.current = false;
                var temp = setTimeout(function() {
                    reconnect();
                    setReconnectScheduled(null);
                }, 5000);
                setReconnectScheduled(temp);
            });
            var reconnect = function reconnect() {
                var time = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 5000;
                setTimeout(function() {
                    socket.connect();
                }, time);
            };
            return resolve();
        });
    };
    (0, _react.useEffect)(function() {
        if (socket) {
            var returnInitialize = function returnInitialize(payload) {
                console.log(payload);
            };
            var returnNotify = function returnNotify(payload) {
                console.log(payload);
            };
            socket.on("returnInitialize", returnInitialize);
            socket.on("returnNotify", returnNotify);
            return function() {
                socket.off("returnInitialize", returnInitialize);
                socket.off("returnNotify", returnNotify);
            };
        }
    }, [
        props._loggedIn
    ]);
    return /*#__PURE__*/ _react["default"].createElement("div", null);
};
var _default = SocketContainer;
exports["default"] = _default;


/***/ }),

/***/ 558:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";
var __webpack_unused_export__;

__webpack_unused_export__ = ({
    value: true
});
Object.defineProperty(exports, "B", ({
    enumerable: true,
    get: function get() {
        return _SocketContainer["default"];
    }
}));
var _SocketContainer = _interopRequireDefault(__webpack_require__(5171));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}


/***/ }),

/***/ 604:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "initialize", ({
    enumerable: true,
    get: function get() {
        return _socket.initialize;
    }
}));
var _socket = __webpack_require__(6480);


/***/ }),

/***/ 6480:
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.initialize = void 0;
function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
function ownKeys(object, enumerableOnly) {
    var keys = Object.keys(object);
    if (Object.getOwnPropertySymbols) {
        var symbols = Object.getOwnPropertySymbols(object);
        enumerableOnly && (symbols = symbols.filter(function(sym) {
            return Object.getOwnPropertyDescriptor(object, sym).enumerable;
        })), keys.push.apply(keys, symbols);
    }
    return keys;
}
function _objectSpread(target) {
    for(var i = 1; i < arguments.length; i++){
        var source = null != arguments[i] ? arguments[i] : {};
        i % 2 ? ownKeys(Object(source), !0).forEach(function(key) {
            _defineProperty(target, key, source[key]);
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)) : ownKeys(Object(source)).forEach(function(key) {
            Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key));
        });
    }
    return target;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
var initialize = function initialize(socket, loggedIn, dborigin) {
    if (socket && loggedIn) {
        var payload = Object.assign(loggedIn, {
            dborigin: dborigin
        });
        socket.emit("initialize", _objectSpread({}, payload));
        return true;
    } else {
        return false;
    }
};
exports.initialize = initialize;


/***/ }),

/***/ 8403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/styles/globals.css
var globals = __webpack_require__(108);
// EXTERNAL MODULE: ./src/styles/tycoon.scss
var tycoon = __webpack_require__(5931);
// EXTERNAL MODULE: ./src/styles/video/videoPlayer.css
var videoPlayer = __webpack_require__(3324);
// EXTERNAL MODULE: ./src/styles/features/output.css
var output = __webpack_require__(2063);
// EXTERNAL MODULE: ./src/styles/video/videojs.css
var videojs = __webpack_require__(3044);
// EXTERNAL MODULE: ./src/styles/video/videoPlayerTycoon.css
var videoPlayerTycoon = __webpack_require__(3033);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/script.js
var script = __webpack_require__(4298);
var script_default = /*#__PURE__*/__webpack_require__.n(script);
;// CONCATENATED MODULE: external "socket.io-client"
const external_socket_io_client_namespaceObject = require("socket.io-client");
var external_socket_io_client_default = /*#__PURE__*/__webpack_require__.n(external_socket_io_client_namespaceObject);
// EXTERNAL MODULE: ./modules/socket/index.js
var modules_socket = __webpack_require__(558);
// EXTERNAL MODULE: ./app.config.js
var app_config = __webpack_require__(139);
// EXTERNAL MODULE: ./modules/utility/onboarding/SignIn.js
var SignIn = __webpack_require__(5203);
// EXTERNAL MODULE: ./modules/events/LocalEventEmitter.js
var LocalEventEmitter = __webpack_require__(711);
// EXTERNAL MODULE: ./modules/util.js
var util = __webpack_require__(8131);
// EXTERNAL MODULE: ./modules/utility/ecommerce/index.js
var ecommerce = __webpack_require__(6102);
;// CONCATENATED MODULE: ./src/pages/_app.js






// import 'shaka-player/dist/controls.css'


// import '../styles/styles.scss';









function MyApp({ Component , pageProps  }) {
    const [_loggedIn, _setLoggedIn] = external_react_default().useState(false);
    const [_stripeSecret, _setStripeSecret] = external_react_default().useState(false);
    const [_loginError, _setLoginError] = external_react_default().useState(false);
    const [_pageError, _setPageError] = external_react_default().useState(null);
    const [_openMenu, _setOpenMenu] = external_react_default().useState({});
    const [_cart, _setCart] = external_react_default().useState({});
    const [fetchBusy, setFetchBusy] = external_react_default().useState(false);
    external_react_default().useEffect(()=>{
        const muteLoginErr = ()=>{
            _setLoginError(null);
        };
        document.addEventListener("mute-login-error", muteLoginErr, {
            once: true
        });
    }, []);
    external_react_default().useEffect(()=>{
        if (pageProps._loggedIn) {
            _setLoggedIn(pageProps._loggedIn);
        } else {
            const signedIn = (0,SignIn.checkSignedIn)();
            console.log(signedIn);
            if (signedIn) {
                _setLoggedIn(signedIn);
            }
        }
    }, [
        _loggedIn,
        pageProps._loggedIn
    ]);
    const toggleSingleOpenMenu = (e, menu)=>{
        if (_openMenu && _openMenu.currentMenu) {
            if (_openMenu.currentMenu == menu) {
                _setOpenMenu({});
            } else {
                _setOpenMenu({
                    currentMenu: menu
                });
            }
        } else {
            _setOpenMenu({
                currentMenu: menu
            });
        }
    };
    external_react_default().useEffect(()=>{
        const cart = JSON.parse(localStorage.getItem("cart"));
        if (cart) {
            if (!cart.user) {
                const temp = cart;
                temp.user = _loggedIn;
                localStorage.setItem("cart", JSON.stringify(temp));
                _setCart(temp);
            }
        } else {
            if (_loggedIn) {
                const def = {
                    user: _loggedIn,
                    cart: []
                };
                localStorage.setItem("cart", JSON.stringify(def));
                _setCart(def);
            }
        }
    }, [
        _loggedIn
    ]);
    pageProps._LocalEventEmitter = LocalEventEmitter.LocalEventEmitter;
    pageProps._loggedIn = _loggedIn;
    pageProps._setLoggedIn = _setLoggedIn;
    pageProps._stripeSecret = _stripeSecret;
    pageProps._setStripeSecret = _setStripeSecret;
    pageProps._loginError = _loginError;
    pageProps._setLoginError = _setLoginError;
    pageProps._pageError = _pageError;
    pageProps._setPageError = _setPageError;
    pageProps._toggleSingleOpenMenu = toggleSingleOpenMenu;
    pageProps._openMenu = _openMenu;
    pageProps._cart = _cart;
    pageProps = Object.assign((0,app_config.resolveVariables)(), pageProps);
    LocalEventEmitter.LocalEventEmitter.unsubscribe("forceUpdateProps");
    LocalEventEmitter.LocalEventEmitter.subscribe("forceUpdateProps", (e)=>{
        console.log(e);
        if (e) {
            if (e.dispatch === "_cart") {
                console.log("updating");
                _setCart(JSON.parse(window.localStorage.getItem("cart"))); // Should force reload of cart props
            }
        }
    });
    LocalEventEmitter.LocalEventEmitter.unsubscribe("global_event");
    LocalEventEmitter.LocalEventEmitter.subscribe("global_event", async (e)=>{
        console.log(e);
        if (e) {
            if (e.action === "buy") {
                _setPageError(null);
                if (!fetchBusy && e.item && e.style && e.option) {
                    let cart = JSON.parse(localStorage.getItem("cart"));
                    const res = await (0,ecommerce.addToCartGlobal)(pageProps.apiUrl, pageProps.domainKey, pageProps._loggedIn, cart, e.item, {
                        style: e.style,
                        option: e.option
                    }, setFetchBusy);
                    LocalEventEmitter.LocalEventEmitter.dispatch("cart_update", {
                        dispatch: "flashCart"
                    });
                    console.log("flashCart");
                    if (res) {
                        if (res.status === "success") {
                            (0,ecommerce.updateCart)(cart, res.cart);
                            // Successfully added to cart, must perform purchase
                            cart = JSON.parse(localStorage.getItem("cart"));
                            const snapshot = (0,ecommerce.calculateTotal)(cart, null, {
                                object: true
                            });
                            console.log("snapshot", snapshot);
                            const res2 = await (0,ecommerce.performPurchase)(pageProps.apiUrl, pageProps.domainKey, pageProps._loggedIn, cart, setFetchBusy, {
                                snapshot: snapshot
                            });
                            if (res2) {
                                if (res2.status === "success") {
                                    var _res2_data, _res2_data_order;
                                    if (res2.data && res2.data.cart) {
                                        (0,ecommerce.updateCart)(cart, res2.data.cart);
                                    }
                                    if (res2 === null || res2 === void 0 ? void 0 : (_res2_data = res2.data) === null || _res2_data === void 0 ? void 0 : (_res2_data_order = _res2_data.order) === null || _res2_data_order === void 0 ? void 0 : _res2_data_order.id) {
                                        pageProps._LocalEventEmitter.dispatch("cart_update", {
                                            dispatch: "purchase",
                                            id: res2.data.order.id
                                        });
                                        console.log("Purchase Success", res2);
                                    }
                                } else {
                                    _setPageError({
                                        message: "Purchase failed",
                                        placement: "purchase"
                                    });
                                }
                            } else {
                                console.log(res2);
                                _setPageError({
                                    message: "Purchase failed",
                                    placement: "purchase"
                                });
                            }
                            setFetchBusy(false);
                        }
                    }
                }
            } else if (e.action === "add_to_cart") {
                _setPageError(null);
                if (!fetchBusy && e.item && e.style && e.option) {
                    const cart = JSON.parse(localStorage.getItem("cart"));
                    const res = await (0,ecommerce.addToCartGlobal)(pageProps.apiUrl, pageProps.domainKey, pageProps._loggedIn, cart, e.item, {
                        style: e.style,
                        option: e.option
                    }, setFetchBusy);
                    LocalEventEmitter.LocalEventEmitter.dispatch("cart_update", {
                        dispatch: "flashCart"
                    });
                    if (res) {
                        if (res.status === "success") {
                            (0,ecommerce.updateCart)(cart, res.cart);
                        }
                    } else {
                        _setPageError({
                            message: "Add to cart failed",
                            placement: "add_to_cart"
                        });
                    }
                }
            }
        }
    });
    const socketIoConfig = {
        reconnectAttempts: 1
    };
    if (pageProps.socketpath) {
        socketIoConfig.path = pageProps.socketpath;
        socketIoConfig.port = pageProps.socketPort;
    }
    const [socket, setSocket] = external_react_default().useState(null);
    const [socketTimeout, setSocketTimeout] = external_react_default().useState(null);
    external_react_default().useEffect(()=>{
        if (!socket && !socketTimeout) {
            setSocket(external_socket_io_client_default()(pageProps.socketUrl, socketIoConfig));
            const r = setTimeout(()=>{
                setSocketTimeout(null);
            }, 20000);
            setSocketTimeout(r);
        }
    }, [
        socket,
        socketTimeout
    ]);
    console.log(socket);
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("meta", {
                        name: "google-signin-client_id",
                        content: "169701902623-9a74mqcbqr38uj87qm8tm3190cicaa7m.apps.googleusercontent.com"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("title", {
                        children: pageProps.siteTitle
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx((script_default()), {
                        src: "https://accounts.google.com/gsi/client",
                        async: true,
                        defer: true
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx((script_default()), {
                        strategy: "lazyOnload",
                        id: "script_one_tap_sign_in",
                        className: "lazyOnload",
                        children: `// Register google one tap sign in event to pass data to registration/login function
                    const onOneTapSignedInGoogle = data => {
                        let event = new CustomEvent("thirdparty-signin", { "detail": data });
                        document.dispatchEvent(event);
                    }
                    const doGoogleInit = (delay = 250) => {
                        try {
                            google.accounts.id.initialize({
                                client_id: '169701902623-9a74mqcbqr38uj87qm8tm3190cicaa7m.apps.googleusercontent.com',
                                callback: onOneTapSignedInGoogle
                            })
                            console.log('Google Loaded')
                            return true
                        } catch (err) {
                            // fail silently
                            setTimeout(() => {
                                doGoogleInit(delay * 2)
                            }, delay)
                        }
                    }
                    try {
                        let createdScripts = document.getElementsByClassName("lazyOnload");
                        if (createdScripts && createdScripts.length > 1) { // Remove duplicate scripts
                            for (let i = 1; i < createdScripts.length; i++) {
                            createdScripts[i].remove();
                            }
                        }
                        doGoogleInit()
                    } catch (err) {
                        // fail silently
                        setTimeout(() => {
                            doGoogleInit(500)
                        }, 250)
                    }
                    `
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(modules_socket/* SocketContainer */.B, {
                socket: socket,
                ...pageProps
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: `${fetchBusy ? "fetchNotBusy fetchBusy" : "fetchNotBusy"}`
            }),
            /*#__PURE__*/ jsx_runtime.jsx(Component, {
                socket: socket,
                ...pageProps
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 2063:
/***/ (() => {



/***/ }),

/***/ 108:
/***/ (() => {



/***/ }),

/***/ 5931:
/***/ (() => {



/***/ }),

/***/ 3324:
/***/ (() => {



/***/ }),

/***/ 3033:
/***/ (() => {



/***/ }),

/***/ 3044:
/***/ (() => {



/***/ }),

/***/ 5567:
/***/ ((module) => {

"use strict";
module.exports = require("jwt-decode");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6153:
/***/ ((module) => {

"use strict";
module.exports = require("universal-cookie");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [172,750,298,102], () => (__webpack_exec__(8403)));
module.exports = __webpack_exports__;

})();