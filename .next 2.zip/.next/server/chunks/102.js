"use strict";
exports.id = 102;
exports.ids = [102];
exports.modules = {

/***/ 139:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "pageDefaults": () => (/* binding */ pageDefaults),
/* harmony export */   "resolveVariables": () => (/* binding */ resolveVariables)
/* harmony export */ });
const resolveConfig = (variables, props)=>{
    return {
        temporaryComponents: {
            pages: [
                {
                    url: "/test",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "div",
                                props: {
                                    className: "title"
                                },
                                children: [
                                    {
                                        type: "h1",
                                        props: {
                                            className: "title",
                                            style: {
                                                marginTop: "0px"
                                            },
                                            ...props
                                        },
                                        children: [
                                            "Hello"
                                        ]
                                    }
                                ]
                            },
                            {
                                type: "p",
                                props: {
                                    className: "content",
                                    ...props
                                },
                                children: [
                                    "Lorem ipsum"
                                ]
                            },
                            {
                                type: "SignIn",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            },
                            {
                                type: "CreditCard",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            },
                            {
                                type: "Streaming_Manager",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            },
                            {
                                type: "Onboarding_SignIn_Username",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            },
                            {
                                type: "Video_Test_Live_Player",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            // {
                            //     type: 'SignInPage', props: { className: 'content', backgroundUrl: 'img/internal/index_bg.png', OnboardCta: predefined.OnBoardCta, ctaTopVideos: {
                            //         image1: 'img/SharonRose_cta_lead_img.png'
                            //     }, imageSplash: null, ...variables, ...props }, children: [
                            //         {
                            //             type: 'Feature', props: { defaultSize: 'medium', stagger: 2000, ...variables, ...props }
                            //         }
                            //     ]
                            // },
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "Hero",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/p",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "ProfilePage",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/w",
                    data: {
                        type: "div",
                        props: {
                            className: ""
                        },
                        children: [
                            {
                                type: "WatchPage",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/terms",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "Terms",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/faq",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "Faq",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/privacy",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "Privacy",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/home",
                    data: {
                        type: "div",
                        props: {
                            className: ""
                        },
                        children: [
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "HomeDash",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/signin",
                    data: {
                        type: "div",
                        props: {
                            className: ""
                        },
                        children: [
                            {
                                type: "CustomModule",
                                props: {
                                    className: "content",
                                    customModule: "Signin",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                },
                {
                    url: "/r",
                    data: {
                        type: "div",
                        props: {
                            className: "lead-background"
                        },
                        children: [
                            {
                                type: "ReceiptPage",
                                props: {
                                    className: "content",
                                    ...variables,
                                    ...props
                                }
                            }
                        ]
                    }
                }
            ]
        },
        environment: {
            logging: {
                showLogs: true
            }
        }
    };
};
const predefined = {
    OnBoardCta: {
        lead: "Watch Live.",
        lead2: "Now",
        description: "Start Livestreaming your Favorite Artists Performances Live",
        detail: 'All payment systems operating on FiDio are operated by Tycoon Systems Corp ("Tycoon"). FiDio allows you to purchase products directly during livestreams. Please note that all purchases made through the Platform are subject to availability, pricing, and other terms specified by the sellers or vendors. We do not guarantee the availability or quality of any products offered by third-party sellers. The content, design, and functionality of the Platform are protected by intellectual property laws. You may not use, modify, distribute, or reproduce any content from the Platform without our prior written consent. Governing Law and Jurisdiction: These terms and your use of the Platform shall be governed by and construed in accordance with the laws of Canada. Any disputes arising from or in connection with these terms shall be subject to the exclusive jurisdiction of the courts in Canada. By registering on our platform you are signifying your agreement with our Terms of Services.',
        afterSignIn: "Click above to Sign In and begin",
        buttonAfterSignIn: "START WATCHING"
    },
    MenuConfig: {
        height: 0,
        padding: "0",
        left: [
            {
                type: "img",
                name: "FiDio",
                width: "110",
                height: "25",
                src: "img/internal/logo.png",
                local: true,
                href: "https://www.FiDio.ca",
                className: "my_logo_class"
            }
        ],
        right: [
            {
                type: "cart"
            },
            {
                type: "link",
                name: "notifications",
                href: "https://www.FiDio.ca",
                muiIcon: "notifications"
            }
        ]
    },
    StyleSafety: {
        padding: "0 1rem"
    },
    ImageSplash: {
        url: "https://d2ib7gxb0luc1i.cloudfront.net/gif/285924c4-88bc-4a64-a5ea-06d0ee3ea946_preview.gif"
    }
};
const pageDefaults = {
    Index: [
        "featureData",
        "profile"
    ],
    home: [
        "featureData",
        "profile"
    ]
};
const resolveVariables = ()=>{
    // return {
    //   apiUrl: 'https://dbservices.tycoon.systems/apidev',
    //   corsdefault: 'include',
    //   dborigin: 'fidio',
    //   dev: true,
    //   devLocal: true,
    //   devAddress: 'http://localhost:3020',
    //   domainKey: 'A8J29AAJSD8239D0930FJSDJFISJOFRJ2098DJ2',
    //   domainUrl: 'www.fidio.ca',
    //   stripeKey: 'pk_test_A7jK4iCYHL045qgjjfzAfPxu',
    //   socketpath: '/socket.io.dev/',
    //   socketUrl: 'https://dbservices.tycoon.systems/',
    //   streamServer: 'rtmp://3.21.225.40/live/',
    //   siteTitle: 'FiDio',
    //   menuConfig: predefined.MenuConfig,
    // };
    return {
        apiUrl: "https://dbservices.tycoon.systems/api",
        corsdefault: "include",
        dborigin: "fidio",
        dev: false,
        domainKey: "A8J29AAJSD8239D0930FJSDJFISJOFRJ2098DJ2",
        domainUrl: "www.fidio.ca",
        stripeKey: "pk_live_51NspsBF8sWqWDDvYDfxn28nWhRfri4yLSool4nAcjRiYyBrJ7HtSJ0vRW8kFLlxFRWTN6SXeiPId7oP1nr0FR78d00N1YLB2PP",
        menuConfig: predefined.MenuConfig,
        socketpath: "/socket.io.live/",
        socketUrl: "https://dbservices.tycoon.systems/",
        streamServer: "rtmp://3.21.225.40/live_dev/",
        siteTitle: "FiDio"
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (resolveConfig);



/***/ }),

/***/ 711:
/***/ ((module) => {


var LocalEventEmitter = {
    _events: {},
    dispatch: function dispatch(event, data) {
        console.log(event, data);
        if (!this._events[event]) return;
        this._events[event].forEach(function(callback) {
            return callback(data);
        });
    },
    subscribe: function subscribe(event, callback) {
        if (!this._events[event]) this._events[event] = [];
        this._events[event].push(callback);
    },
    unsubscribe: function unsubscribe(event) {
        if (!this._events[event]) return;
        delete this._events[event];
    }
};
module.exports = {
    LocalEventEmitter: LocalEventEmitter
};


/***/ }),

/***/ 8131:
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.compareObjects = compareObjects;
exports.isObjectEmpty = exports.getFormattedTime = exports.getFormattedDate = exports.detectAllowEditingFlag = exports.debounce = void 0;
function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
function _slicedToArray(arr, i) {
    return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _unsupportedIterableToArray(arr, i) || _nonIterableRest();
}
function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}
function _unsupportedIterableToArray(o, minLen) {
    if (!o) return;
    if (typeof o === "string") return _arrayLikeToArray(o, minLen);
    var n = Object.prototype.toString.call(o).slice(8, -1);
    if (n === "Object" && o.constructor) n = o.constructor.name;
    if (n === "Map" || n === "Set") return Array.from(o);
    if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen);
}
function _arrayLikeToArray(arr, len) {
    if (len == null || len > arr.length) len = arr.length;
    for(var i = 0, arr2 = new Array(len); i < len; i++)arr2[i] = arr[i];
    return arr2;
}
function _iterableToArrayLimit(arr, i) {
    var _i = null == arr ? null : "undefined" != typeof Symbol && arr[Symbol.iterator] || arr["@@iterator"];
    if (null != _i) {
        var _s, _e, _x, _r, _arr = [], _n = !0, _d = !1;
        try {
            if (_x = (_i = _i.call(arr)).next, 0 === i) {
                if (Object(_i) !== _i) return;
                _n = !1;
            } else for(; !(_n = (_s = _x.call(_i)).done) && (_arr.push(_s.value), _arr.length !== i); _n = !0);
        } catch (err) {
            _d = !0, _e = err;
        } finally{
            try {
                if (!_n && null != _i["return"] && (_r = _i["return"](), Object(_r) !== _r)) return;
            } finally{
                if (_d) throw _e;
            }
        }
        return _arr;
    }
}
function _arrayWithHoles(arr) {
    if (Array.isArray(arr)) return arr;
}
var isObjectEmpty = function isObjectEmpty(obj) {
    return obj // 👈 null and undefined check
     && Object.keys(obj).length === 0 && Object.getPrototypeOf(obj) === Object.prototype;
};
exports.isObjectEmpty = isObjectEmpty;
var debounce = function debounce(a, b, c) {
    var d, e;
    return function() {
        function h() {
            d = null, c || (e = a.apply(f, g));
        }
        var f = this, g = arguments;
        return clearTimeout(d), d = setTimeout(h, b), c && !d && (e = a.apply(f, g)), e;
    };
};
exports.debounce = debounce;
var detectAllowEditingFlag = function detectAllowEditingFlag(data, loggedIn) {
    if (data && data.author && loggedIn && loggedIn.identifier && data.author === loggedIn.identifier) {
        return true;
    }
    return false;
};
exports.detectAllowEditingFlag = detectAllowEditingFlag;
var getFormattedTime = function getFormattedTime(time) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    try {
        // Format the time (-HH:MMAM/PM)
        if (options.simple) {
            var _time$split$map = time.split(":").map(Number), _time$split$map2 = _slicedToArray(_time$split$map, 2), hours = _time$split$map2[0], minutes = _time$split$map2[1];
            var period = hours < 12 ? "AM" : "PM";
            var hours12 = hours % 12 || 12;
            var _formattedTime = "".concat(hours12, ":").concat(minutes.toString().padStart(2, "0")).concat(period);
            return _formattedTime;
        }
        var timeOptions = {
            hour: "2-digit",
            minute: "2-digit",
            hour12: true
        };
        var timeFormatter = new Intl.DateTimeFormat("en-US", timeOptions);
        var formattedTime = timeFormatter.format(time);
        return formattedTime;
    } catch (err) {
        console.log(err);
        return time;
    }
};
exports.getFormattedTime = getFormattedTime;
var getFormattedDate = function getFormattedDate(date) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    if (options.pretty) {
        try {
            var dateOptions = {
                day: "2-digit",
                month: "short",
                year: "numeric"
            };
            console.log("Format Date", date, _typeof(date));
            var dateFormatter = new Intl.DateTimeFormat("en-US", dateOptions);
            var formattedDate = dateFormatter.format(new Date(date));
            console.log("Time for Date", date);
            var formattedTime = getFormattedTime(new Date(date));
            console.log("Formatted Time Date", formattedDate, formattedTime);
            // Combine date and time
            if (!options.date && !options.time || options.date && options.time) {
                return formattedDate + "-" + formattedTime;
            }
            var d = "";
            if (options.date) {
                d += formattedDate;
            }
            if (options.time) {
                if (d.length !== 0) {
                    d += "-";
                }
                d += formattedTime;
            }
            return d;
        } catch (err) {
            console.log(err);
            return date;
        }
    }
    var year = date.getFullYear();
    var month = (1 + date.getMonth()).toString().padStart(2, "0");
    var day = date.getDate().toString().padStart(2, "0");
    return month + "/" + day + "/" + year;
};
exports.getFormattedDate = getFormattedDate;
function compareObjects(obj1, obj2) {
    if (obj1 === obj2) return true;
    if (_typeof(obj1) !== "object" || _typeof(obj2) !== "object" || obj1 == null || obj2 == null) {
        return false;
    }
    var keysA = Object.keys(obj1);
    var keysB = Object.keys(obj2);
    if (keysA.length !== keysB.length) {
        return false;
    }
    var result = true;
    keysA.forEach(function(key) {
        if (!keysB.includes(key)) {
            result = false;
        }
        if (typeof obj1[key] === "function" || typeof obj2[key] === "function") {
            if (obj1[key].toString() !== obj2[key].toString()) {
                result = false;
            }
        }
        if (!compareObjects(obj1[key], obj2[key])) {
            result = false;
        }
    });
    return result;
}


/***/ }),

/***/ 8730:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.westernMoneyFormat = exports.updateCart = exports.resolveStyles = exports.resolveMoneyFormat = exports.resolveImg = exports.resolveDefaultStyle = exports.resolveCurrentStyle = exports.resolveCurrentPrice = exports.resolveCurrentOption = exports.performPurchase = exports.doUploadImageForProduct = exports.doUploadImageForLineupParticipant = exports.doPublishProduct = exports.createShop = exports.calculateTotal = exports.addToCartGlobal = exports.addToCart = void 0;
var _fetch = __webpack_require__(6699);
var _SignIn = __webpack_require__(5203);
var _util = __webpack_require__(8131);
var _universalCookie = _interopRequireDefault(__webpack_require__(6153));
var _LocalEventEmitter = __webpack_require__(711);
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
var cookies = new _universalCookie["default"]();
var createShop = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(uri, domainKey, user, shopData) {
        var fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    if (!(user.identifier && user.hash && shopData && shopData.shopName)) {
                        _context.next = 24;
                        break;
                    }
                    fetchBody = {
                        domainKey: domainKey,
                        shopData: shopData,
                        hash: user.hash,
                        identifier: user.identifier
                    };
                    _context.next = 4;
                    return (0, _fetch.fetchPost)(uri + "/m/createshop", null, null, fetchBody);
                case 4:
                    res = _context.sent;
                    if (res) {
                        _context.next = 9;
                        break;
                    }
                    return _context.abrupt("return", false);
                case 9:
                    if (!res.hasOwnProperty("status")) {
                        _context.next = 21;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context.next = 15;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context.abrupt("return", "disauthenticated");
                case 15:
                    if (!(res.status == "failed")) {
                        _context.next = 19;
                        break;
                    }
                    return _context.abrupt("return", false);
                case 19:
                    if (!(res.status == "success")) {
                        _context.next = 21;
                        break;
                    }
                    return _context.abrupt("return", res);
                case 21:
                    return _context.abrupt("return", false);
                case 24:
                    return _context.abrupt("return", false);
                case 25:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function createShop(_x, _x2, _x3, _x4) {
        return _ref.apply(this, arguments);
    };
}();
exports.createShop = createShop;
var doPublishProduct = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(uri, domainKey, shop, user, product, body) {
        var res;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    if (!(user.identifier && user.hash && product && shop && domainKey)) {
                        _context2.next = 23;
                        break;
                    }
                    _context2.next = 3;
                    return (0, _fetch.fetchPost)(uri + "/m/publishproduct", null, null, body, {
                        formData: true
                    });
                case 3:
                    res = _context2.sent;
                    if (res) {
                        _context2.next = 8;
                        break;
                    }
                    return _context2.abrupt("return", false);
                case 8:
                    if (!res.hasOwnProperty("status")) {
                        _context2.next = 20;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context2.next = 14;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context2.abrupt("return", "disauthenticated");
                case 14:
                    if (!(res.status == "failed")) {
                        _context2.next = 18;
                        break;
                    }
                    return _context2.abrupt("return", false);
                case 18:
                    if (!(res.status == "success")) {
                        _context2.next = 20;
                        break;
                    }
                    return _context2.abrupt("return", res);
                case 20:
                    return _context2.abrupt("return", false);
                case 23:
                    return _context2.abrupt("return", false);
                case 24:
                case "end":
                    return _context2.stop();
            }
        }, _callee2);
    }));
    return function doPublishProduct(_x5, _x6, _x7, _x8, _x9, _x10) {
        return _ref2.apply(this, arguments);
    };
}();
exports.doPublishProduct = doPublishProduct;
var resolveImg = function resolveImg(product, cdn, override) {
    if (override) {
        return override;
    }
    return "img/default/greythumb_product.jpg";
};
exports.resolveImg = resolveImg;
var resolveStyles = function resolveStyles(product) {
    if (product && product.styles) {
        return product.styles;
    }
    return [];
};
exports.resolveStyles = resolveStyles;
var resolveCurrentPrice = function resolveCurrentPrice(product, selectedStyle, currency) {
    console.log(product, selectedStyle, currency);
    if (product && product.styles) {
        var p = product.styles.find(function(m) {
            return m.sid === selectedStyle;
        });
        if (p && Object.prototype.hasOwnProperty.call(p, "price")) {
            return "".concat(currency).concat(p.price);
        }
        if (product.styles[0] && Object.prototype.hasOwnProperty.call(product.styles[0], "price")) {
            return "".concat(currency).concat(product.styles[0].price);
        }
    }
    return "";
};
exports.resolveCurrentPrice = resolveCurrentPrice;
var resolveCurrentStyle = function resolveCurrentStyle(product, selectedStyle) {
    if (product && product.styles) {
        var p = product.styles.find(function(m) {
            return m.sid === selectedStyle;
        });
        return p;
    }
    return "";
};
exports.resolveCurrentStyle = resolveCurrentStyle;
var resolveCurrentOption = function resolveCurrentOption(style, selectedOption) {
    if (style && style.option) {
        var o = style.option.find(function(m) {
            return m.sid === selectedOption;
        });
        return o;
    }
    return "";
};
exports.resolveCurrentOption = resolveCurrentOption;
var resolveDefaultStyle = function resolveDefaultStyle(product, selectedStyle, f, currentOption, f2) {
    if ((0, _util.isObjectEmpty)(selectedStyle)) {
        if (product && product.styles && product.styles[0] && product.styles[0].sid) {
            f(product.styles[0].sid);
            if (!currentOption && product.styles[0].option && product.styles[0].option[0] && product.styles[0].option[0].sid) {
                f2(product.styles[0].option[0].sid);
            }
        }
    }
};
exports.resolveDefaultStyle = resolveDefaultStyle;
var updateCart = function updateCart(user, cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
    _LocalEventEmitter.LocalEventEmitter.dispatch("forceUpdateProps", {
        dispatch: "_cart"
    });
    return cart;
};
exports.updateCart = updateCart;
var calculateTotal = function calculateTotal(cart, prefix, options) {
    var prices = [];
    var total = 0;
    if (cart && cart.items) {
        cart.items.map(function(item) {
            var style = resolveCurrentStyle(item.product, item.style);
            if (style && Object.prototype.hasOwnProperty.call(style, "price")) {
                prices.push(Object.assign(item, {
                    price: style.price
                }));
                total += style.price * item.quantity;
            }
        });
    }
    if (options) {
        if (options.object) {
            return {
                prices: prices,
                total: total
            };
        }
    }
    if (prefix) {
        return prefix + total;
    }
    return total;
};
exports.calculateTotal = calculateTotal;
var doUploadImageForProduct = /*#__PURE__*/ function() {
    var _ref3 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee3(uri, domainKey, product, user, body) {
        var res;
        return _regeneratorRuntime().wrap(function _callee3$(_context3) {
            while(1)switch(_context3.prev = _context3.next){
                case 0:
                    if (!(user.identifier && user.hash && product && domainKey)) {
                        _context3.next = 23;
                        break;
                    }
                    _context3.next = 3;
                    return (0, _fetch.fetchPost)(uri + "/m/uploadimageforproduct", null, null, body, {
                        formData: true
                    });
                case 3:
                    res = _context3.sent;
                    if (res) {
                        _context3.next = 8;
                        break;
                    }
                    return _context3.abrupt("return", false);
                case 8:
                    if (!res.hasOwnProperty("status")) {
                        _context3.next = 20;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context3.next = 14;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context3.abrupt("return", "disauthenticated");
                case 14:
                    if (!(res.status == "failed")) {
                        _context3.next = 18;
                        break;
                    }
                    return _context3.abrupt("return", false);
                case 18:
                    if (!(res.status == "success")) {
                        _context3.next = 20;
                        break;
                    }
                    return _context3.abrupt("return", res);
                case 20:
                    return _context3.abrupt("return", false);
                case 23:
                    return _context3.abrupt("return", false);
                case 24:
                case "end":
                    return _context3.stop();
            }
        }, _callee3);
    }));
    return function doUploadImageForProduct(_x11, _x12, _x13, _x14, _x15) {
        return _ref3.apply(this, arguments);
    };
}();
exports.doUploadImageForProduct = doUploadImageForProduct;
var doUploadImageForLineupParticipant = /*#__PURE__*/ function() {
    var _ref4 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee4(uri, domainKey, product, user, body) {
        var res;
        return _regeneratorRuntime().wrap(function _callee4$(_context4) {
            while(1)switch(_context4.prev = _context4.next){
                case 0:
                    if (!(user.identifier && user.hash && product && domainKey)) {
                        _context4.next = 23;
                        break;
                    }
                    _context4.next = 3;
                    return (0, _fetch.fetchPost)(uri + "/m/uploadimageforlineupparticipant", null, null, body, {
                        formData: true
                    });
                case 3:
                    res = _context4.sent;
                    if (res) {
                        _context4.next = 8;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 8:
                    if (!res.hasOwnProperty("status")) {
                        _context4.next = 20;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context4.next = 14;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context4.abrupt("return", "disauthenticated");
                case 14:
                    if (!(res.status == "failed")) {
                        _context4.next = 18;
                        break;
                    }
                    return _context4.abrupt("return", false);
                case 18:
                    if (!(res.status == "success")) {
                        _context4.next = 20;
                        break;
                    }
                    return _context4.abrupt("return", res);
                case 20:
                    return _context4.abrupt("return", false);
                case 23:
                    return _context4.abrupt("return", false);
                case 24:
                case "end":
                    return _context4.stop();
            }
        }, _callee4);
    }));
    return function doUploadImageForLineupParticipant(_x16, _x17, _x18, _x19, _x20) {
        return _ref4.apply(this, arguments);
    };
}();
exports.doUploadImageForLineupParticipant = doUploadImageForLineupParticipant;
var addToCartGlobal = /*#__PURE__*/ function() {
    var _ref5 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee5(uri, domainKey, user, cart, product, spec, setFetchBusy, options) {
        var fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee5$(_context5) {
            while(1)switch(_context5.prev = _context5.next){
                case 0:
                    _context5.prev = 0;
                    console.log(uri, domainKey, user, cart, product, spec, setFetchBusy, options);
                    if (!(user && user.identifier && user.hash && product && domainKey && uri)) {
                        _context5.next = 25;
                        break;
                    }
                    setFetchBusy(true);
                    fetchBody = {
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier,
                        cart: cart,
                        product: product,
                        spec: spec,
                        options: options
                    };
                    _context5.next = 7;
                    return (0, _fetch.fetchPost)(uri + "/m/addtocart", null, null, fetchBody);
                case 7:
                    res = _context5.sent;
                    setFetchBusy(false);
                    if (res) {
                        _context5.next = 13;
                        break;
                    }
                    return _context5.abrupt("return", false);
                case 13:
                    if (!res.hasOwnProperty("status")) {
                        _context5.next = 25;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context5.next = 19;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context5.abrupt("return", "disauthenticated");
                case 19:
                    if (!(res.status == "failed")) {
                        _context5.next = 23;
                        break;
                    }
                    return _context5.abrupt("return", false);
                case 23:
                    if (!(res.status == "success")) {
                        _context5.next = 25;
                        break;
                    }
                    return _context5.abrupt("return", res);
                case 25:
                    _context5.next = 32;
                    break;
                case 27:
                    _context5.prev = 27;
                    _context5.t0 = _context5["catch"](0);
                    console.log(_context5.t0);
                    if (setFetchBusy) {
                        setFetchBusy(false);
                    }
                    return _context5.abrupt("return", {
                        // fail silently
                        status: "failed",
                        message: "Could not add Product to cart"
                    });
                case 32:
                case "end":
                    return _context5.stop();
            }
        }, _callee5, null, [
            [
                0,
                27
            ]
        ]);
    }));
    return function addToCartGlobal(_x21, _x22, _x23, _x24, _x25, _x26, _x27, _x28) {
        return _ref5.apply(this, arguments);
    };
}();
exports.addToCartGlobal = addToCartGlobal;
var addToCart = /*#__PURE__*/ function() {
    var _ref6 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee6(uri, domainKey, user, cart, product, spec, setFetchBusy, options) {
        var style, option, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee6$(_context6) {
            while(1)switch(_context6.prev = _context6.next){
                case 0:
                    _context6.prev = 0;
                    console.log(uri, domainKey, user, product, spec, cart);
                    if (!(user && user.identifier && user.hash && product && domainKey && uri)) {
                        _context6.next = 33;
                        break;
                    }
                    if (!(product && product.styles)) {
                        _context6.next = 33;
                        break;
                    }
                    if (!(spec.style && spec.option)) {
                        _context6.next = 33;
                        break;
                    }
                    style = product.styles.find(function(p) {
                        return p.sid === spec.style;
                    });
                    if (!(style && style.option)) {
                        _context6.next = 33;
                        break;
                    }
                    option = style.option.find(function(o) {
                        return o.sid === spec.option;
                    });
                    if (!option) {
                        _context6.next = 33;
                        break;
                    }
                    if (!(option.quantity && (option.quantity > 0 || option.quantity === -100))) {
                        _context6.next = 33;
                        break;
                    }
                    if (!setFetchBusy) {
                        _context6.next = 33;
                        break;
                    }
                    setFetchBusy(true);
                    fetchBody = {
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier,
                        cart: cart,
                        product: product,
                        spec: spec,
                        options: options
                    };
                    _context6.next = 15;
                    return (0, _fetch.fetchPost)(uri + "/m/addtocart", null, null, fetchBody);
                case 15:
                    res = _context6.sent;
                    setFetchBusy(false);
                    if (res) {
                        _context6.next = 21;
                        break;
                    }
                    return _context6.abrupt("return", false);
                case 21:
                    if (!res.hasOwnProperty("status")) {
                        _context6.next = 33;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context6.next = 27;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context6.abrupt("return", "disauthenticated");
                case 27:
                    if (!(res.status == "failed")) {
                        _context6.next = 31;
                        break;
                    }
                    return _context6.abrupt("return", false);
                case 31:
                    if (!(res.status == "success")) {
                        _context6.next = 33;
                        break;
                    }
                    return _context6.abrupt("return", res);
                case 33:
                    throw new Error();
                case 36:
                    _context6.prev = 36;
                    _context6.t0 = _context6["catch"](0);
                    console.log(_context6.t0);
                    if (setFetchBusy) {
                        setFetchBusy(false);
                    }
                    return _context6.abrupt("return", {
                        // fail silently
                        status: "failed",
                        message: "Could not add Product to cart"
                    });
                case 41:
                case "end":
                    return _context6.stop();
            }
        }, _callee6, null, [
            [
                0,
                36
            ]
        ]);
    }));
    return function addToCart(_x29, _x30, _x31, _x32, _x33, _x34, _x35, _x36) {
        return _ref6.apply(this, arguments);
    };
}();
exports.addToCart = addToCart;
var performPurchase = /*#__PURE__*/ function() {
    var _ref7 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee7(uri, domainKey, user, cart, setFetchBusy, options) {
        var fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee7$(_context7) {
            while(1)switch(_context7.prev = _context7.next){
                case 0:
                    _context7.prev = 0;
                    if (!(user && user.identifier && user.hash && cart && domainKey && uri)) {
                        _context7.next = 27;
                        break;
                    }
                    if (!setFetchBusy) {
                        _context7.next = 27;
                        break;
                    }
                    setFetchBusy(true);
                    fetchBody = {
                        domainKey: domainKey,
                        hash: user.hash,
                        identifier: user.identifier,
                        cart: cart,
                        options: options
                    };
                    _context7.next = 7;
                    return (0, _fetch.fetchPost)(uri + "/m/performpurchase", null, null, fetchBody);
                case 7:
                    res = _context7.sent;
                    setFetchBusy(false);
                    if (res) {
                        _context7.next = 13;
                        break;
                    }
                    return _context7.abrupt("return", false);
                case 13:
                    if (!res.hasOwnProperty("status")) {
                        _context7.next = 27;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context7.next = 19;
                        break;
                    }
                    (0, _SignIn.logout)();
                    return _context7.abrupt("return", "disauthenticated");
                case 19:
                    if (!(res.status == "failed")) {
                        _context7.next = 25;
                        break;
                    }
                    if (!res.message) {
                        _context7.next = 22;
                        break;
                    }
                    return _context7.abrupt("return", res);
                case 22:
                    return _context7.abrupt("return", false);
                case 25:
                    if (!(res.status == "success")) {
                        _context7.next = 27;
                        break;
                    }
                    return _context7.abrupt("return", res);
                case 27:
                    throw new Error();
                case 30:
                    _context7.prev = 30;
                    _context7.t0 = _context7["catch"](0);
                    console.log(_context7.t0);
                    if (setFetchBusy) {
                        setFetchBusy(false);
                    }
                    return _context7.abrupt("return", {
                        // fail silently
                        status: "failed",
                        message: "Could not perform purchase"
                    });
                case 35:
                case "end":
                    return _context7.stop();
            }
        }, _callee7, null, [
            [
                0,
                30
            ]
        ]);
    }));
    return function performPurchase(_x37, _x38, _x39, _x40, _x41, _x42) {
        return _ref7.apply(this, arguments);
    };
}();
exports.performPurchase = performPurchase;
var westernMoneyFormat = new Intl.NumberFormat("en-US", {
    minimumIntegerDigits: 1,
    minimumFractionDigits: 2
});
exports.westernMoneyFormat = westernMoneyFormat;
var resolveMoneyFormat = function resolveMoneyFormat(v) {
    try {
        if (!isNaN(Number(v)) && v !== null) {
            return westernMoneyFormat.format(v);
        }
        return null;
    } catch (err) {
        console.log(err);
        return null;
    }
};
exports.resolveMoneyFormat = resolveMoneyFormat;


/***/ }),

/***/ 6102:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


Object.defineProperty(exports, "__esModule", ({
    value: true
}));
Object.defineProperty(exports, "addToCart", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.addToCart;
    }
}));
Object.defineProperty(exports, "addToCartGlobal", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.addToCartGlobal;
    }
}));
Object.defineProperty(exports, "calculateTotal", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.calculateTotal;
    }
}));
Object.defineProperty(exports, "createShop", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.createShop;
    }
}));
Object.defineProperty(exports, "doPublishProduct", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.doPublishProduct;
    }
}));
Object.defineProperty(exports, "doUploadImageForLineupParticipant", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.doUploadImageForLineupParticipant;
    }
}));
Object.defineProperty(exports, "doUploadImageForProduct", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.doUploadImageForProduct;
    }
}));
Object.defineProperty(exports, "performPurchase", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.performPurchase;
    }
}));
Object.defineProperty(exports, "resolveCurrentOption", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveCurrentOption;
    }
}));
Object.defineProperty(exports, "resolveCurrentPrice", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveCurrentPrice;
    }
}));
Object.defineProperty(exports, "resolveCurrentStyle", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveCurrentStyle;
    }
}));
Object.defineProperty(exports, "resolveDefaultStyle", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveDefaultStyle;
    }
}));
Object.defineProperty(exports, "resolveImg", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveImg;
    }
}));
Object.defineProperty(exports, "resolveMoneyFormat", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveMoneyFormat;
    }
}));
Object.defineProperty(exports, "resolveStyles", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.resolveStyles;
    }
}));
Object.defineProperty(exports, "updateCart", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.updateCart;
    }
}));
Object.defineProperty(exports, "westernMoneyFormat", ({
    enumerable: true,
    get: function get() {
        return _ecommerce.westernMoneyFormat;
    }
}));
var _ecommerce = __webpack_require__(8730);


/***/ }),

/***/ 6699:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.retrieveUrlParams = exports.fetchPost = exports.fetchGet = void 0;
var _app = __webpack_require__(139);
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
var fetchPost = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(route, headers, cred) {
        var body, options, updatedBody, payload, _args = arguments;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    body = _args.length > 3 && _args[3] !== undefined ? _args[3] : {};
                    options = _args.length > 4 && _args[4] !== undefined ? _args[4] : {};
                    if (!headers && !options.formData) {
                        headers = {
                            "Accept": "application/json",
                            "Content-Type": "application/json"
                        };
                    }
                    if (!cred) {
                        cred = (0, _app.resolveVariables)().corsdefault;
                    }
                    console.log(route, fetch);
                    updatedBody = body;
                    if (options.formData) {
                        body.append("dborigin", (0, _app.resolveVariables)().dborigin);
                    } else {
                        updatedBody.dborigin = (0, _app.resolveVariables)().dborigin;
                    }
                    console.log("Form Data", options.formData);
                    payload = {
                        method: "POST",
                        cred: cred,
                        body: options.formData ? body : JSON.stringify(updatedBody)
                    };
                    if (headers) {
                        payload.headers = headers;
                    }
                    _context.next = 12;
                    return fetch(route, payload).then(function(response) {
                        return response.json();
                    }).then(function(data) {
                        return data;
                    })["catch"](function(err) {
                        console.log(err);
                        return err;
                    });
                case 12:
                    return _context.abrupt("return", _context.sent);
                case 13:
                case "end":
                    return _context.stop();
            }
        }, _callee);
    }));
    return function fetchPost(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();
exports.fetchPost = fetchPost;
var fetchGet = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(route, headers, cred, options) {
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    if (!headers) {
                        headers = {
                            "Accept": "application/json",
                            "Content-Type": "application/json"
                        };
                    }
                    if (!cred) {
                        cred = (0, _app.resolveVariables)().corsdefault;
                    }
                    _context2.next = 4;
                    return fetch(route, {
                        method: "GET",
                        headers: headers,
                        cred: cred
                    }).then(function(response) {
                        return response.json();
                    }).then(function(data) {
                        return data;
                    })["catch"](function(err) {
                        return err;
                    });
                case 4:
                    return _context2.abrupt("return", _context2.sent);
                case 5:
                case "end":
                    return _context2.stop();
            }
        }, _callee2);
    }));
    return function fetchGet(_x4, _x5, _x6, _x7) {
        return _ref2.apply(this, arguments);
    };
}();
exports.fetchGet = fetchGet;
var retrieveUrlParams = function retrieveUrlParams() {
    return new Proxy(new URLSearchParams(window.location.search), {
        get: function get(searchParams, prop) {
            return searchParams.get(prop);
        }
    });
};
exports.retrieveUrlParams = retrieveUrlParams;


/***/ }),

/***/ 5203:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {


function _typeof(obj) {
    "@babel/helpers - typeof";
    return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(obj) {
        return typeof obj;
    } : function(obj) {
        return obj && "function" == typeof Symbol && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
    }, _typeof(obj);
}
Object.defineProperty(exports, "__esModule", ({
    value: true
}));
exports.updateLocalLoginSession = exports.logout = exports.grabUsername = exports.checkSignedInAndPrompt = exports.checkSignedIn = exports.attemptThirdPartySignIn = void 0;
var _universalCookie = _interopRequireDefault(__webpack_require__(6153));
var _fetch = __webpack_require__(6699);
var _ecommerce = __webpack_require__(8730);
var _jwtDecode = _interopRequireDefault(__webpack_require__(5567));
function _interopRequireDefault(obj) {
    return obj && obj.__esModule ? obj : {
        "default": obj
    };
}
function _regeneratorRuntime() {
    "use strict"; /*! regenerator-runtime -- Copyright (c) 2014-present, Facebook, Inc. -- license (MIT): https://github.com/facebook/regenerator/blob/main/LICENSE */ 
    _regeneratorRuntime = function _regeneratorRuntime() {
        return exports1;
    };
    var exports1 = {}, Op = Object.prototype, hasOwn = Op.hasOwnProperty, defineProperty = Object.defineProperty || function(obj, key, desc) {
        obj[key] = desc.value;
    }, $Symbol = "function" == typeof Symbol ? Symbol : {}, iteratorSymbol = $Symbol.iterator || "@@iterator", asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator", toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";
    function define(obj, key, value) {
        return Object.defineProperty(obj, key, {
            value: value,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }), obj[key];
    }
    try {
        define({}, "");
    } catch (err) {
        define = function define(obj, key, value) {
            return obj[key] = value;
        };
    }
    function wrap(innerFn, outerFn, self, tryLocsList) {
        var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator, generator = Object.create(protoGenerator.prototype), context = new Context(tryLocsList || []);
        return defineProperty(generator, "_invoke", {
            value: makeInvokeMethod(innerFn, self, context)
        }), generator;
    }
    function tryCatch(fn, obj, arg) {
        try {
            return {
                type: "normal",
                arg: fn.call(obj, arg)
            };
        } catch (err) {
            return {
                type: "throw",
                arg: err
            };
        }
    }
    exports1.wrap = wrap;
    var ContinueSentinel = {};
    function Generator() {}
    function GeneratorFunction() {}
    function GeneratorFunctionPrototype() {}
    var IteratorPrototype = {};
    define(IteratorPrototype, iteratorSymbol, function() {
        return this;
    });
    var getProto = Object.getPrototypeOf, NativeIteratorPrototype = getProto && getProto(getProto(values([])));
    NativeIteratorPrototype && NativeIteratorPrototype !== Op && hasOwn.call(NativeIteratorPrototype, iteratorSymbol) && (IteratorPrototype = NativeIteratorPrototype);
    var Gp = GeneratorFunctionPrototype.prototype = Generator.prototype = Object.create(IteratorPrototype);
    function defineIteratorMethods(prototype) {
        [
            "next",
            "throw",
            "return"
        ].forEach(function(method) {
            define(prototype, method, function(arg) {
                return this._invoke(method, arg);
            });
        });
    }
    function AsyncIterator(generator, PromiseImpl) {
        function invoke(method, arg, resolve, reject) {
            var record = tryCatch(generator[method], generator, arg);
            if ("throw" !== record.type) {
                var result = record.arg, value = result.value;
                return value && "object" == _typeof(value) && hasOwn.call(value, "__await") ? PromiseImpl.resolve(value.__await).then(function(value) {
                    invoke("next", value, resolve, reject);
                }, function(err) {
                    invoke("throw", err, resolve, reject);
                }) : PromiseImpl.resolve(value).then(function(unwrapped) {
                    result.value = unwrapped, resolve(result);
                }, function(error) {
                    return invoke("throw", error, resolve, reject);
                });
            }
            reject(record.arg);
        }
        var previousPromise;
        defineProperty(this, "_invoke", {
            value: function value(method, arg) {
                function callInvokeWithMethodAndArg() {
                    return new PromiseImpl(function(resolve, reject) {
                        invoke(method, arg, resolve, reject);
                    });
                }
                return previousPromise = previousPromise ? previousPromise.then(callInvokeWithMethodAndArg, callInvokeWithMethodAndArg) : callInvokeWithMethodAndArg();
            }
        });
    }
    function makeInvokeMethod(innerFn, self, context) {
        var state = "suspendedStart";
        return function(method, arg) {
            if ("executing" === state) throw new Error("Generator is already running");
            if ("completed" === state) {
                if ("throw" === method) throw arg;
                return doneResult();
            }
            for(context.method = method, context.arg = arg;;){
                var delegate = context.delegate;
                if (delegate) {
                    var delegateResult = maybeInvokeDelegate(delegate, context);
                    if (delegateResult) {
                        if (delegateResult === ContinueSentinel) continue;
                        return delegateResult;
                    }
                }
                if ("next" === context.method) context.sent = context._sent = context.arg;
                else if ("throw" === context.method) {
                    if ("suspendedStart" === state) throw state = "completed", context.arg;
                    context.dispatchException(context.arg);
                } else "return" === context.method && context.abrupt("return", context.arg);
                state = "executing";
                var record = tryCatch(innerFn, self, context);
                if ("normal" === record.type) {
                    if (state = context.done ? "completed" : "suspendedYield", record.arg === ContinueSentinel) continue;
                    return {
                        value: record.arg,
                        done: context.done
                    };
                }
                "throw" === record.type && (state = "completed", context.method = "throw", context.arg = record.arg);
            }
        };
    }
    function maybeInvokeDelegate(delegate, context) {
        var methodName = context.method, method = delegate.iterator[methodName];
        if (undefined === method) return context.delegate = null, "throw" === methodName && delegate.iterator["return"] && (context.method = "return", context.arg = undefined, maybeInvokeDelegate(delegate, context), "throw" === context.method) || "return" !== methodName && (context.method = "throw", context.arg = new TypeError("The iterator does not provide a '" + methodName + "' method")), ContinueSentinel;
        var record = tryCatch(method, delegate.iterator, context.arg);
        if ("throw" === record.type) return context.method = "throw", context.arg = record.arg, context.delegate = null, ContinueSentinel;
        var info = record.arg;
        return info ? info.done ? (context[delegate.resultName] = info.value, context.next = delegate.nextLoc, "return" !== context.method && (context.method = "next", context.arg = undefined), context.delegate = null, ContinueSentinel) : info : (context.method = "throw", context.arg = new TypeError("iterator result is not an object"), context.delegate = null, ContinueSentinel);
    }
    function pushTryEntry(locs) {
        var entry = {
            tryLoc: locs[0]
        };
        1 in locs && (entry.catchLoc = locs[1]), 2 in locs && (entry.finallyLoc = locs[2], entry.afterLoc = locs[3]), this.tryEntries.push(entry);
    }
    function resetTryEntry(entry) {
        var record = entry.completion || {};
        record.type = "normal", delete record.arg, entry.completion = record;
    }
    function Context(tryLocsList) {
        this.tryEntries = [
            {
                tryLoc: "root"
            }
        ], tryLocsList.forEach(pushTryEntry, this), this.reset(!0);
    }
    function values(iterable) {
        if (iterable) {
            var iteratorMethod = iterable[iteratorSymbol];
            if (iteratorMethod) return iteratorMethod.call(iterable);
            if ("function" == typeof iterable.next) return iterable;
            if (!isNaN(iterable.length)) {
                var i = -1, next = function next() {
                    for(; ++i < iterable.length;)if (hasOwn.call(iterable, i)) return next.value = iterable[i], next.done = !1, next;
                    return next.value = undefined, next.done = !0, next;
                };
                return next.next = next;
            }
        }
        return {
            next: doneResult
        };
    }
    function doneResult() {
        return {
            value: undefined,
            done: !0
        };
    }
    return GeneratorFunction.prototype = GeneratorFunctionPrototype, defineProperty(Gp, "constructor", {
        value: GeneratorFunctionPrototype,
        configurable: !0
    }), defineProperty(GeneratorFunctionPrototype, "constructor", {
        value: GeneratorFunction,
        configurable: !0
    }), GeneratorFunction.displayName = define(GeneratorFunctionPrototype, toStringTagSymbol, "GeneratorFunction"), exports1.isGeneratorFunction = function(genFun) {
        var ctor = "function" == typeof genFun && genFun.constructor;
        return !!ctor && (ctor === GeneratorFunction || "GeneratorFunction" === (ctor.displayName || ctor.name));
    }, exports1.mark = function(genFun) {
        return Object.setPrototypeOf ? Object.setPrototypeOf(genFun, GeneratorFunctionPrototype) : (genFun.__proto__ = GeneratorFunctionPrototype, define(genFun, toStringTagSymbol, "GeneratorFunction")), genFun.prototype = Object.create(Gp), genFun;
    }, exports1.awrap = function(arg) {
        return {
            __await: arg
        };
    }, defineIteratorMethods(AsyncIterator.prototype), define(AsyncIterator.prototype, asyncIteratorSymbol, function() {
        return this;
    }), exports1.AsyncIterator = AsyncIterator, exports1.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
        void 0 === PromiseImpl && (PromiseImpl = Promise);
        var iter = new AsyncIterator(wrap(innerFn, outerFn, self, tryLocsList), PromiseImpl);
        return exports1.isGeneratorFunction(outerFn) ? iter : iter.next().then(function(result) {
            return result.done ? result.value : iter.next();
        });
    }, defineIteratorMethods(Gp), define(Gp, toStringTagSymbol, "Generator"), define(Gp, iteratorSymbol, function() {
        return this;
    }), define(Gp, "toString", function() {
        return "[object Generator]";
    }), exports1.keys = function(val) {
        var object = Object(val), keys = [];
        for(var key in object)keys.push(key);
        return keys.reverse(), function next() {
            for(; keys.length;){
                var key = keys.pop();
                if (key in object) return next.value = key, next.done = !1, next;
            }
            return next.done = !0, next;
        };
    }, exports1.values = values, Context.prototype = {
        constructor: Context,
        reset: function reset(skipTempReset) {
            if (this.prev = 0, this.next = 0, this.sent = this._sent = undefined, this.done = !1, this.delegate = null, this.method = "next", this.arg = undefined, this.tryEntries.forEach(resetTryEntry), !skipTempReset) for(var name in this)"t" === name.charAt(0) && hasOwn.call(this, name) && !isNaN(+name.slice(1)) && (this[name] = undefined);
        },
        stop: function stop() {
            this.done = !0;
            var rootRecord = this.tryEntries[0].completion;
            if ("throw" === rootRecord.type) throw rootRecord.arg;
            return this.rval;
        },
        dispatchException: function dispatchException(exception) {
            if (this.done) throw exception;
            var context = this;
            function handle(loc, caught) {
                return record.type = "throw", record.arg = exception, context.next = loc, caught && (context.method = "next", context.arg = undefined), !!caught;
            }
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i], record = entry.completion;
                if ("root" === entry.tryLoc) return handle("end");
                if (entry.tryLoc <= this.prev) {
                    var hasCatch = hasOwn.call(entry, "catchLoc"), hasFinally = hasOwn.call(entry, "finallyLoc");
                    if (hasCatch && hasFinally) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    } else if (hasCatch) {
                        if (this.prev < entry.catchLoc) return handle(entry.catchLoc, !0);
                    } else {
                        if (!hasFinally) throw new Error("try statement without catch or finally");
                        if (this.prev < entry.finallyLoc) return handle(entry.finallyLoc);
                    }
                }
            }
        },
        abrupt: function abrupt(type, arg) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc <= this.prev && hasOwn.call(entry, "finallyLoc") && this.prev < entry.finallyLoc) {
                    var finallyEntry = entry;
                    break;
                }
            }
            finallyEntry && ("break" === type || "continue" === type) && finallyEntry.tryLoc <= arg && arg <= finallyEntry.finallyLoc && (finallyEntry = null);
            var record = finallyEntry ? finallyEntry.completion : {};
            return record.type = type, record.arg = arg, finallyEntry ? (this.method = "next", this.next = finallyEntry.finallyLoc, ContinueSentinel) : this.complete(record);
        },
        complete: function complete(record, afterLoc) {
            if ("throw" === record.type) throw record.arg;
            return "break" === record.type || "continue" === record.type ? this.next = record.arg : "return" === record.type ? (this.rval = this.arg = record.arg, this.method = "return", this.next = "end") : "normal" === record.type && afterLoc && (this.next = afterLoc), ContinueSentinel;
        },
        finish: function finish(finallyLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.finallyLoc === finallyLoc) return this.complete(entry.completion, entry.afterLoc), resetTryEntry(entry), ContinueSentinel;
            }
        },
        "catch": function _catch(tryLoc) {
            for(var i = this.tryEntries.length - 1; i >= 0; --i){
                var entry = this.tryEntries[i];
                if (entry.tryLoc === tryLoc) {
                    var record = entry.completion;
                    if ("throw" === record.type) {
                        var thrown = record.arg;
                        resetTryEntry(entry);
                    }
                    return thrown;
                }
            }
            throw new Error("illegal catch attempt");
        },
        delegateYield: function delegateYield(iterable, resultName, nextLoc) {
            return this.delegate = {
                iterator: values(iterable),
                resultName: resultName,
                nextLoc: nextLoc
            }, "next" === this.method && (this.arg = undefined), ContinueSentinel;
        }
    }, exports1;
}
function _defineProperty(obj, key, value) {
    key = _toPropertyKey(key);
    if (key in obj) {
        Object.defineProperty(obj, key, {
            value: value,
            enumerable: true,
            configurable: true,
            writable: true
        });
    } else {
        obj[key] = value;
    }
    return obj;
}
function _toPropertyKey(arg) {
    var key = _toPrimitive(arg, "string");
    return _typeof(key) === "symbol" ? key : String(key);
}
function _toPrimitive(input, hint) {
    if (_typeof(input) !== "object" || input === null) return input;
    var prim = input[Symbol.toPrimitive];
    if (prim !== undefined) {
        var res = prim.call(input, hint || "default");
        if (_typeof(res) !== "object") return res;
        throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return (hint === "string" ? String : Number)(input);
}
function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
    try {
        var info = gen[key](arg);
        var value = info.value;
    } catch (error) {
        reject(error);
        return;
    }
    if (info.done) {
        resolve(value);
    } else {
        Promise.resolve(value).then(_next, _throw);
    }
}
function _asyncToGenerator(fn) {
    return function() {
        var self = this, args = arguments;
        return new Promise(function(resolve, reject) {
            var gen = fn.apply(self, args);
            function _next(value) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
            }
            function _throw(err) {
                asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
            }
            _next(undefined);
        });
    };
}
var cookies = new _universalCookie["default"]();
var updateLocalLoginSession = function updateLocalLoginSession(data) {
    cookies.set("login", data);
};
/**
 * Attempt to sign in user or ask for more information (username) for register completion
 * @param {*} data 
 * @returns {*}
 */ exports.updateLocalLoginSession = updateLocalLoginSession;
var attemptThirdPartySignIn = /*#__PURE__*/ function() {
    var _ref = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee(data, apiUrl, domainKey) {
        var decodedToken, fetchBody, res, _res$vendor, cookieObj, cart, event;
        return _regeneratorRuntime().wrap(function _callee$(_context) {
            while(1)switch(_context.prev = _context.next){
                case 0:
                    _context.prev = 0;
                    // Decode google third party sign in data and make fetch to server for info
                    if (data && data.detail && data.detail.credential) {
                        decodedToken = (0, _jwtDecode["default"])(data.detail.credential);
                    }
                    fetchBody = {
                        domainKey: domainKey,
                        googleData: data,
                        token: decodedToken,
                        encodedToken: data.detail.credential
                    };
                    if (data.requestedUsername) {
                        fetchBody.requestedUsername = data.requestedUsername;
                    }
                    // Call to server to look for user
                    _context.next = 6;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/authenticate", null, null, fetchBody);
                case 6:
                    res = _context.sent;
                    if (res && res.hash) {
                        // Update cookie signifying login
                        cookieObj = _defineProperty({
                            identifier: res.identifier,
                            username: res.username,
                            icon: res.icon,
                            hash: res.hash,
                            vendor: (_res$vendor = res.vendor) !== null && _res$vendor !== void 0 ? _res$vendor : null
                        }, "icon", res.icon); // Optionally set official minipost plan
                        if (res.plan) {
                            cookieObj.plan = res.plan;
                        }
                        if (res.cart) {
                            cart = JSON.parse(localStorage.getItem("cart"));
                            (0, _ecommerce.updateCart)(cart, res.cart);
                        }
                        updateLocalLoginSession(cookieObj);
                        event = new CustomEvent("mute-login-error", {
                            "detail": true
                        }); // Mutes login errors across application
                        document.dispatchEvent(event);
                    }
                    return _context.abrupt("return", res);
                case 11:
                    _context.prev = 11;
                    _context.t0 = _context["catch"](0);
                    console.log(_context.t0);
                    return _context.abrupt("return", null);
                case 15:
                case "end":
                    return _context.stop();
            }
        }, _callee, null, [
            [
                0,
                11
            ]
        ]);
    }));
    return function attemptThirdPartySignIn(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
}();
exports.attemptThirdPartySignIn = attemptThirdPartySignIn;
var checkSignedIn = function checkSignedIn() {
    if (!cookies.get("login")) {
        return false;
    }
    console.log(cookies.get("login"));
    return cookies.get("login");
};
exports.checkSignedIn = checkSignedIn;
var checkSignedInAndPrompt = function checkSignedInAndPrompt(setPageError, desc) {
    try {
        var user = checkSignedIn();
        if (!user) {
            if (setPageError) {
                setPageError(desc ? desc : "Please sign in with google to register");
            }
            google.accounts.id.prompt(function(notification) {
            // console.log('on prompt notification', notification);
            });
            return false;
        }
        return user;
    } catch (err) {
        return err; // fail silently
    }
};
exports.checkSignedInAndPrompt = checkSignedInAndPrompt;
var logout = function logout(_setLoggedIn) {
    try {
        cookies.remove("login");
        if (_setLoggedIn) {
            _setLoggedIn(false);
        }
        (0, _ecommerce.updateCart)("", {
            items: [],
            user: null
        });
        var onOneTapSignedInGoogle = function onOneTapSignedInGoogle(data) {
            var event = new CustomEvent("thirdparty-signin", {
                "detail": data
            });
            document.dispatchEvent(event);
        };
        var doGoogleInit = function doGoogleInit() {
            var delay = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 250;
            try {
                google.accounts.id.initialize({
                    client_id: "169701902623-9a74mqcbqr38uj87qm8tm3190cicaa7m.apps.googleusercontent.com",
                    callback: onOneTapSignedInGoogle
                });
                console.log("Google Loaded");
                return true;
            } catch (err) {
                console.log(err);
            // fail silently
            }
        };
        setTimeout(function() {
            doGoogleInit();
        }, 2000);
        return true;
    } catch (err) {
        console.log(err);
        return false; // fail silently
    }
};
/**
 * Register username and assign it to currently signed in user *Protected route*
 * @param {String} desiredUsername 
 * @returns 
 */ exports.logout = logout;
var grabUsername = /*#__PURE__*/ function() {
    var _ref2 = _asyncToGenerator(/*#__PURE__*/ _regeneratorRuntime().mark(function _callee2(apiUrl, domainKey, data, checkSignedIn, setLoggedIn) {
        var user, fetchBody, res;
        return _regeneratorRuntime().wrap(function _callee2$(_context2) {
            while(1)switch(_context2.prev = _context2.next){
                case 0:
                    _context2.prev = 0;
                    if (!checkSignedIn) {
                        _context2.next = 32;
                        break;
                    }
                    user = checkSignedIn();
                    if (!(user && user.identifier && user.hash)) {
                        _context2.next = 29;
                        break;
                    }
                    fetchBody = {
                        domainKey: domainKey,
                        identifier: user.identifier,
                        hash: user.hash,
                        proposedUsername: data.proposedUsername
                    };
                    _context2.next = 7;
                    return (0, _fetch.fetchPost)(apiUrl + "/m/grabusername", null, null, fetchBody);
                case 7:
                    res = _context2.sent;
                    if (res) {
                        _context2.next = 12;
                        break;
                    }
                    return _context2.abrupt("return", false);
                case 12:
                    if (!res.hasOwnProperty("status")) {
                        _context2.next = 20;
                        break;
                    }
                    if (!(res.status == "disauthenticated")) {
                        _context2.next = 18;
                        break;
                    }
                    logout();
                    return _context2.abrupt("return", "disauthenticated");
                case 18:
                    if (!(res.status == "username taken")) {
                        _context2.next = 20;
                        break;
                    }
                    return _context2.abrupt("return", res.status);
                case 20:
                    if (!(res.identifier && res.username && res.hash)) {
                        _context2.next = 27;
                        break;
                    }
                    user.username = res.username;
                    user.hash = res.hash;
                    user.identifier = res.identifier;
                    updateLocalLoginSession(user);
                    setLoggedIn(user);
                    return _context2.abrupt("return", true);
                case 27:
                    _context2.next = 30;
                    break;
                case 29:
                    return _context2.abrupt("return", false);
                case 30:
                    _context2.next = 33;
                    break;
                case 32:
                    return _context2.abrupt("return", false);
                case 33:
                    _context2.next = 38;
                    break;
                case 35:
                    _context2.prev = 35;
                    _context2.t0 = _context2["catch"](0);
                    return _context2.abrupt("return", false);
                case 38:
                    return _context2.abrupt("return", false);
                case 39:
                case "end":
                    return _context2.stop();
            }
        }, _callee2, null, [
            [
                0,
                35
            ]
        ]);
    }));
    return function grabUsername(_x4, _x5, _x6, _x7, _x8) {
        return _ref2.apply(this, arguments);
    };
}();
exports.grabUsername = grabUsername;


/***/ })

};
;