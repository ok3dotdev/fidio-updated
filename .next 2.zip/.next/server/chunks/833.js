"use strict";
exports.id = 833;
exports.ids = [833];
exports.modules = {

/***/ 9021:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



const Footer = (props)=>{
    const { pageName  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: `w-full bg-black relative z-40 ${pageName === "Index" ? "" : ""}`,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-wrap justify-between pt-8 w-full pb-1 lg:grid-cols-5 md:pb-14 order-0 sm:gap-6 sm:grid sm:grid-cols-4 max-w-[110rem] mx-auto px-4 text-gray-400 gap-y-12 text-xs",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "text-center col-span-1 lg:col-span-2 w-full flex justify-center lg:block",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                            src: "/img/internal/frame2.png",
                            alt: "",
                            className: "h-auto w-[160px] lg:w-[260px]"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "col-span-1",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-white",
                                children: "LEGAL"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-gray-400 font-sans",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            className: "font-sans",
                                            href: "/terms",
                                            children: "Terms of Service"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            className: "font-sans",
                                            href: "/privacy",
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            className: "font-sans",
                                            href: "/faq",
                                            children: "FAQ"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-white",
                                children: "COMPANY"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-gray-400 font-sans",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Artist & Managers"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "cursor-pointer font-sans",
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Clubs & Venues"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Partners"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "mailto:admin@fidio.ca",
                                            children: "Sponsors"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "mb-4 text-white",
                                children: "FOLLOW US"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "flex flex-col gap-4 text-gray-400 font-sans",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "https://www.instagram.com/fidio_official/?igshid=MWZjMTM2ODFkZg%3D%3D/",
                                            children: "Instagram"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "https://www.facebook.com/Fidioafrica",
                                            children: "Facebook"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "#",
                                            children: "Twitter"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            className: "font-sans",
                                            target: "_blank",
                                            href: "https://www.linkedin.com/company/fidio-inc/",
                                            children: "LinkedIn"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "w-full p-7 max-w-[110rem] mx-auto",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("hr", {
                        className: "border-gray-400 mb-4"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "flex justify-between text-gray-400 text-xs",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "\xa92023 Fidio."
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 9833:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4836);
/* harmony import */ var _features_Footer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9021);
/* harmony import */ var _features_head_seo__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(402);
/* harmony import */ var _seo_data__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2763);
/* harmony import */ var _AltMenu__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8386);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_AltMenu__WEBPACK_IMPORTED_MODULE_6__]);
_AltMenu__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// import { Menu } from '../../modules/menu';





const HomeLayout = ({ useProps , pageName , children , pageData , props  })=>{
    const showMainMenu = pageName === "Index";
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "relative h-full",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_head_seo__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                site: _seo_data__WEBPACK_IMPORTED_MODULE_5__/* .siteData */ .HM,
                page: pageData
            }),
            showMainMenu ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Menu__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                ...props,
                classname: ""
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AltMenu__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                ...props
            }),
            children,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_features_Footer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                pageName: pageName
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HomeLayout);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(968);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);



const HeadSEO = ({ site ={} , page ={} , schema  })=>{
    var _site_seo, _site_seo1, _site_seo2, _page_seo, _site_seo3, _page_seo1, _site_seo4, _page_seo2, _site_seo5, _page_seo3, _site_seo6, _page_seo4, _page_seo_shareGraphic, _site_seo7, _site_seo_shareGraphic;
    // ({ site, page, schema });
    // set <head> variables
    const siteTitle = site.title;
    const siteFavicon = ((_site_seo = site.seo) === null || _site_seo === void 0 ? void 0 : _site_seo.favicon) || "/favicon.svg";
    const siteFaviconLegacy = ((_site_seo1 = site.seo) === null || _site_seo1 === void 0 ? void 0 : _site_seo1.faviconLegacy) || "/favicon.ico";
    const siteTouchIcon = (_site_seo2 = site.seo) === null || _site_seo2 === void 0 ? void 0 : _site_seo2.touchIcon;
    const templateTags = [
        {
            tag: "{{page_title}}",
            value: page.title
        },
        {
            tag: "{{site_title}}",
            value: siteTitle
        }
    ];
    const metaTitle = replaceTemplateTags(((_page_seo = page.seo) === null || _page_seo === void 0 ? void 0 : _page_seo.metaTitle) || ((_site_seo3 = site.seo) === null || _site_seo3 === void 0 ? void 0 : _site_seo3.metaTitle), templateTags);
    const metaDesc = ((_page_seo1 = page.seo) === null || _page_seo1 === void 0 ? void 0 : _page_seo1.metaDesc) || ((_site_seo4 = site.seo) === null || _site_seo4 === void 0 ? void 0 : _site_seo4.metaDesc);
    const shareTitle = replaceTemplateTags(((_page_seo2 = page.seo) === null || _page_seo2 === void 0 ? void 0 : _page_seo2.shareTitle) || ((_site_seo5 = site.seo) === null || _site_seo5 === void 0 ? void 0 : _site_seo5.shareTitle), templateTags);
    const shareDesc = ((_page_seo3 = page.seo) === null || _page_seo3 === void 0 ? void 0 : _page_seo3.shareDesc) || ((_site_seo6 = site.seo) === null || _site_seo6 === void 0 ? void 0 : _site_seo6.shareDesc);
    const shareGraphic = ((_page_seo4 = page.seo) === null || _page_seo4 === void 0 ? void 0 : (_page_seo_shareGraphic = _page_seo4.shareGraphic) === null || _page_seo_shareGraphic === void 0 ? void 0 : _page_seo_shareGraphic.asset) || ((_site_seo7 = site.seo) === null || _site_seo7 === void 0 ? void 0 : (_site_seo_shareGraphic = _site_seo7.shareGraphic) === null || _site_seo_shareGraphic === void 0 ? void 0 : _site_seo_shareGraphic.asset);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_head__WEBPACK_IMPORTED_MODULE_2___default()), {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                charSet: "utf-8"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "google-site-verification",
                content: "lHOono40MjI581OLKURuEXMPIAjq-zz9sYZ-xeeZeto"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                httpEquiv: "x-ua-compatible",
                content: "ie=edge"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "viewport",
                content: "initial-scale=1.0, width=device-width"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "format-detection",
                content: "telephone=no"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: siteFaviconLegacy,
                sizes: "any"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                preload: "true",
                rel: "icon",
                type: "image/svg+xml",
                href: siteFavicon
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                preload: "true",
                rel: "mask-icon",
                href: siteFavicon,
                color: "#000000"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "preconnect",
                href: "https://cdn.sanity.io",
                crossOrigin: ""
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: metaTitle
            }),
            metaDesc && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "description",
                content: metaDesc
            }),
            shareTitle && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:title",
                        content: shareTitle
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:title",
                        content: shareTitle
                    })
                ]
            }),
            shareDesc && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        property: "og:description",
                        content: shareDesc
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                        name: "twitter:description",
                        content: shareDesc
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:type",
                content: "website"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                name: "twitter:card",
                content: "summary_large_image"
            }),
            siteTitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                property: "og:site_name",
                content: siteTitle
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HeadSEO);
// replace template tags with values
function replaceTemplateTags(string, templateTags = []) {
    let newString = string;
    templateTags.map((v)=>{
        newString = newString.replace(new RegExp(v.tag, "g"), v.value);
    });
    return newString;
}


/***/ }),

/***/ 2763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Cs": () => (/* binding */ termsOfServicePageData),
/* harmony export */   "HM": () => (/* binding */ siteData),
/* harmony export */   "YZ": () => (/* binding */ homePageData),
/* harmony export */   "mm": () => (/* binding */ privacyPolicyPageData)
/* harmony export */ });
// Common site data
const siteData = {
    title: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
    seo: {
        favicon: "/img/internal/group4.png",
        faviconLegacy: "/img/internal/group4.png",
        touchIcon: "/img/internal/group4.png",
        metaTitle: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
        metaDesc: "Enjoy Your Best African Musical Concerts At The Comfort Of Your Home",
        shareTitle: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
        shareDesc: "Enjoy Your Best African Musical Concerts At The Comfort Of Your Home",
        shareGraphic: {
            asset: "/img/internal/group4.png"
        }
    }
};
// Sample data for Home page
const homePageData = {
    title: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
    seo: {
        metaTitle: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
        metaDesc: "Enjoy Your Best African Musical Concerts At The Comfort Of Your Home",
        shareTitle: "Fidio Inc. - ENJOY YOUR BEST AFRICAN MUSICAL CONCERTS",
        shareDesc: "Enjoy Your Best African Musical Concerts At The Comfort Of Your Home",
        shareGraphic: {
            asset: "/img/internal/group4.png"
        }
    }
};
// Sample data for Privacy Policy page
const privacyPolicyPageData = {
    title: "Privacy Policy | Fidio Inc.",
    seo: {
        metaTitle: "Privacy Policy | Fidio Inc.",
        metaDesc: "Learn how we protect your privacy with our comprehensive privacy policy.",
        shareTitle: "Privacy Policy | Fidio Inc.",
        shareDesc: "Learn how we protect your privacy with our comprehensive privacy policy.",
        shareGraphic: {
            asset: "/img/internal/group4.png"
        }
    }
};
// Sample data for Terms of Service page
const termsOfServicePageData = {
    title: "Terms of Service | Fidio Inc.",
    seo: {
        metaTitle: "Terms of Service | Our Terms and Conditions",
        metaDesc: "Read our terms of service to understand our terms and conditions.",
        shareTitle: "Terms of Service | Fidio Inc.",
        shareDesc: "Read our terms of service to understand our terms and conditions.",
        shareGraphic: {
            asset: "/img/internal/group4.png"
        }
    }
};



/***/ })

};
;