"use strict";
(() => {
var exports = {};
exports.id = 229;
exports.ids = [229];
exports.modules = {

/***/ 6076:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {


// UNUSED EXPORTS: default

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: external "@mui/icons-material/HomeOutlined"
const HomeOutlined_namespaceObject = require("@mui/icons-material/HomeOutlined");
;// CONCATENATED MODULE: external "@mui/icons-material/WatchLaterOutlined"
const WatchLaterOutlined_namespaceObject = require("@mui/icons-material/WatchLaterOutlined");
;// CONCATENATED MODULE: external "@mui/icons-material/FavoriteBorderOutlined"
const FavoriteBorderOutlined_namespaceObject = require("@mui/icons-material/FavoriteBorderOutlined");
;// CONCATENATED MODULE: external "@mui/icons-material/VideoLibraryOutlined"
const VideoLibraryOutlined_namespaceObject = require("@mui/icons-material/VideoLibraryOutlined");
;// CONCATENATED MODULE: external "@mui/icons-material/SettingsOutlined"
const SettingsOutlined_namespaceObject = require("@mui/icons-material/SettingsOutlined");
;// CONCATENATED MODULE: external "@mui/icons-material/ExitToAppOutlined"
const ExitToAppOutlined_namespaceObject = require("@mui/icons-material/ExitToAppOutlined");
// EXTERNAL MODULE: ./modules/utility/onboarding/SignIn.js
var SignIn = __webpack_require__(5203);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./customModules/features/Sidebar.jsx










const Sidebar = (props)=>{
    var _props_userData, _props_userData_profileData, _props_userData_profileData_user;
    const router = useRouter();
    const { query , asPath  } = router;
    const handleLogout = (e)=>{
        logout();
        router.push("/");
    };
    return /*#__PURE__*/ _jsx("div", {
        className: "bg-black h-full px-2 md:px-6 text-sm font-medium text-dashtext shadow-lg",
        children: /*#__PURE__*/ _jsxs("div", {
            className: " h-full flex flex-col pb-12 ",
            children: [
                /*#__PURE__*/ _jsxs("div", {
                    className: "mb-8 flex items-center flex-col gap-8 pt-4",
                    children: [
                        /*#__PURE__*/ _jsx("div", {
                            className: "w-12  h-12 rounded-full",
                            children: /*#__PURE__*/ _jsx("a", {
                                href: "/p",
                                children: /*#__PURE__*/ _jsx("img", {
                                    className: "rounded-full",
                                    src: props === null || props === void 0 ? void 0 : (_props_userData = props.userData) === null || _props_userData === void 0 ? void 0 : (_props_userData_profileData = _props_userData.profileData) === null || _props_userData_profileData === void 0 ? void 0 : (_props_userData_profileData_user = _props_userData_profileData.user) === null || _props_userData_profileData_user === void 0 ? void 0 : _props_userData_profileData_user.icon,
                                    alt: ""
                                })
                            })
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "flex flex-col items-center gap-y-8 mt-6",
                            children: [
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(HomeOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "hidden md:block",
                                            children: "Home"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(WatchLaterOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "hidden md:block",
                                            children: "Recents"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(VideoLibraryOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "hidden md:block",
                                            children: "Playlists"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(FavoriteBorderOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "hidden md:block",
                                            children: "Favourites"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ _jsxs("div", {
                    className: "flex items-center justify-between flex-col pt-2 h-full basis-1/2",
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: "w-full",
                            children: [
                                /*#__PURE__*/ _jsx("hr", {
                                    className: "w-full pb-2 border-dashBorder"
                                }),
                                /*#__PURE__*/ _jsx("p", {
                                    className: "text-center",
                                    children: "Following"
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: "flex flex-col items-center gap-y-8 pb-8",
                            children: [
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(SettingsOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            className: "hidden md:block",
                                            children: "Settings"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ _jsxs("div", {
                                    className: "flex w-full justify-start gap-x-8",
                                    children: [
                                        /*#__PURE__*/ _jsx(ExitToAppOutlinedIcon, {}),
                                        /*#__PURE__*/ _jsx("p", {
                                            onClick: handleLogout,
                                            className: "hidden md:block cursor-pointer",
                                            children: "Logout"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const features_Sidebar = ((/* unused pure expression or super */ null && (Sidebar)));

// EXTERNAL MODULE: ./customModules/features/Menu.jsx
var features_Menu = __webpack_require__(4836);
// EXTERNAL MODULE: ./customModules/features/Footer.jsx
var Footer = __webpack_require__(9021);
;// CONCATENATED MODULE: ./customModules/features/Layout.jsx


// import Menu from '../../modules/menu/Menu';



const Layout = ({ props , children , userData  })=>{
    return /*#__PURE__*/ _jsxs("div", {
        className: " relative h-screen",
        children: [
            /*#__PURE__*/ _jsx(Menu, {
                page: "home",
                ...props
            }),
            /*#__PURE__*/ _jsx("div", {
                className: "bg-black  h-full flex",
                children: children
            })
        ]
    });
};
/* harmony default export */ const features_Layout = ((/* unused pure expression or super */ null && (Layout)));


/***/ }),

/***/ 716:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps),
/* harmony export */   "page": () => (/* binding */ page)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _modules_utility_fetch__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(23);
/* harmony import */ var _app_config__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(139);
/* harmony import */ var _modules_utility_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4108);
/* harmony import */ var _modules_util__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8131);
/* harmony import */ var _modules_menu___WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9675);
/* harmony import */ var _customModules_features_Layout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6076);
/* harmony import */ var _customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9833);
/* harmony import */ var _customModules_features_HomeDash__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1630);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_9__]);
_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_9__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
/* eslint-disable react-hooks/rules-of-hooks */ 










const pageName = "home";
const page = (props)=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const { query , asPath  } = router;
    const [fetching, setFetching] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [mergeProps, setMergeProps] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({});
    let resolvedDefinition = props.resolvedDefinition;
    const variables = (0,_app_config__WEBPACK_IMPORTED_MODULE_4__.resolveVariables)();
    let config = (0,_app_config__WEBPACK_IMPORTED_MODULE_4__["default"])(variables, props);
    let resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .resolvePage */ .mS)(config, props.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const getDefaults = async (force)=>{
        const defaults = await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .resolveDefaults */ .Fx)(resolvedPage.url, props, variables, query, asPath, setFetching, force);
        if (!(0,_modules_util__WEBPACK_IMPORTED_MODULE_6__.isObjectEmpty)(defaults)) {
            const newProps = Object.assign({
                ...props
            }, defaults);
            setMergeProps(newProps);
        }
    };
    props._LocalEventEmitter.unsubscribe("refetchDefaults");
    props._LocalEventEmitter.subscribe("refetchDefaults", (e)=>{
        getDefaults(true);
    });
    const [componentDidMount, setComponentDidMount] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [fetchingProfile, setFetchingProfile] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const [profileLoaded, setProfileLoaded] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(false);
    const r = react__WEBPACK_IMPORTED_MODULE_1___default().useRef();
    const profileEvent = "fetchProfileData";
    props._LocalEventEmitter.unsubscribe(profileEvent);
    props._LocalEventEmitter.subscribe(profileEvent, (e)=>{
        e, profileLoaded, fetchingProfile, props._loggedIn, e.dispatch == "fetch";
        if (e.dispatch && e.dispatch == "fetch") {
            if (!profileLoaded && !fetchingProfile && props._loggedIn && props._loggedIn.username) {
            // ('Running!');
            // getUserProfileData(props);
            }
        }
    });
    const getUserProfileData = async (props)=>{
        try {
            setFetchingProfile(true);
            setTimeout(()=>{
                setFetchingProfile(false);
            }, 1000);
            let fetchBody = {
                domainKey: props.domainKey,
                params: {
                    u: props._loggedIn.username
                },
                hash: props._loggedIn.hash,
                identifier: props._loggedIn.identifier,
                profileReq: true
            };
            // ('Running req', fetchBody, props.apiUrl + '/m/pagedefaults');
            let res = await (0,_modules_utility_fetch__WEBPACK_IMPORTED_MODULE_3__.fetchPost)(props.apiUrl + "/m/pagedefaults", null, null, fetchBody);
            if (!res) {
                setFetchingProfile(false);
                return false;
            } else if (res.hasOwnProperty("status")) {
                if (res.status == "disauthenticated") {
                    setFetchingProfile(false);
                    logout();
                    return "disauthenticated";
                } else if (res.status == "failed") {
                    setFetchingProfile(false);
                    return false;
                } else if (res.status == "success") {
                    setFetchingProfile(false);
                    setProfileLoaded(res);
                    // ('res11', res);
                    return res;
                }
            }
            setFetchingProfile(false);
        } catch (err) {
            setFetchingProfile(false); // fail silently
        }
    };
    const useProps = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .handlePropsPriority */ .oC)(mergeProps, props);
    config = (0,_app_config__WEBPACK_IMPORTED_MODULE_4__["default"])(variables, useProps);
    resolvedPage = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .resolvePage */ .mS)(config, useProps.path);
    resolvedDefinition = resolvedPage && resolvedPage.data; // Access the `data` property
    const components = (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .generateComponent */ .iR)(resolvedDefinition);
    // // ({ useProps });
    // ('home', props);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customModules_features_HomeLayout__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
            pageName: pageName,
            pageData: "",
            props: useProps,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_customModules_features_HomeDash__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                ...props
            })
        })
    });
};
const getServerSideProps = async (context)=>{
    return await (0,_modules_utility_js__WEBPACK_IMPORTED_MODULE_5__/* .getServerSidePropsDefault */ .nG)(context, _app_config__WEBPACK_IMPORTED_MODULE_4__.pageDefaults[pageName]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (page);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AllInclusive");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 2818:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronRight");

/***/ }),

/***/ 9605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 5020:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Inventory");

/***/ }),

/***/ 1567:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Notifications");

/***/ }),

/***/ 7248:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCart");

/***/ }),

/***/ 227:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Stadium");

/***/ }),

/***/ 5692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 7229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 4515:
/***/ ((module) => {

module.exports = require("@stripe/react-stripe-js");

/***/ }),

/***/ 943:
/***/ ((module) => {

module.exports = require("@stripe/stripe-js");

/***/ }),

/***/ 5567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 2423:
/***/ ((module) => {

module.exports = require("lucide-react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 5925:
/***/ ((module) => {

module.exports = require("next/router.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5700:
/***/ ((module) => {

module.exports = require("react-fast-marquee");

/***/ }),

/***/ 4508:
/***/ ((module) => {

module.exports = require("react-responsive-carousel");

/***/ }),

/***/ 6153:
/***/ ((module) => {

module.exports = require("universal-cookie");

/***/ }),

/***/ 5828:
/***/ ((module) => {

module.exports = require("uuid");

/***/ }),

/***/ 5335:
/***/ ((module) => {

module.exports = require("video.js");

/***/ }),

/***/ 7715:
/***/ ((module) => {

module.exports = import("@radix-ui/react-dialog");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 6912:
/***/ ((module) => {

module.exports = import("zustand");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [172,750,636,262,102,108,386,833,675], () => (__webpack_exec__(716)));
module.exports = __webpack_exports__;

})();